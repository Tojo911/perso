import { Component, Input, ElementRef, AfterViewInit } from '@angular/core';

/**
 * Composant Wizard
 * Il prend en entré un liste d'étapes.
 * Sous la forme d'un tableau d'objet.
 * Chaque objet possède une clé 'name' et une clé 'childs' qui permet d'afficher une liste de sous enfants.
 * Chaque enfant est un objet qui contient une clé 'name' et une clé 'template'.
 * Permet d'afficher le contenu d'un template `<ng-template>` directement dans le bon emplacement.

 Exemple:
```javascript
this.wizardSteps = [
	{
		name: 'Information client',
		childs: [
			{ name: 'Sous étape 1', template: this.subStep1 },
			{ name: 'Sous étape 2', template: this.subStep2 },
			{ name: 'Sous étape 3', template: this.subStep3 },
			{ name: 'Sous étape 4', template: this.subStep4 }
		]
	}
];
```
 *
 *
 */
@Component({
  selector: 'app-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.scss']
})
export class WizardComponent implements AfterViewInit {
  @Input() steps = [];
  localIndex = 0;

  @Input()
  set index(newIndex) {
    this.localIndex = newIndex;
    this.refreshListenerEvents();
  }
  get index() {
    return this.localIndex;
  }

  constructor(private _elementRef: ElementRef) {}

  next() {
    if (this.localIndex < this.steps.length) {
      this.index = this.localIndex + 1;
    }
  }

  ngAfterViewInit() {
    this.refreshListenerEvents();
  }

  refreshListenerEvents() {
    const getElement = newElement => {
      do {
        if (newElement.classList.contains('is-wizard-sub-step')) {
          return newElement;
        } else {
          newElement = newElement.parentElement;
        }
      } while (newElement !== null);

      return null;
    };

    setTimeout(() => {
      const list = this._elementRef.nativeElement.getElementsByTagName('input');
      for (let i = 0; i < list.length; i++) {
        list[i].onfocus = e => {
          const newElement = getElement(e.srcElement);
          console.log(newElement);
          if (newElement) {
            newElement.classList.add('active');
          }
        };

        list[i].onblur = e => {
          const newElement = getElement(e.srcElement);
          if (newElement) {
            newElement.classList.remove('active');
          }
        };
      }
    }, 10);
  }
}
