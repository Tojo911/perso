import {
  Component,
  OnInit,
  Input,
  Output,
  AfterViewInit,
  ElementRef,
  ViewEncapsulation,
  HostListener,
  forwardRef,
  EventEmitter
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { IonRangeSliderCallback } from 'ng2-ion-range-slider';
declare const $: any;

/**
 * Composant Slider
 * @param values (optionnel)	Saisie d'une plage de valeurs. Chez nous, il n'en faut que 2.
 * @param min (optionnel)	Saisie d'une valeure min
 * @param max (optionnel) Saisie d'une valeure max
 * @param step (optionnel) Saisie d'une graduation de progression. Pour eviter de tomber sur des chiffres trop précis comme 10002€
 * @param unity (optionnel) Saisie d'une unité de valeure
 * @param placeholder (optionnel) Saisie d'un champ par défaut
 *
 * Attention Jquery ui est obligatoire pour ce composant.
 */
@Component({
  selector: 'app-input-slider',
  templateUrl: './input-slider.component.html',
  styleUrls: ['./input-slider.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => InputSliderComponent)
    }
  ],
  encapsulation: ViewEncapsulation.None
})
export class InputSliderComponent implements OnInit, ControlValueAccessor {
  @Input()
  min: number = null;
  mouseIsOver = false;
  mouseleavedAlready = false;
  @Input()
  autoClosedAfter: number = null;
  @Input()
  max: number = null;
  @Input()
  step: number = null;
  @Input()
  unity: string = null;
  @Input()
  placeholder: string = null;
  @Input()
  rangeValues = [this.min, this.max];
  popupSliderVisible = false;
  isPopupReady = false;
  onChanged: () => any;
  onTouched: () => any;
  @Output()
  rangeValuesChange = new EventEmitter();

  @Input()
  set values(vals) {
    if (vals === null) {
      vals = [null, null];
    }
    if (vals) {
      if (vals[0] === null) {
        vals[0] = this.min;
      }

      if (vals[1] === null) {
        vals[1] = this.max;
      }

      this.rangeValues = [+vals[0], +vals[1]];
    }
  }
  get values() {
    return this.rangeValues;
  }

  constructor(private _elementRef: ElementRef) {}
  // initiliation des valeurs pour éviter de gérer le cas où l'on n'a pas saisi
  ngOnInit() {
    if (this.rangeValues === null) {
      this.rangeValues = [+this.min, +this.max];
    }
  }

  // auto fermeture de la popup
  @HostListener('document:click', ['$event'])
  onClick(event: Event): void {
    const slider = this._elementRef.nativeElement.querySelector(
      '.popup-slider'
    );
    if (slider && !slider.contains(event.target) && this.isPopupReady) {
      this.onTogglePopup();
    }
  }

  // affichage ou non de la popup + initialisation des bonnes variables
  onTogglePopup() {
    if (this.popupSliderVisible) {
      this.popupSliderVisible = false;
      this.isPopupReady = false;
    } else {
      this.popupSliderVisible = true;
      setTimeout(() => {
        this.isPopupReady = true;
      }, 200);
    }
  }

  // convertion d'un nombre en joli nombre ex: 1000000 => 1 000 000
  getString(value: number) {
    let string = '';
    const valueToString = value + '',
      length = valueToString.length;

    for (let i = length - 1; i >= 0; i--) {
      string = valueToString[i] + string;
      if ((length - i) % 3 === 0) {
        string = ' ' + string;
      }
    }

    return string.trim();
  }

  // convertion d'un nombre en petit nombre ex: 1000000 => 1M
  getShortString(value: number) {
    const rangeList = [{ value: 'M', nbZero: 6 }, { value: 'K', nbZero: 3 }];
    for (let i = 0; i < rangeList.length; i++) {
      const range = rangeList[i],
        puissance = Math.pow(10, range.nbZero);
      if (value >= puissance) {
        return Math.floor(value / puissance) + range.value;
      }
    }

    return value;
  }

  writeValue(obj): void {
    this.rangeValues = obj;
    this.rangeValuesChange.emit(this.rangeValues);
  }
  registerOnChange(fn: any): void {
    this.onChanged = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  sliderChange($event: IonRangeSliderCallback) {
    this.writeValue([$event.from, $event.to]);
  }
  /*@HostListener('mousemove', ['$event.target'])
  onmouseover(el) {
    this.mouseIsOver = true;
    console.log('mouseOver:' + this.mouseIsOver);
  }
  @HostListener('mouseleave', ['$event.target'])
  onmouseleave(el?) {
    if (this.autoClosedAfter) {
      if ( this.mouseleavedAlready && this.popupSliderVisible && !this.mouseIsOver ) {
        this.onTogglePopup();
        this.mouseleavedAlready = false;
      } else  if (  this.popupSliderVisible)  {
        setTimeout(() => {this.onmouseleave(); }, this.autoClosedAfter);
        this.mouseleavedAlready = true;
      } else if ( this.mouseIsOver ) {
        this.mouseleavedAlready = false;
      }
    }

    this.mouseIsOver = false;
  }*/
  hasLeft(el) {
    if (this.popupSliderVisible) {
      this.onTogglePopup();
    }
  }
}
