import { Component, Input, TemplateRef, HostBinding } from '@angular/core';
import {
  FileUploader,
  FileDropDirective,
  FileSelectDirective,
  FileItem
} from 'ng2-file-upload';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SelectTypeDocumentDialogComponent } from './select-type-document-dialog/select-type-document-dialog.component';
import { FileItemPlus } from '../../../models/file-item-plus';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent {
  @Input()
  placeHolderTemplate: TemplateRef<any> = null;
  @Input()
  fileSizeErrMsg: string;
  isFileSizeErrMsg: boolean;
  @Input()
  mediaTypeErrMsg: string;
  isMediaTypeErrMsg: boolean;
  @HostBinding('class.has-file')
  classHasFile = false;
  allowedMimeType =
   // tslint:disable-next-line:max-line-length
   'image/jpeg,image/png,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  @Input()
  data;
  localFile = null;
  isMimeTypeError = false;
  public uploader = new FileUploader({
    allowedMimeType: this.allowedMimeType.split(','),
    maxFileSize: 1024 * 1024 * 100 /* 100Mb */
  });
  public hasBaseDropZoneOver = false;
  public hasAnotherDropZoneOver = false;
  // input with setter
  constructor(private dialog: MatDialog) {
    this.uploader.onWhenAddingFileFailed = item => {
      this.isMimeTypeError = true;
      const errors: any = {};
      errors.fileName = item.name;
      errors.list = [];
      errors.isError = true;
      if (item.size > this.uploader.options.maxFileSize) {
        this.isFileSizeErrMsg = true;
        errors.list.push(this.fileSizeErrMsg);
      }
      if (this.uploader.options.allowedMimeType.indexOf(item.type) === -1) {
        this.isMediaTypeErrMsg = true;
        errors.list.push(this.mediaTypeErrMsg);
      }

      setTimeout(() => {
        this.isMimeTypeError = false;
      }, 1000);
      setTimeout(() => {
        this.isFileSizeErrMsg = false;
        this.isMediaTypeErrMsg = false;
      }, 2000);
      const dialogConfig = {
        width: '500px',
        data: errors
      };
      this.dialog.open(SelectTypeDocumentDialogComponent, dialogConfig);
      console.log(item);
    };
    this.uploader.onAfterAddingFile = file => {
      console.log(file);
      const dialogConfig = {
        width: '500px',
        data: file,
        disableClose: true
      };
      this.dialog
        .open(SelectTypeDocumentDialogComponent, dialogConfig)
        .afterClosed()
        .subscribe(res => {
          console.log(res);
          this.data.files = this.uploader.queue;
          this.uploader.queue.forEach(item => {
            if (item._file.name === res._file.name) {
              item.formData = res.formData;
            }
          });
        });
    };
  }
  @Input()
  set file(file) {
    this.localFile = file;
    console.log(this.localFile);
    this.classHasFile = file !== null;
  }
  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e;
  }
  get file() {
    return this.localFile;
  }

  onRemove() {
    this.file = null;
  }
}
