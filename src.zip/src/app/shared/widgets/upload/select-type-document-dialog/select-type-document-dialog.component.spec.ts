import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectTypeDocumentDialogComponent } from './select-type-document-dialog.component';

describe('SelectTypeDocumentDialogComponent', () => {
  let component: SelectTypeDocumentDialogComponent;
  let fixture: ComponentFixture<SelectTypeDocumentDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectTypeDocumentDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectTypeDocumentDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
