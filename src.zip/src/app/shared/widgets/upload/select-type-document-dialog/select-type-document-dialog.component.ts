import { Component, OnInit, Inject } from '@angular/core';
import { ModelOption } from '../../../../models/option-model';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FileItem } from 'ng2-file-upload';

@Component({
  selector: 'app-select-type-document-dialog',
  templateUrl: './select-type-document-dialog.component.html',
  styleUrls: ['./select-type-document-dialog.component.scss']
})
export class SelectTypeDocumentDialogComponent implements OnInit {
  documentTypes: ModelOption[];
  setDocumentTypes(item) {
    console.log(item);
    this.data.formData = {'documentType': item.libelle, 'typeCode': item.value};
    console.log(this.data);

    this.dialogRef.close(this.data);
  }
  closeDialog() {
    this.dialogRef.close();
  }
  constructor( public dialogRef: MatDialogRef<SelectTypeDocumentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.documentTypes = [
      new ModelOption('Carte nationale d\'identité', 'CNI'),
      new ModelOption('Identification du matériel', 'IDENT_MAT'),
      new ModelOption('KBIS', 'KBIS'),
      new ModelOption('Demande de financement', 'DMD_FINAN'),
      new ModelOption('Eléments financiers', 'ELEM_FINANCIER'),
      new ModelOption('Autres documents', 'AUTRES')
    ];
   }

  ngOnInit() {
  }

}
