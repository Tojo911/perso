import {
  Component,
  Input,
  Output,
  ElementRef,
  EventEmitter,
  ChangeDetectionStrategy,
  forwardRef,
  OnInit
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { ModelOption } from '../../../models/option-model';

/**
 * Composant Multi options
 * @param value	Saisie des options en string. Possibilité de passer en
 * object mais attention au *[attr.outline]="value === option"* dans le htmld
 *
 * @Output valueChange two-way binding pour la valeur "value" avec possiblité de n'écouter que le retour.
 */

@Component({
  selector: 'app-multi-options',
  templateUrl: './multi-options.component.html',
  styleUrls: ['./multi-options.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => MultiOptionsComponent)
    }
  ],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MultiOptionsComponent implements ControlValueAccessor, OnInit {
  @Input()
  value: ModelOption | string = null;
  @Input()
  label: string;
  @Input()
  preset = false;
  @Input()
  options: ModelOption[] | string[] = [];
  optionKeys: string[] = [];
  valueKey: string;
  @Output()
  valueChange = new EventEmitter();
  isModelOpt = true;
  onChange = (_: any) => {};
  onTouched = (_: any) => {};

  ngOnInit(): void {
    if (this.options && this.options.length > 0) {
      if (typeof this.options[0] !== 'string') {
        const tab = this.options as ModelOption[];
        this.optionKeys = tab.map((res: ModelOption) => res.libelle);
      } else {
        this.optionKeys = this.options as string[];
      }
    }

    if (this.preset) {
      if (!this.value && this.optionKeys && this.optionKeys.length > 0) {
        this.onSelectOption(this.optionKeys[0]);
      }
    }
  }

  constructor(private _elementRef: ElementRef) {}

  onSelectOption(option: string) {
    this.writeValue(option);
    this.valueChange.emit(this.value);
    this.onChange(this.value);
  }

  checkButtonWith() {
    // check max size and upgrade value
    const buttonList = this._elementRef.nativeElement.getElementsByTagName(
        'button'
      ),
      length = buttonList.length;
    let newMaxWith = 0;
    for (let i = 0; i < length; i++) {
      const button = buttonList[i],
        width = button.offsetWidth;
      if (width > newMaxWith) {
        newMaxWith = width;
      }
    }

    // set new width
    const newMaxWithString = newMaxWith + 'px';
    for (let i = 0; i < length; i++) {
      const buttonStyled = buttonList[i];
      buttonStyled.style.width = newMaxWithString;
    }
  }

  isNotSelected(option: string) {
    // if (this.valueKey && this.valueKey !== '') {
    if (this.value && this.value !== '' && typeof this.value === 'string') {
      return option.toLowerCase() !== (this.value as string).toLowerCase();
    } else if (this.valueKey && this.valueKey !== '') {
      return option.toLowerCase() !== this.valueKey.toLowerCase();
    } else {
      return true;
    }
  }

  getOptionModel(option: string) {
    if (this.options.length > 0) {
      if (typeof this.options[0] !== 'string') {
        const tab = this.options as ModelOption[];
        return tab.filter(res => res.libelle === option)[0];
      } else {
        return option;
      }
    }
  }
  onResize(event) {
    console.log(event);
  }

  writeValue(value: any): void {
    if (this.isPossibleValue(value)) {
      this.value = this.getOptionModel(value);
      this.valueKey = value;
    }
  }
  isPossibleValue(value: string) {
    let flag = false;
    this.optionKeys.forEach(it => {
      if (value === it) {
        flag = true;
      }
    });
    return flag;
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
}
