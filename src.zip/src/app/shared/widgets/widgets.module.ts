import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../modules/material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { CollapsePanelComponent } from './collapse-panel/collapse-panel.component';
import { InputComponent } from './input/input.component';
import { InputDatePickerComponent } from './input-date-picker/input-date-picker.component';
import { InputRangeDateComponent } from './input-range-date/input-range-date.component';
import { InputSearchComponent } from './input-search/input-search.component';
import { InputSliderComponent } from './input-slider/input-slider.component';
import { KpiNumberComponent } from './kpi-number/kpi-number.component';
import { MultiOptionsComponent } from './multi-options/multi-options.component';
import { SelectComponent } from './select/select.component';
import { TextareaComponent } from './textarea/textarea.component';
import { UploadComponent } from './upload/upload.component';
import { DatePickerInputComponent } from './date-picker-input/date-picker-input.component';
import { WizardComponent } from './wizard/wizard.component';
import { IonRangeSliderModule } from 'ng2-ion-range-slider';
import { FileUploadModule } from 'ng2-file-upload';
import { SelectTypeDocumentDialogComponent } from './upload/select-type-document-dialog/select-type-document-dialog.component';
import { DirectivesModule } from '../../directives/directives.module';
import { DateStepperComponent } from './date-stepper/date-stepper.component';
import { CollapseMenuComponent } from './collapse-menu/collapse-menu.component';

const list = [
  BreadcrumbComponent,
  CollapsePanelComponent,
  DatePickerInputComponent,
  InputComponent,
  InputDatePickerComponent,
  InputRangeDateComponent,
  InputSearchComponent,
  InputSliderComponent,
  KpiNumberComponent,
  MultiOptionsComponent,
  SelectComponent,
  TextareaComponent,
  InputRangeDateComponent,
  InputDatePickerComponent,
  InputSearchComponent,
  InputSliderComponent,
  UploadComponent,
  WizardComponent,
  DatePickerInputComponent,
  DateStepperComponent,
  CollapseMenuComponent
];

@NgModule({
  declarations: [...list, SelectTypeDocumentDialogComponent],
  entryComponents: [SelectTypeDocumentDialogComponent],
  imports: [MaterialModule, CommonModule, FormsModule, ReactiveFormsModule, IonRangeSliderModule, FileUploadModule, DirectivesModule],
  exports: list
})
export class WidgetsModule {}
