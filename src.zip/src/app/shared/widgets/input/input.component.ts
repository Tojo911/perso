import {
  Component,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  Renderer2,
  OnInit,
  forwardRef,
  HostListener,
  ViewChild,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import {
  ControlValueAccessor,
  FormGroup,
  FormControl,
  NG_VALUE_ACCESSOR
} from '@angular/forms';
import { IFormatInput } from '../../../classes/interfaces/IFormatInput';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => InputComponent)
    }
  ]
})
export class InputComponent implements ControlValueAccessor, OnChanges, OnInit {
  @ViewChild('formatInput')
  formatInput: ElementRef;
  @ViewChild('input')
  input: ElementRef;
  @Input()
  label: string = null;
  @Input()
  format: string = null;
  @Input()
  placeholder: string = null;
  @Input()
  hidden: string = null;
  @Input()
  description: string = null;
  @Input()
  disabled = false;
  @Input()
  readonlyInput = false;
  @Input()
  type: string = null;
  // Min and Max for type number; to be fixed later
  @Input()
  min: number = null;
  @Input()
  max: number = null;
  @Input()
  maxLength: number;
  maxLengthFormat: number;
  @Input()
  minLength: number;
  @Input()
  unit: string = null;
  @Input()
  name: string = null;
  @Input()
  cancellable = false;
  @Input()
  searching = false;
  @Input()
  value: string = null;
  @Input()
  customFormat: IFormatInput;
  @Output()
  valueChange = new EventEmitter();
  @Output()
  cancelValue = new EventEmitter();
  formattedValue = '';
  onChange = (_: any) => {};
  onTouched = (_: any) => {};
  constructor(private el: ElementRef, private renderer: Renderer2) {}
  ngOnInit() {
    if ( this.formatInput && this.formatInput.nativeElement.readonly !== this.readonlyInput) {
      this.formatInput.nativeElement.readonly = this.readonlyInput;
    }
    if ( this.input && this.input.nativeElement.readonly !== this.readonlyInput) {
      this.input.nativeElement.readonly = this.readonlyInput;
    }
  }
  ngOnChanges(changes: SimpleChanges) {
    if (
      (this.format || this.customFormat) &&
      changes.value &&
      changes.value.currentValue !== this.parse(this.formattedValue)
    ) {
      this.formattedValue = this.transform(changes.value.currentValue);
      if (this.formatInput) {
        this.formatInput.nativeElement.value = this.formattedValue;
      }
    }
  }
  change(newValue) {
    this.writeValue(newValue);
    this.valueChange.emit(newValue);
    this.onChange(this.value);
    if (this.format || this.customFormat) {
      this.formatInput.nativeElement.value = this.formattedValue;
    }
  }

  changeFormat(newValue) {
    this.formattedValue = this.transform(newValue);
    const offset = this.formattedValue.split(' ').length - 1;
    if (offset && offset > 0) {
      this.maxLengthFormat = this.maxLength + offset;
    }
    const unformattedValue = this.parse(this.formattedValue);
    this.change(unformattedValue);
  }
  cancel(data) {
    this.formattedValue = '';
    this.value = '';
    this.cancelValue.emit(data);
  }
  writeValue(value: any): void {
    this.value = value;
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  transform(val) {
    let valStr = '';
    let arr;
    if (this.format) {
      switch (this.format) {
        case 'siren':
          valStr = val + '';
          valStr = this.parse(valStr) + '';
          arr = valStr.split('');
          valStr = '';
          arr.map(c => {
            valStr += c;
            if (
              valStr.replace(/ /g, '').length % 3 === 0 &&
              arr.length > valStr.replace(/ /g, '').length
            ) {
              valStr += ' ';
            }
          });
          break;
        case 'amount':
          // restriction maxlength minlength
          // calcul max ou min
          let decPart = '';
          if (this.min && val < this.min) {
            val = this.min + '';
          }
          if (this.max && val > this.max) {
            val = this.max + '';
          }
          valStr = val + '';
          valStr = this.parse(valStr);
          if (valStr === '') {
            return '';
          }
          if (valStr.indexOf('.')) {
            decPart = valStr.split('.')[1];
            valStr = valStr.split('.')[0];
          }
          if (this.maxLength && valStr.length > this.maxLength) {
            valStr = valStr.substring(0, this.maxLength);
          }
          arr = valStr.split('');
          valStr = '';
          arr.reverse().map(c => {
            valStr += c;
            if (
              valStr.replace(/ /g, '').length % 3 === 0 &&
              arr.length > valStr.replace(/ /g, '').length
            ) {
              valStr += ' ';
            }
          });
          valStr = valStr
            .split('')
            .reverse()
            .join('');
          if (decPart && decPart !== '') {
            valStr += '.' + decPart;
          }
          break;
      }
    } else {
      valStr = this.customFormat.transform(val);
    }
    return valStr;
  }

  parse(val) {
    let valStr = '';
    if (this.format) {
      switch (this.format) {
        case 'siren':
          valStr = val + '';
          valStr = valStr.replace(/ /g, '');
          if (this.maxLength && valStr.length > this.maxLength) {
            valStr = valStr.substring(0, this.maxLength);
          }

          break;
        case 'amount':
          valStr = val + '';
          if (valStr.substring(valStr.length - 1, 1) === '.') {
            valStr = valStr.replace('.', '');
          }
          valStr = valStr.replace(/ /g, '');
          if (valStr === '') {
            return '';
          }
          val = Number(valStr);
          if (this.min && val < this.min) {
            val = this.min + '';
          }
          if (this.max && val > this.max) {
            val = this.max + '';
          }
          valStr = val + '';
          if (this.maxLength && valStr.length > this.maxLength) {
            valStr = valStr.substring(0, this.maxLength);
          }
          // calcul max ou min
          // restriction maxlength minlength
          break;
      }
    } else {
      valStr = this.customFormat.parse(val);
    }
    return valStr;
  }
}
