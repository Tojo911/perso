import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent implements OnInit {
  @Input() steps: any[] = [];
  @Output() stepChange = new EventEmitter<string>();
  constructor() {}

  ngOnInit() {}

  search(item: string) {
    this.stepChange.emit(item);
  }
}
