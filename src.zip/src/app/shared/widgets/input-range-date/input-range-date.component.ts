import {
  Component,
  Input,
  ElementRef,
  HostListener,
  OnInit,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  AfterViewInit,
  Output,
  forwardRef,
  ViewChild
} from '@angular/core';
import { InputDatePickerComponent } from '../input-date-picker/input-date-picker.component';
import { ClickedOutsideDirective } from '../../../directives/clicked-outside.directive';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

/**
 * Composant Date range
 * C'est un composant qui prend 2 date et les affiches pour séléctionner une plage de temps.
 *
 * @param dates (optionnel) Saisie de 2 dates (Qui serront luent par l'object new Date(param))
 *
 */

@Component({
  selector: 'app-input-range-date',
  templateUrl: './input-range-date.component.html',
  styleUrls: ['./input-range-date.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => InputRangeDateComponent),
    }
  ]
})
export class InputRangeDateComponent
  implements OnInit, ControlValueAccessor, AfterViewInit, OnChanges {
  @Input()
  dates = undefined;
  @Input()
  placeholderRange1;
  @Input()
  placeholderRange2;
  @Output()
  datesChange = new EventEmitter<any>();
  @Input()
  placeholder = 'Date';
  textPreview = 'Date';
  @ViewChild(ClickedOutsideDirective)
  myDir;
  popupVisible = false;
  isPopupReady = false;
  @Input()
  autoClosedAfter: number;
  public date1 = null;
  public date2 = null;
  public maxdate = null;
  public mindate = null;
  onChanged: () => any;
  onTouched: () => any;

  // initialisation avec récuparation du dom du composant
  constructor(private _elementRef: ElementRef) {}

  ngOnInit() {}

  writeValue(obj): void {
    // this.dates = obj;
    // this.datesChange.emit([
    //   this.date1 ? this.date1 : null,
    //   this.date2 ? this.date2 : null
    // ]);
  }
  registerOnChange(fn: any): void {
    this.onChanged = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  ngAfterViewInit() {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['placeholder'] && changes['placeholder'].currentValue) {
      this.textPreview = this.placeholder;
    }
    if (changes['dates'] && changes['dates'].currentValue !== undefined) {
      if (this.dates === null) {
        this.textPreview = this.placeholder;
        return;
      }
      this.date1 = this.dates ? this.dates[0] : null;
      this.date2 = this.dates ? this.dates[1] : null;
      this.maxdate = this.date1;
      this.mindate = this.date2;
    }
  }

  // écoute des événements pour auto fermer la popup
  @HostListener('document:click', ['$event'])
  onClick(event: Event): void {
    const htmlElementTarget = <HTMLElement>event.target;
    const slider = this._elementRef.nativeElement.querySelector('.popup-date');

    if (slider && !slider.contains(event.target) && this.isPopupReady) {
      if (
        htmlElementTarget.closest('mat-datepicker-content') ||
        htmlElementTarget.closest('table.mat-calendar-table')
      ) {
        event.preventDefault();
        event.stopPropagation();
      } else {
        this.onTogglePopup(event);
      }
    }
  }

  // toogle de status de visiblité de popup
  onTogglePopup(event?) {
    if (this.popupVisible) {
      this.popupVisible = false;
      this.isPopupReady = false;
    } else {
      this.popupVisible = true;
      setTimeout(() => {
        this.isPopupReady = true;
      }, 200);
    }
  }

  // conversion d'une date en string au format DD/MM/YY
  getDateString(date) {
    const dateObject = new Date(date);
    return (
      (dateObject.getDate() < 10
        ? '0' + dateObject.getDate()
        : dateObject.getDate()) +
      '/' +
      (dateObject.getMonth() + 1 < 10
        ? '0' + (dateObject.getMonth() + 1)
        : dateObject.getMonth() + 1) +
      '/' +
      (dateObject.getFullYear() + '').slice(-2)
    );
  }

  // rafraichissement du texte de prévisualisation
  refreshPreview() {
    if (this.date2 === null && this.date1 === null) {
      this.textPreview = this.placeholder;
      return;
    }
    let string = '';
    if (this.date1 !== null) {
      string += this.getDateString(this.date1);
    }

    if (this.date2 !== null) {
      if (string !== '') {
        string += ' au ';
      } else {
        string += "Jusqu'au ";
      }
      string += this.getDateString(this.date2);
    } else {
      if (string !== '') {
        string = 'A partir du ' + string;
      }
    }

    this.datesChange.emit([
      this.date1 ? this.date1 : null,
      this.date2 ? this.date2 : null
    ]);

    this.textPreview = string;
    this.myDir.resumeOverDetection();
  }

  hasLeft(el) {
    if (this.popupVisible) {
      this.onTogglePopup();
    }
  }
}
