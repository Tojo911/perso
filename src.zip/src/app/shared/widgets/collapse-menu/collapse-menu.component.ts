import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-collapse-menu',
  templateUrl: './collapse-menu.component.html',
  styleUrls: ['./collapse-menu.component.scss']
})
export class CollapseMenuComponent {
  @Input()
  title: string;
  @Input()
  disabled: string;
  @Input()
  icon: string;
  public showPanel = true;

  constructor() { }

}
