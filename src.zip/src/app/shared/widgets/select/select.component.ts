import {
  Component,
  Input,
  ViewChild,
  EventEmitter,
  Output,
  ChangeDetectionStrategy,
  forwardRef,
  ViewEncapsulation,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { ModelOption } from '../../../models/option-model';
/**
 * Composant Select
 * @param value	valeur selectionné par défaut
 * @param list tableau d'options envoyé directement au composant matérial mat-option
 * @param placeholder (optionnel) valeur affiché si aucunes valeur de sélectionnée
 * @param label (optionnel)	affichage d'un label au mpême principe que dans les inputs
 * @param description (optionnel) affichage d'une description au mpême principe que dans les inputs
 * @param multiple (optionnel) option pour autoriser le multi choix
 *
 * @Output valueChange two-way binding pour la valeur "value" avec possiblité de n'écouter que le retour.
 */
@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => SelectComponent)
    }
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.Emulated
})
export class SelectComponent implements ControlValueAccessor, OnChanges {
  @Input()
  value: ModelOption = null;
  @Input()
  forced: ModelOption = null;
  @Input()
  list: ModelOption[] = null;
  @Input()
  placeholder: string;
  @Input()
  label: string = null;
  @Input()
  description: string = null;
  @Input()
  multiple = false;
  @Input()
  direction: string;
  @Input()
  preset;
  @Input()
  autoClosedAfter: number;
  @Output()
  valueChange = new EventEmitter<string>();
  @ViewChild('formField')
  formField;
  @ViewChild('select')
  select;
  onChange = (_: any) => {};
  onTouched = (_: any) => {};

  ngOnChanges(changes: SimpleChanges) {
    if (this.list) {
      if (
        this.list.length > 0 &&
        this.preset &&
        (!this.value || !this.getListValue(this.value))
      ) {
        if (
          this.list.length > 0 &&
          this.preset &&
          (!this.value || !this.getListValue(this.value))
        ) {
          this.onUpdateValue(this.getPresetValue());
        }
      }
    }

    if (changes['value'] && this.getListValue(changes['value'].currentValue)) {
      this.value = this.getListValue(changes['value'].currentValue);
    }
  }
  getListValue(val) {
    if (!val) {
      return null;
    }
    const res = this.list.find(
      it => val.value === it.value || val.libelle === it.libelle
    );
    if (res) {
      return res;
    } else {
      return null;
    }
  }
  getPresetValue() {
    const res = this.list.find(
      it => this.preset === it.value || this.preset === it.libelle
    );
    if (res) {
      return res;
    } else {
      return this.list[0];
    }
  }

  onUpdateValue(item) {
    this.value = item;
    this.onChange(item);
    this.valueChange.emit(item);
  }

  getPlaceHolder() {
    if (this.value === null || this.value === undefined) {
      return this.placeholder;
    } else {
      return '';
    }
  }

  writeValue(value: any): void {
    if (this.value) {
      this.value = value;
    }
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
}
