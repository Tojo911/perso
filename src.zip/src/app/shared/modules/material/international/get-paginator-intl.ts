import { MatPaginatorIntl } from '@angular/material';

export class GetPaginatorIntl {
  constructor() {
    const paginatorIntl = new MatPaginatorIntl();
    paginatorIntl.itemsPerPageLabel = 'Nbr d\'élements par page:';
    paginatorIntl.nextPageLabel = null;
    paginatorIntl.previousPageLabel = null;
    // paginatorIntl.getRangeLabel = (page: number, pageSize: number, length: number) => (page + 1) + ' ' + pageSize + ' ' + length ;
    return paginatorIntl;
  }
}
