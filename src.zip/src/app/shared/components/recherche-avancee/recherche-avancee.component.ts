import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { ModelOption } from '../../../models/option-model';
import { Perimetre } from '../../../models/perimetre';
import { AuthService } from '../../../services/auth/auth.service';
import { DdfService } from '../../../services/ddf/ddf.service';
import {
  CritereRechercheInfo,
  CriteresModelToMap
} from '../../../models/critere-recherche-info';
import { map } from 'rxjs/internal/operators/map';
import { RechercheService } from '../../../services/recherche/recherche.service';
import { ItemTableInfo } from '../../../models/item-table-info';
import { TranslateService } from '@ngx-translate/core';
import * as globalFunc from '../../../models/global-functions';
import { SirenFormatter } from '../../../classes/inputFormatter/sirenFormatter';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { AmountFormatter } from '../../../classes/inputFormatter/amountFormatter';
import { DossierInfo } from '../../../models/dossier-info';
import { HomeTabEnum } from '../../../models/enums/home-tab.enum';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-recherche-avancee',
  templateUrl: './recherche-avancee.component.html',
  styleUrls: ['./recherche-avancee.component.scss']
})
export class RechercheAvanceeComponent implements OnInit, OnChanges {
  @Input()
  selectedTabIndex: number;
  @Input()
  status: ModelOption[];

  public datasource: ItemTableInfo[];
  @Input()
  public perimetre: Perimetre;
  @Input()
  public perimetres: Perimetre[];
  public showSpinner: boolean;
  public hasResultData: boolean;
  public criteresModel: CriteresModelToMap = new CriteresModelToMap();

  public sirenFormat = new SirenFormatter();
  public amountFormat = new AmountFormatter();
  public HomeTabEnum = HomeTabEnum;
  public validForm = false;
  searchForm: FormGroup; // = new FormGroup({});
  @Output()
  emitCritereSearchModel: EventEmitter<CritereRechercheInfo> = new EventEmitter<
    CritereRechercheInfo
  >();
  @Output()
  reinitialiseEvent: EventEmitter<void> = new EventEmitter<void>();

  constructor(
    private router: Router,
    private httpClient: HttpClient,
    private authService: AuthService,
    private rechercheService: RechercheService,
    private translateService: TranslateService,
    private fb: FormBuilder
  ) {
    this.searchForm = this.fb.group({
      numeroFL: ['', [Validators.required]],
      numeroSIREN: ['', [Validators.required]],
      raisonSociale: ['', [Validators.required]],
      statut: ['', [Validators.required]],
      dateCreation: ['', [Validators.required]],
      refApporteur: ['', [Validators.required]],
      numAccord: ['', [Validators.required]],
      ekipAgence: ['', [Validators.required]],
      refDossierInterne: ['', [Validators.required]],
      nbLoyerRestant: ['', [Validators.required]]
    });
  }

  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges) {
    if (
      changes['selectedTabIndex'] &&
      changes['selectedTabIndex'].previousValue &&
      changes['selectedTabIndex'].currentValue !==
        changes['selectedTabIndex'].previousValue
    ) {
      this.reinitialiser();
    }
  }

  isCitereEmpty(obj) {
    for (const key in obj) {
      if (obj[key] !== null && obj[key] !== '') {
        return false;
      }
    }
    return true;
  }

  search(index) {
    this.criteresModel.perimetre = this.perimetre ? this.perimetre : undefined;
    this.criteresModel.perimetres = this.perimetres;
    this.criteresModel.phase = this.HomeTabEnum[index];
    this.emitCritereSearchModel.emit(
      new CritereRechercheInfo(this.criteresModel)
    );
  }

  reinitialiser() {
    this.criteresModel = new CriteresModelToMap();
    this.reinitialiseEvent.emit();
    this.criteresModel.dateCreation = null;
    this.criteresModel.dateFinContrat = null;
  }

  isFormValid() {
    for (const key of Object.keys(this.searchForm.controls)) {
      const field = this.searchForm.get(key);
      if (field.errors === null) {
        return true;
      }
    }
  }
}
