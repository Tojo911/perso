import {
  Component,
  OnInit,
  Input,
  Output,
  SimpleChanges,
  OnChanges,
  EventEmitter,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { ModelOption } from '../../../models/option-model';
import { ItemTableInfo } from '../../../models/item-table-info';

import { TableColumnDefinitionModel } from '../../../models/table-column-definition-model';
import { KpiModel } from '../../../models/kpimodel';
import { CritereRechercheInfo, CriteresModelToMap } from '../../../models/critere-recherche-info';
import { RechercheService } from '../../../services/recherche/recherche.service';
import { map } from 'rxjs/internal/operators/map';
import { DossierInfo } from '../../../models/dossier-info';
import { Subscription } from 'rxjs';
import { AuthService } from '../../../services/auth/auth.service';
import { Perimetre } from '../../../models/perimetre';
import { HomeTabEnum } from '../../../models/enums/home-tab.enum';

@Component({
  selector: 'app-phase-data-list',
  templateUrl: './phase-data-list.component.html',
  styleUrls: ['./phase-data-list.component.scss']
})
export class PhaseDataListComponent implements OnInit, OnChanges, OnDestroy {
  @Input()
  title: string;
  @Input()
  isExportAuth: boolean;
  @Input()
  selectedKpiStatut: ModelOption;
  @Input()
  tableColumnsDefinition: TableColumnDefinitionModel[];
  @Input()
  datasource: any;
  @Input()
  statusList: ModelOption[];
  @Input()
  perimetres: Perimetre[];
  @Input()
  statusComList: ModelOption[];
  @Input()
  tabIndex: number;
  @Output()
  reinitialiseClickEvent: EventEmitter<void> = new EventEmitter<void>();
  @Output()
  rowClicked: EventEmitter<any> = new EventEmitter<any>();

  private hasFilterParam = false;
  private dataAux: any[] = undefined;

  public showSearchBox = false;
  public showSearchBlock = false;
  public filterValue;
  public statut_param: ModelOption;
  public statut_com_param: ModelOption;
  public min = 0;
  public max = 1000;
  public montant_param = [this.min, this.max];
  public date_param: any[];
  public showSpinner = false;
  public showAdvancedCriteres = false;
  public expandedSearchPanel = false;
  private searchSubscribe: Subscription;
  @ViewChild('collapsePanel')
  collapsePanel: any;

  constructor(
    private translateService: TranslateService,
    private rechercheService: RechercheService,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnChanges(changes: SimpleChanges) {
    if (changes['datasource'] && changes['datasource'].currentValue) {
      this.dataAux = this.datasource;
    }

    if (
      changes['tabIndex'] &&
      changes['tabIndex'].currentValue !== changes['tabIndex'].previousValue
    ) {
      this.collapsePanel.close();
      this.resetSearch();
    }
    if (
      changes['perimetres'] &&
      changes['perimetres'].currentValue !== changes['perimetres'].previousValue
    ) {
      this.search(new CritereRechercheInfo(CriteresModelToMap.setPerimetres(this.perimetres, HomeTabEnum[this.tabIndex])));
    }
  }

  ngOnInit() {}

  applyFilter(value: string) {
    this.filterValue = value;
  }

  resetSearch() {
    this.filterValue = '';
    this.showSearchBox = false;
    // this.datasource = this.dataAux;
  }

  actionOnClick(item) {
    this.rowClicked.emit(item);
  }

  initialiseData(event) {
    if (this.searchSubscribe) {
      this.searchSubscribe.unsubscribe();
    }
    this.showSpinner = false;
    this.datasource = this.dataAux;
  }

  search(critereModel: CritereRechercheInfo) {
    let filteredList;
    if (critereModel) {
      this.showSpinner = true;
      this.searchSubscribe = this.rechercheService
        .advancedSearch(critereModel)
        .pipe(
          map(res => {
            return (res.content as DossierInfo[]).map(
              item => new DossierInfo(item)
            );
          })
        )
        .subscribe(
          res => {
            console.log('filteredList before map........', res);
            filteredList = res.map(
              (item: DossierInfo) => new ItemTableInfo(item)
            );

            if (filteredList !== undefined) {
              this.datasource = filteredList;
              this.showSpinner = false;
            }
          },
          error => {
            console.log('error');
          }
        );
    }
  }

  ngOnDestroy() {
    if (this.searchSubscribe) {
      this.searchSubscribe.unsubscribe();
    }
  }
}
