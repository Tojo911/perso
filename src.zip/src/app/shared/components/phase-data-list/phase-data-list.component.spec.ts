import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PhaseDataListComponent } from './phase-data-list.component';


describe('PhaseDataList.ComponentComponent', () => {
  let component: PhaseDataListComponent;
  let fixture: ComponentFixture<PhaseDataListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhaseDataListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhaseDataListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
