import {
  Component,
  OnInit,
  Input,
  OnChanges,
  AfterViewInit
} from '@angular/core';
import {
  MatTableDataSource,
  MatSort,
  Sort,
  PageEvent,
  MatPaginator
} from '@angular/material';
import { ViewChild } from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ItemTableInfo } from '../../../models/item-table-info';
import { AfterContentInit } from '@angular/core';
import * as globalFunc from '../../../models/global-functions';
import { TableColumnDefinitionModel } from '../../../models/table-column-definition-model';
import { Observable, of, merge } from 'rxjs';
import { map } from 'rxjs/internal/operators/map';
import { ElementRef } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnChanges, OnInit, AfterViewInit {
  @Input()
  source: any[];
  @Input()
  selected: () => {};
  @Input()
  noPagination: boolean;
  @Input()
  loading: boolean;
  @Input()
  dynamicColumns: TableColumnDefinitionModel[];
  @Input()
  filterValue: string;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @Output()
  rowClicked = new EventEmitter();
  @Output()
  rowDblClicked = new EventEmitter();
  @Output()
  sourceChange = new EventEmitter();

  public dataIsReady = false;
  public colsDefIsReady = false;
  public pageEvent: PageEvent;
  public displayedColumns: any[];
  public datasource = new MatTableDataSource<any>();

  constructor() {}

  ngOnChanges(changes: SimpleChanges) {
    if (changes['source'] && changes['source'].currentValue) {
      this.dataIsReady = true;
      this.datasource = new MatTableDataSource(
        changes['source'].currentValue.slice(0, 99)
      );
      this.datasource.paginator = this.paginator;

    }

    if (changes['dynamicColumns'] && changes['dynamicColumns'].currentValue) {
      this.colsDefIsReady = true;
      this.displayedColumns = this.dynamicColumns.map(row => row.columnDef);
    }

    if (
      changes['filterValue'] &&
      changes['filterValue'].currentValue !==
      changes['filterValue'].previousValue
    ) {
      this.datasource.filter = this.filterValue.trim().toLowerCase();
    }
  }

  ngOnInit() {}

  ngAfterViewInit() {
    this.datasource.sort = this.sort;
  }
  _onRowClicked(row) {
    this.rowClicked.emit(row);
  }
  _onRowDblClicked(row) {
    this.rowDblClicked.emit(row);
  }

  itemBeenRead(item) {
    item.new = false;
  }

  getColumnValue(column: TableColumnDefinitionModel, row: any) {
    if (column.date) {
      return globalFunc.mapTimestampToDate(column.cell(row));
    }
    return column.cell(row);
  }

  compareFunction(a: string, b: string) {
    if (!isNaN(+a) && !isNaN(+b)) {
      return +a < +b ? -1 : 1;
    }
    return a.toLowerCase() < b.toLowerCase() ? -1 : 1;
  }

  compare(a: string, b: string, d: string) {
    return this.compareFunction(a, b) * (d === 'asc' ? 1 : -1);
  }

  sortData(sort: Sort) {
    const data = this.datasource.data.slice();
    if (!sort.active || sort.direction === '') {
      this.datasource.data = data;
      return;
    }

    for (const element of this.dynamicColumns) {
      if (sort.active === element.columnDef) {
        this.datasource.data = data.sort((a, b) => {
          return this.compare(element.cell(a), element.cell(b), sort.direction);
        });
        break;
      }
    }
  }
}
