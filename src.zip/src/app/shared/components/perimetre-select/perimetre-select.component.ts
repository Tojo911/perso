import {
  Component,
  Input,
  OnInit,
  OnChanges,
  HostListener,
  ViewChild,
  AfterViewInit,
  ViewChildren,
  ElementRef,
  QueryList
} from '@angular/core';
import {
  trigger,
  style,
  transition,
  animate,
  group
} from '@angular/animations';
import { log } from 'util';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { PerimetreService } from '../../../services/perimetre/perimetre.service';
import { ClickedOutsideDirective } from '../../../directives/clicked-outside.directive';
import { Perimetre } from '../../../models/perimetre';
import { MatOptionSelectionChange, MatPseudoCheckbox } from '@angular/material';

// FIXME: move interface into one model
export interface PerimetreItem {
  name?: string;
  type?: string;
  id?: string;
  perimetre: Perimetre;
  children: any[];
}
@Component({
  selector: 'app-perimetre-select',
  templateUrl: './perimetre-select.component.html',
  styleUrls: ['./perimetre-select.component.scss'],
  animations: [
    trigger('itemAnim', [
      transition('* => enter', [
        style({ transform: 'translateX(100%)' }),
        animate(200)
      ]),
      transition('* => leave', [
        style({ transform: 'translateX(-100%)' }),
        animate(200)
      ])
    ])
  ]
})
export class PerimetreSelectComponent
  implements OnInit, OnChanges, AfterViewInit {
  @Input()
  isFullRange: boolean;
  @Input()
  multiple: boolean;
  @Input()
  label = '';
  @Input()
  items: any[];
  @Input()
  value = '';
  @Input()
  placeholder = '';
  @Input()
  perimetre: Perimetre;
  @Input()
  perimetres: Perimetre[];
  @Output()
  perimetreChange = new EventEmitter<any>();
  @Output()
  perimetresChange = new EventEmitter<any>();
  @Output()
  valueChange = new EventEmitter<string>();
  @ViewChild('select')
  select;
  @ViewChild(ClickedOutsideDirective)
  dirs;
  currentItems: any[];
  @ViewChildren('links', { read: ElementRef })
  connectors: QueryList<ElementRef>;
  @ViewChildren(MatPseudoCheckbox)
  checkBoxs: QueryList<MatPseudoCheckbox>;
  public focusComp = [];
  public focusCheckBox = [];
  lastItem: any;
  public search: string;
  public aux: any[];
  public list = [];
  public direction = '';
  public isSingle = false;
  public singleValue: string;
  public model = {};
  public lastList = [];
  public lastItems = [];
  public defaultPerimetre: Perimetre;
  public setToPerimetre = true;
  public typePerimetre;
  public selectedPerimetres: Perimetre[] = [];
  public lastEmittedPerimeter: Perimetre[] = [];
  public isLoading = true;
  constructor(private perimetreService: PerimetreService) {
    this.typePerimetre = { type: perimetreService.MARCHES };

    setTimeout(async () => {
      await this.connectors.changes.subscribe(con => {
        this.focusComp = con._results ? con._results : [];
        this.dirs.compList = [...this.dirs.compList, ...this.focusComp];
      });
      await this.checkBoxs.changes.subscribe(con => {
        this.focusCheckBox = con._results ? con._results : [];
        this.dirs.compList = [...this.dirs.compList, ...this.focusCheckBox];
      });
    }, 800);
  }
  ngAfterViewInit() {
    this.select.open();
    setTimeout(() => {
      this.select.close();
      this.isLoading = false;
    }, 1500);
  }
  set(ref, tar) {
    ref = [...tar];
    /*ref.splice(0, ref.length);
    tar.forEach(it => ref.push(it));*/
  }
  ngOnInit() {
    if (this.multiple) {
      this.select.multiple = true;
    }
    this.defaultPerimetre = this.perimetre;
    this.perimetre = {};
    this.model = localStorage.getItem('organisation')
      ? JSON.parse(localStorage.getItem('organisation'))
      : {};
    this.loadChild({ type: this.perimetreService.MARCHES });
  }
  async onBlur($event) {
    if (!this.select.panelOpen) {
      // this.select.open();
      this.currentItems = this.lastItems;
      this.resetSearch();
      this.goToselectedValue();
      this.setValueForMultipleOption();
      setTimeout(this.select.close(), 2800);
    }
    if (this.multiple) {
      if (
        this.isPerimetreDifferent(
          this.lastEmittedPerimeter,
          this.selectedPerimetres
        )
      ) {
        this.perimetresChange.emit(
          this.perimetreService.computePerimetre(this.selectedPerimetres)
        );
        this.lastEmittedPerimeter = this.selectedPerimetres;
      }
    }
  }
  isPerimetreDifferent(array1, array2) {
    let flag = false;
    array1.forEach(it => {
      if (array2.filter(item => it.id === item.id).length === 0) {
        flag = true;
      }
    });
    array2.forEach(it => {
      if (array1.filter(item => it.id === item.id).length === 0) {
        flag = true;
      }
    });
    return flag;
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes['items']) {
      if (this.isSingleton(this.items)) {
        this.isSingle = true;
        this.value = this.getSingleValue(this.items);
      }
      this.aux = this.items;
    }
  }
  filterList() {
    if (!this.search || this.search === '') {
      this.items = this.currentItems;
    }
    this.items = this.currentItems.filter(
      it =>
        it.name.toLocaleLowerCase().indexOf(this.search.toLocaleLowerCase()) >
        -1
    );
  }
  selectRange(item) {
    if (this.isFullRange) {
      this.setRef(item);
      this.onUpdatePerimetre(item);
    } else {
      this.animate(item);
    }
  }
  isSingleton(item: Perimetre[]) {
    if (item.length === 0) {
      this.list.pop();
      return true;
    } else if (item.length > 1) {
      return false;
    } else {
      this.list = [...this.list, item[0]];
      return this.isSingleton(item[0].children);
    }
  }

  getSingleValue(items: Perimetre[]): string {
    // FIXME: try to add Enumeration for string
    if (items[0].type === 'vendeur') {
      return items[0].name;
    } else {
      return this.getSingleValue(items[0].children);
    }
  }

  async animate(item, reset?) {
    this.resetSearch();
    this.list.push(item);
    await this.loadChild(item);
    // }

    this.items = [];
    this.direction = 'enter';
  }

  searchItem(item: any) {
    this.resetSearch();
    this.direction = 'leave';
    this.isSingle = false;
    if (this.list.length === 1) {
      this.list = this.list.slice(0, this.list.indexOf(item));
      this.ngOnInit();
    } else {
      this.list = this.list.slice(0, this.list.indexOf(item) + 1);
      this.items = [];
      this.loadChild(item);
    }
  }

  public onUpdatePerimetre(item?: any) {
    if (!this.perimetre) {
      this.perimetre = {};
    }
    if (item) {
      if (item.type === this.perimetreService.VENDEUR) {
        this.perimetre.vendeur = item.id;
      } else if (item.type === this.perimetreService.VENDEURS) {
        this.perimetre.agence = item.id;
        delete this.perimetre.vendeur;
      } else if (item.type === this.perimetreService.AGENCES) {
        this.perimetre.apporteur = item.id;
        delete this.perimetre.agence;
        delete this.perimetre.vendeur;
      } else if (item.type === this.perimetreService.APPORTEURS) {
        this.perimetre.marche = item.id;
        delete this.perimetre.apporteur;
        delete this.perimetre.agence;
        delete this.perimetre.vendeur;
      }
    }
    console.log('update du perimetre');
    this.perimetreChange.emit(
      this.multiple ? this.selectedPerimetres : this.perimetre
    );
    this.onUpdateValue(item.name);
  }
  public onUpdateValue(name: any) {
    this.value = name;

    this.valueChange.emit(this.value);
    // this.perimetreChange.emit(this.perimetre);
  }
  setValueForMultipleOption() {
    if (this.multiple) {
      console.log('select:' + this.select.value);
      const listCommonItem = this.items.filter(it =>
        this.selectedPerimetres.find(res => res.id === it.id)
      );
      if (listCommonItem && listCommonItem.length > 0) {
        this.select.value = listCommonItem.map(perim => perim.name);
      }
      console.log('select after multiple check:' + this.select.value);
    }
  }
  getPlaceHolder() {
    if (this.value === '' || this.value === undefined) {
      return this.placeholder;
    } else {
      return '';
    }
  }
  async loadChild(ref?: Perimetre) {
    switch (ref.type) {
      case this.perimetreService.AGENCES:
        this.perimetre.apporteur = ref.id;
        await this.perimetreService
          .getAgences(this.perimetre)
          .subscribe(it =>
            this.setItems(it, this.perimetreService.VENDEURS, ref)
          );
        break;
      case this.perimetreService.APPORTEURS:
        this.perimetre = { marche: ref.id };
        await this.perimetreService
          .getApporteurs(ref.id)
          .subscribe(it =>
            this.setItems(it, this.perimetreService.AGENCES, ref)
          );
        break;
      case this.perimetreService.VENDEURS:
        this.perimetre.agence = ref.id;
        await this.perimetreService
          .getVendeurs(this.perimetre)
          .subscribe(it =>
            this.setItems(it, this.perimetreService.VENDEUR, ref)
          );
        break;
      case this.perimetreService.MARCHES:
        this.perimetreService
          .getMarches()
          .subscribe(it =>
            this.setItems(it, this.perimetreService.APPORTEURS, ref)
          );
        break;
      default:
        console.log(ref);
        break;
    }
  }
  setItems(it, perimetre, ref) {
    this.items = (it.content as any[]).map(item => {
      return this.setPerimetre(item, perimetre, it);
    });
    if (!this.model[perimetre]) {
      this.model[perimetre] = {};
    }
    if (ref.id) {
      this.model[perimetre][ref.id] = this.items;
    } else {
      this.model[perimetre] = this.items;
    }
    this.currentItems = this.items;
    localStorage.setItem('organisation', JSON.stringify(this.model));
    const defaultVal = this.matchWithPerimetre([this.defaultPerimetre]);
    this.setValueForMultipleOption();
    if (this.setToPerimetre && defaultVal) {
      if (perimetre === this.perimetreService.VENDEUR) {
        this.perimetre = this.defaultPerimetre;
        this.value = defaultVal.map(perim => perim.name).join(',');
        if (this.multiple) {
          this.selectedPerimetres = defaultVal;
          this.setValueForMultipleOption();
        } else {
          this.select.value = defaultVal[0].name;
        }
        this.lastItem = defaultVal;
        this.lastList = this.list;
        this.lastItems = this.items;
        this.setToPerimetre = false;
      } else {
        this.animate(defaultVal[0]);
      }
    } else if (this.items.length === 1 && !this.isFullRange) {
      if (perimetre === this.perimetreService.VENDEUR) {
      } else {
        this.animate(this.items[0]);
      }
    }
  }
  setPerimetre(input: any, groupe, list) {
    return groupe === this.perimetreService.VENDEUR
      ? {
          name: input.nom + ' ' + input.prenom,
          type: groupe,
          id: input.id,
          perimetre: input,
          items: list
        }
      : {
          name: input.libelle,
          type: groupe,
          id: input.id,
          children: [1],
          perimetre: input,
          items: list
        };
  }
  selectedPerimeter(item) {
    this.value = item.name;
  }
  perimetreYetSetted() {
    return this.perimetre ? this.matchWithPerimetre([this.perimetre]) : false;
  }
  goToselectedValue() {
    if (this.lastList.length > 0 && this.lastItems.length > 0 ) {
      this.list = this.lastList;
      this.items = this.lastItems;
    }
  }
  matchWithPerimetre(perimetres: Perimetre[]) {
    return this.items.filter(
      it =>
        perimetres.filter(
          perimetre =>
            perimetre.agence === it.id ||
            perimetre.apporteur === it.id ||
            perimetre.vendeur === it.id ||
            perimetre.marche === it.id
        ).length > 0
    );
  }

  setRef(item) {
    this.resetSearch();
    if (!this.multiple) {
        this.lastItems = this.items;
        this.lastItem = item;
        this.lastList = this.list.map(it => it);
    }
  }
  resetSearch() {
    this.search = '';
    this.items = this.currentItems;
  }
  selected(event: MatOptionSelectionChange, item) {
    if (this.multiple && event.source.selected) {
      this.selectedPerimetres.push(item.perimetre);
      this.lastItems = this.items;
        this.lastItem = item;
        this.lastList = this.list.map(it => it);
    } else {
      this.selectedPerimetres = this.selectedPerimetres.filter(
        it => it.id !== item.perimetre.id
      );
    }
    // this.select.value = this.matchWithPerimetre(this.selectedPerimetres).map(perim => perim.name);
    console.log(JSON.stringify(this.selectedPerimetres));
  }
}
