import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { IAppConfig, EnvIAppConfig } from '../../../models/config/iapp-config';

@Injectable()
export class LoadConfigurationService {
  public static URL_BACKEND: string;
  public static SECURITY_DOMAIN: string;
  public static URL_BACKEND_KEY = 'URL_BACKEND';
  public static SECURITY_DOMAIN_KEY = 'SECURITY_DOMAIN';
  public static CURRENT_USER = 'currentUser';
  public static DATA = 'data';
  static environnement: string;
  static envVar: IAppConfig;

  constructor(private http: HttpClient) {}

  private config: Object = null;
  private env: Object = null;

  geturlBackEnd() {
    if (!LoadConfigurationService.URL_BACKEND) {
      LoadConfigurationService.URL_BACKEND = localStorage.getItem(
        LoadConfigurationService.URL_BACKEND_KEY
      );
      console.log(LoadConfigurationService.URL_BACKEND);
    }
    return LoadConfigurationService.URL_BACKEND;
  }
  setVarEnv() {
    console.log('loading var env...');
    LoadConfigurationService.URL_BACKEND = LoadConfigurationService.envVar
      .enableProxy
      ? ''
      : LoadConfigurationService.envVar.urlBackend +
        LoadConfigurationService.envVar.contextBackend;
    LoadConfigurationService.SECURITY_DOMAIN =
      LoadConfigurationService.envVar.domain;
      localStorage.setItem(
        LoadConfigurationService.URL_BACKEND_KEY,
        LoadConfigurationService.URL_BACKEND
      );
      localStorage.setItem(
        LoadConfigurationService.SECURITY_DOMAIN_KEY,
        LoadConfigurationService.SECURITY_DOMAIN
      );
    console.log('loading var env...');
  }
  /**
   * Use to get the data found in the second file (config file)
   */
  public getConfig(key: any) {
    return this.config[key];
  }

  /**
   * Use to get the data found in the first file (env file)
   */
  public getEnv(key: any) {
    return this.env[key];
  }

  /**
   * This method:
   *   a) Loads "env.json" to get the current working environment (e.g.: 'production', 'development')
   *   b) Loads "config.[env].json" to get all env's variables (e.g.: 'config.development.json')
   */
  public load() {
    if (!LoadConfigurationService.envVar) {
      return this.http
        .get('assets/config/config.json')
        .pipe(
          map(res => {
            try {
              LoadConfigurationService.envVar = res[
                environment.env
              ] as IAppConfig;
              this.setVarEnv();
              if (!LoadConfigurationService.envVar) {
                console.error('Could not load environnement variable');
              }
            } catch (e) {
              console.error('Could not load environnement variable');
            }
          })
        )
        .subscribe(envResponse => {});
    }
  }
}
