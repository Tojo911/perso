import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { LoadConfigurationService } from '../load-configuration/load-configuration.service';

@Injectable()
export class RequesterService {
  public CONTENT_TYPE_JSON = 'application/json';
  public CONTENT_MULTIPART = 'multipart/form-data';
  public DEFAULT_ACCEPT = 'application/json, text/plain';
  public BEARER = 'Bearer ';

  constructor(
    private http: HttpClient,
    private lconfService: LoadConfigurationService
  ) {}

  request(api, datas, isMultipart?) {
    return this.http.request(
      this.getHttpMethod(api),
      this.getEndpoint(
        api,
        this.lconfService.geturlBackEnd()
      ),
      this.buildRequestOptions(datas, isMultipart)
    );
  }
  // Build request http options
  buildRequestOptions(datas, isMultipart?) {
    // Get user Token
    const cUser = JSON.parse(
      localStorage.getItem(LoadConfigurationService.CURRENT_USER)
    );
    const token = cUser && cUser.token ? cUser.token : null;
    // Get Request Body
    const body = datas && datas.body ? datas.body : null;
    // Get query params
    const params = datas && datas.params ? datas.params : null;
    // Build Request Option
    let headers = new HttpHeaders();
    headers = headers.append('Authorization', this.BEARER + token);
    if (!isMultipart) {
      headers = headers.append ('Content-Type', this.CONTENT_TYPE_JSON);
    }
    const httpOptions = {
      headers: headers,
      body: body,
      params: params
    };
    return httpOptions;
  }

  // Get the Http method name
  getHttpMethod(api) {
    return api.method || 'GET';
  }

  getEndpoint(api, urlBackend) {
    return urlBackend + api.url;
  }
}
