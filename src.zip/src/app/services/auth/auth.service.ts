import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { LoadConfigurationService } from '../../shared/services/load-configuration/load-configuration.service';
import { UtilsService } from '../../shared/services/utils/utils.service';
import { Perimetre } from '../../models/perimetre';
import { environment } from '../../../environments/environment';
import { UserInfo, MarcheInfos } from '../../models/ddf';

export class UserToken {
  token: string;
}

@Injectable()
export class AuthService {
  public AUTH_API_URL = '/flashlease/api/auth/login';
  public token: string;
  public userTokenInfo: UserInfo = {};
  private jwt = new JwtHelperService();
  constructor(private http: RequesterService, private router: Router) {
    // const currentUser = JSON.parse(
    //   localStorage.getItem(LoadConfigurationService.CURRENT_USER)
    // );
    // this.token = currentUser && currentUser.token;

    this.token = this.getCurrentUserToken();
    if (this.token) {
      this.userTokenInfo = this.jwt.decodeToken(this.token);
    }
  }

  login(username: string, password: string): Observable<boolean> {
    console.log('auth service login');

    const datas = {
      body: JSON.stringify({
        username: username,
        password: password,
        domain: LoadConfigurationService.SECURITY_DOMAIN
      })
    };

    const api = UtilsService.buildApi('POST', this.AUTH_API_URL);

    return this.http.request(api, datas).pipe(
      map((data: UserToken) => {
        const token = data && data.token;
        if (token) {
          this.token = token;
          localStorage.setItem(
            LoadConfigurationService.CURRENT_USER,
            JSON.stringify({ username: username, token: token })
          );
          if (this.token) {
            this.userTokenInfo = this.jwt.decodeToken(this.token);
            console.log('user Info........    ', this.userTokenInfo);
          }
          return true;
        } else {
          return false;
        }
      })
    );
  }

  logout(): void {
    this.token = null;
    localStorage.removeItem(LoadConfigurationService.CURRENT_USER);
    localStorage.removeItem(LoadConfigurationService.DATA);
    this.router.navigate(['/login']);
  }

  // check if user is logged and jwt is not expired
  isLogged(): boolean {
    const jwt = new JwtHelperService();
    const token = this.getCurrentUserToken();
    if (token && !jwt.isTokenExpired(token)) {
      return true;
    }
    return false;
  }

  // get user data (payload) from jwt
  getCurrentUser() {
    const jwt = new JwtHelperService();
    const token = this.getCurrentUserToken();
    if (token) {
      return jwt.decodeToken(token) as UserInfo;
    }
    return false;
  }

  // get jwt from localStorage
  getCurrentUserToken(): any {
    const cu = JSON.parse(
      localStorage.getItem(LoadConfigurationService.CURRENT_USER)
    );
    if (cu && cu.token) {
      return cu.token;
    }
    return false;
  }

  // get user data from JWT payload by key
  getUserDataByKeyFromJWTPayload(key: string): any {
    const token = this.getCurrentUser();

    if (token && token.hasOwnProperty(key)) {
      return token[key];
    }
    return false;
  }
  // get user data from JWT payload by key
  getUserDataByKeyFromJWTPayloadObject(key: string): any {
    return JSON.parse(this.getUserDataByKeyFromJWTPayload(key));
  }

  getPerimetreFromToken() {
    const perimetre: Perimetre = {};
    perimetre.marche = JSON.parse(this.userTokenInfo.marche as string).oid;
    perimetre.apporteur = JSON.parse(this.userTokenInfo
      .apporteur as string).oid;
    perimetre.agence = JSON.parse(this.userTokenInfo.agence as string).oid;
    perimetre.vendeur = this.userTokenInfo.id;

    perimetre.marcheDetails = JSON.parse(this.userTokenInfo.marche as string);
    perimetre.apporteurDetails = JSON.parse(this.userTokenInfo
      .apporteur as string);
    perimetre.agenceDetails = JSON.parse(this.userTokenInfo.agence as string);
    perimetre.vendeurDetails = JSON.parse(this.userTokenInfo.vendeur as string);

    return perimetre;
  }
  getAuthorities() {
    const res = this.getUserDataByKeyFromJWTPayload('authorities');
    return res ? res : [] ;
  }
  getRoles() {
    return this.getUserDataByKeyFromJWTPayload('roles');
  }
  isAuthDdf() {
    return this.getAuthorities().filter(it => it === 'ROLE_etu_cre').length > 0
      ? true
      : false;
  }
  isDashMontage() {
    return this.getAuthorities().filter(it => it === 'ROLE_vp_sta_dos').length > 0
      ? true
      : false;
  }
  isDashExportExcel() {
    return this.getAuthorities().filter(it => it === 'ROLE_vp_lis_tra').length > 0
      ? true
      : false;
  }
  isDashParc() {
    return this.getAuthorities().filter(it => it === 'ROLE_por_edp').length > 0
      ? true
      : false;
  }
  isAuthSuiviDossier() {
    return this.getAuthorities().filter(it => it === 'ROLE_pil_sta').length > 0
      ? true
      : false;
  }
  isInterne() {
    return this.getRoles().filter(it => it === 'INTERNE').length > 0
      ? true
      : false;
  }
  isDev() {
    return environment.env === 'dev';
  }
  isProd() {
    return environment.env === 'prod';
  }
}
