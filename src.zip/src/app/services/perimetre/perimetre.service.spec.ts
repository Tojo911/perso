import { TestBed, inject } from '@angular/core/testing';

import { PerimetreService } from './perimetre.service';

describe('PerimetreService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PerimetreService]
    });
  });

  it('should be created', inject([PerimetreService], (service: PerimetreService) => {
    expect(service).toBeTruthy();
  }));
});
