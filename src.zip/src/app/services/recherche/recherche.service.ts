import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { DossierInfo } from '../../models/dossier-info';

@Injectable({ providedIn: 'root' })
export class RechercheService {
  private API_SEARCH_ADVANCED_URL = `/flashlease/api/search/advanced`;
  private API_SEARCH_QUICK_URL = `/flashlease/api/search/quick/`;
  private emitter: any;
  public storage: Observable<any> = new Observable<any>(
    e => (this.emitter = e)
  );

  constructor(private http: RequesterService) {}

  sendStorage(data: any) {
    if (this.emitter) {
      this.emitter.next(data);
    }
  }

  clearStorage() {
    //   this.storage.next();
  }

  // getStorage(): Observable<any> {
  //   return this.storage.asObservable();
  // }

  advancedSearch(critere): Observable<any> {
    console.log(critere);
    const api = { method: 'POST', url: this.API_SEARCH_ADVANCED_URL };
    return this.http.request(api, { body: critere }).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  quickSearch(critere): Observable<any> {
    const api = { method: 'GET', url: this.API_SEARCH_QUICK_URL + critere };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }
}
