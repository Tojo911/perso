import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MockService {
  private env: string;
  constructor() {
    this.env = environment.env;
  }

  isDev() {
    return this.env === 'dev';
  }

  isProd() {
    return this.env === 'prod';
  }


}
