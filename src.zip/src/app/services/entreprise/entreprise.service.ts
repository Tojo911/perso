import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Router } from '@angular/router';

import { AuthService } from '../auth/auth.service';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { RequesterService } from '../../shared/services/requester/requester.service';

@Injectable({
  providedIn: 'root'
})
export class EntrepriseService {

  public ENT_API_URL = `/flashlease/api/entreprise/`;

  constructor(private http: RequesterService, private authService: AuthService) {}

  getEntreprise(siren: string): Observable<any> {

    const api = { method: 'GET', url: this.ENT_API_URL + siren};
    return this.http.request(api, null).pipe(
      map(data => ({
        content: data
      }))
    );
  }
}
