import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Router } from '@angular/router';

import { AuthService } from '../auth/auth.service';

import { Observable, BehaviorSubject } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { RequesterService } from '../../shared/services/requester/requester.service';
import { CatalogueService } from '../catalogue/catalogue.service';
import { MaterielService } from '../materiel/materiel.service';
import { ValidationErrors } from '@angular/forms';
import { HttpRequest } from '@angular/common/http';
import { Perimetre } from '../../models/perimetre';

@Injectable({
  providedIn: 'root'
})
export class DdfService {
  public DDF_API_CREATE_URL = '/flashlease/api/ddf/create';
  public DDF_API_URL = `/flashlease/api/ddf/`;
  public DDF_API_VALID = `/flashlease/api/ddf/validate`;
  public DDF_API_LIST_URL = `/flashlease/api/ddf/list`;
  public DDF_API_TICKET_STATUS_URL = '/flashlease/api/kpi/ddf';
  public DDF_API_DOSSIERS_MONTAGE_LIST_URL = '/flashlease/api/montage/list';
  public DDF_API_KPI_DOSSIERS_MONTAGE_URL = '/flashlease/api/kpi/montage';
  public DDF_API_KPI_SUIVI_PARC_URL = '/flashlease/api/kpi/affaires';
  public DDF_API_SUIVIS_PARC_LIST_URL = '/flashlease/api/affaires/list';
  public DDF_API_BASE_URL = '/flashlease/api/';
  public DDF_API_KPI_BASE_URL = '/flashlease/api/kpi/';

  public DDF_ACCORD_LIST_URL = '/flashlease/api/ddf/accords/';
  public DDF_ETUDE_LIST_URL = '/flashlease/api/ddf/etudes/';
  public DDF_REFUS_LIST_URL = '/flashlease/api/ddf/refuses/';
  public DDF_EXPIRE_LIST_URL = '/flashlease/api/ddf/expires/';

  public MONTAGE_PAYES_LIST_URL = '/flashlease/api/montage/payes/';
  public MONTAGE_ENTRAITEMENT_LIST_URL =
    '/flashlease/api/montage/entraitement/';
  public MONTAGE_RECUS_LIST_URL = '/flashlease/api/montage/recus/';
  public MONTAGE_ENANOMALIE_LIST_URL = '/flashlease/api/montage/enanomalie/';

  public PARC_SAINE_LIST = '/flashlease/api/affaires/saines/';
  public PARC_CONTENTIEUSE_LIST = '/flashlease/api/affaires/contentieuses/';
  public PARC_AMIABLE_LIST = '/flashlease/api/affaires/amiables/';
  public PARC_EXPIRENt_LIST = '/flashlease/api/affaires/expirent/';

  validatingData = {};

  public currentDashboardTab = new BehaviorSubject(undefined);
  constructor(
    private http: RequesterService,
    private authService: AuthService,
    private catalogueService: CatalogueService,
    private materielSetrvice: MaterielService
  ) {}

  setDashboardTabIndex(index) {
    this.currentDashboardTab.next(index);
  }

  postDdf(data): Observable<any> {
    const api = { method: 'POST', url: this.DDF_API_CREATE_URL };
    let isMulti = false;
    const formdata: FormData = new FormData();
    isMulti = true;
    if (data.files && data.files.length > 0) {
      data.files.forEach(it => {
        formdata.append(
          'files[]',
          it._file,
          it.formData.typeCode + '__' + it.file.name
        );
      });
    }
    formdata.append('data', JSON.stringify(data.data));
    if (data.vendeur) {
      formdata.append('vendeur', JSON.stringify(data.vendeur));
    }
    data = formdata;
    return this.http.request(api, { body: data }, isMulti).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getDdf(did): Observable<any> {
    const api = { method: 'GET', url: this.DDF_API_URL + did };
    return this.http.request(api, { body: did }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  getPiecesDdf(did): Observable<any> {
    const api = { method: 'GET', url: this.DDF_API_URL + did + '/pieces' };
    return this.http.request(api, { body: did }).pipe(
      map(data => ({
        content: data
      }))
    );
  }

  AsyncValidatorDdf(data): Observable<ValidationErrors | null> {
    const api = { method: 'POST', url: this.DDF_API_VALID };
    return this.http.request(api, { body: data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getCatalogs(): Observable<any> {
    return this.catalogueService.getCatalogues();
  }

  getMateriels(code_cat): Observable<any> {
    return this.materielSetrvice.getMaterielByCatalogue(code_cat);
  }

  getDdfsList(id?) {
    const api = {
      method: 'GET',
      url: id ? this.DDF_API_LIST_URL + '/' + id : this.DDF_API_LIST_URL
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
        id: id
      }))
    );
  }

  setDataToValidate(data: any) {
    this.validatingData = data;
  }

  getKpiDfs() {
    const api = { method: 'GET', url: this.DDF_API_TICKET_STATUS_URL };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  getKpiDfsByUser(id) {
    const api = {
      method: 'GET',
      url: this.DDF_API_TICKET_STATUS_URL + '/' + id
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
        id: id
      }))
    );
  }

  getKpi(ids, type) {
    const req = { api: null, data: null };
    if (!ids || typeof ids === 'number') {
      req.api = {
        method: 'GET',
        url: this.DDF_API_KPI_BASE_URL + type + '/' + ids
      };
    } else {
      req.api = {
        method: 'POST',
        url: this.DDF_API_KPI_BASE_URL + type
      };
      req.data = ids;
    }
    return this.http.request(req.api, { body: req.data }).pipe(
      map(response => ({
        content: response,
        id: ids,
        type: type
      }))
    );
  }

  getDashboardList(id, type) {
    const api = {
      method: 'GET',
      url: this.DDF_API_BASE_URL + type + '/list/' + id
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
        id: id,
        type: type
      }))
    );
  }

  getAllStatus(type: string) {
    const api = {
      method: 'GET',
      url: this.DDF_API_BASE_URL + type + '/allstatus'
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response,
        type: type
      }))
    );
  }

  // Récupère les commentaires du suivi de dossier
  getCommentairesParSuiviDeDossier(type: string): Observable<any> {
    const api = {
      method: 'GET',
      url: this.DDF_API_URL + type + '/commentaires'
    };
    console.log('API : reception de la liste');
    return this.http.request(api, null).pipe(
      map((response: Response) => ({content: response}))
    );
  }

  postCommentairesParSuiviDeDossier(data, numDoss: string): Observable<any> {
    const api = { method: 'POST', url: this.DDF_API_URL + numDoss + '/commentaire' };
    console.log('API : envoi du message : ' + data);
    return this.http.request(api, { body: data }).pipe(
      map(response => ({
        content: response
      }))
    );
  }

  // Récupération de la liste des dossiers accordés
  getDDFAccordList(id) {
    if (typeof id !== 'string') {
      return this.getList(id, this.DDF_ACCORD_LIST_URL);
    } else {
      return this.get(id, this.DDF_ACCORD_LIST_URL);
    }
  }

  getDDFEtudeList(id) {
    if (typeof id !== 'string') {
      return this.getList(id, this.DDF_ETUDE_LIST_URL);
    } else {
      return this.get(id, this.DDF_ETUDE_LIST_URL);
    }
  }

  getDDFRefusList(id) {
    if (typeof id !== 'string') {
      return this.getList(id, this.DDF_REFUS_LIST_URL);
    } else {
      return this.get(id, this.DDF_REFUS_LIST_URL);
    }
  }

  getDDFExpireList(id) {
    if (typeof id !== 'string') {
      return this.getList(id, this.DDF_EXPIRE_LIST_URL);
    } else {
      return this.get(id, this.DDF_EXPIRE_LIST_URL);
    }
  }

  // Recuperer la liste des Dossier en Montage
  getMontagePayesList(id) {
    if (typeof id !== 'string') {
      return this.getList(id, this.MONTAGE_PAYES_LIST_URL);
    } else {
      return this.get(id, this.MONTAGE_PAYES_LIST_URL);
    }
  }

  getMontageEntraitementList(id: string | Perimetre[]) {
    if (typeof id !== 'string') {
      return this.getList(id, this.MONTAGE_ENTRAITEMENT_LIST_URL);
    } else {
      return this.get(id, this.MONTAGE_ENTRAITEMENT_LIST_URL);
    }
  }

  getMontageRecusList(id: string | Perimetre[]) {
    if (typeof id !== 'string') {
      return this.getList(id, this.MONTAGE_RECUS_LIST_URL);
    } else {
      return this.get(id, this.MONTAGE_RECUS_LIST_URL);
    }
  }

  getMontageEnAnomalieList(id: string | Perimetre[]) {
    if (typeof id !== 'string') {
      return this.getList(id, this.MONTAGE_ENANOMALIE_LIST_URL);
    } else {
      return this.get(id, this.MONTAGE_ENANOMALIE_LIST_URL);
    }
  }

  // Recuperer la liste des Dossier affaires
  getParcSaineList(id: string | Perimetre[]) {
    if (typeof id !== 'string') {
      return this.getList(id, this.PARC_SAINE_LIST);
    } else {
      return this.get(id, this.PARC_SAINE_LIST);
    }
  }

  getParcContentieuseList(id) {
    if (typeof id !== 'string') {
      return this.getList(id, this.PARC_CONTENTIEUSE_LIST);
    } else {
      return this.get(id, this.PARC_CONTENTIEUSE_LIST);
    }
  }

  getParcAmiableList(id) {
    if (typeof id !== 'string') {
      return this.getList(id, this.PARC_AMIABLE_LIST);
    } else {
      return this.get(id, this.PARC_AMIABLE_LIST);
    }
  }

  geParcExpireList(id) {
    if (typeof id !== 'string') {
      return this.getList(id, this.PARC_EXPIRENt_LIST);
    } else {
      return this.get(id, this.PARC_EXPIRENt_LIST);
    }
  }
  getList(perimetres: Perimetre[], url) {
    const api = {
      method: 'POST',
      url: url
    };
    return this.http.request(api, { body: perimetres }).pipe(
      map(response => ({
        content: response
      }))
    );
  }
  get(id: string, url) {
    const api = {
      method: 'GET',
      url: url + id
    };
    return this.http.request(api, null).pipe(
      map(response => ({
        content: response
      }))
    );
  }
}
