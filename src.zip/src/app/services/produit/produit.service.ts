import { Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class ProduitService {
  constructor(private authService: AuthService) {}

  getProduits(): any[] {
    const KEY = 'produits';
    return this.authService.getUserDataByKeyFromJWTPayload(KEY);
  }
}
