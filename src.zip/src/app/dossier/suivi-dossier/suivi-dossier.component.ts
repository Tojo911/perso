import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
import { AffaireInfo, BienInfo, ContratInfo, DossierInfo, DossierInfo2, DossierRatifieInfo, ElementInfo, MaterielFinancementInfo, PalierInfo, RatificationInfo, CommentaireDecisionCommerciale} from '../../models/ddf';
import * as func from '../../models/global-functions';
import { TableColumnDefinitionModel } from '../../models/table-column-definition-model';
import { AffaireService } from '../../services/affaires/affaire.service';
import { DdfService } from '../../services/ddf/ddf.service';
import { RatificationService } from '../../services/ddf/ratification.service';
import { MockService } from '../../services/mock/mock-service.service';
import { Dossier } from '../dossier-bloc/dossier-bloc.component';
import { DossierHeader, DossierHeaderBuilder } from '../dossier-header/dossier-header.component';
import { TemporalFreezeItem } from './temporal-freeze/temporal-freeze.component';
import { AuthService } from '../../services/auth/auth.service';
// import { ContratInfoClass } from '../../models/modelClass';



export enum Phase {
  DDF = 'ddf',
  MONTAGE = 'mont',
  PARC = 'parc'
}
@Component({
  selector: 'app-suivi-dossier',
  templateUrl: './suivi-dossier.component.html',
  styleUrls: ['./suivi-dossier.component.scss']
})
export class SuiviDossierComponent implements OnInit, OnDestroy {
  numDoss: any;
  pieces$;
  ddf$;
  nbColumns = 4;
  type: string;
  typesEnum = Phase;
  affaires: AffaireInfo;
  dossierLoading = false;
  route$;
  labelDossier = 'Informations générales';
  data: any = 26288;
  ddfData: DossierInfo;
  dossierHeader: DossierHeader;
  dossierDates: TemporalFreezeItem[] = [];
  montageFreezeDates: TemporalFreezeItem[] = [];
  parcFreezeDates: TemporalFreezeItem[] = [];
  ratifications: RatificationInfo[];
  ratificationsloaded = false;
  loaded = false;
  public dossierRatifie: DossierRatifieInfo = {};
  DossierRatifiable = false;
  ddfRetrived = false;
  paliers: PalierInfo[];
  selectedRatification: RatificationInfo;
  selectedContrat: ContratInfo;
  affaireElements: Dossier[];
  commentairesDecisionCommerciale: any;
  memory: {
    dossier: DossierRatifieInfo;
    contrat: ContratInfo;
    ratification: RatificationInfo;
  } = {
      dossier: null,
      contrat: null,
      ratification: null
    };
  steps: any[];
  pieces: any;
  piecesJointe: any;
  dossierSelector: any;
  ratificationSelector: any;
  palierColumns: TableColumnDefinitionModel[];
  columns: TableColumnDefinitionModel[];
  elementColumns: TableColumnDefinitionModel[];
  dossierColumns: TableColumnDefinitionModel[];
  private formatNumber = new AmountFormatter();
  contratContent: Dossier[];
  dossierContent: Dossier[];
  affairesContent: Dossier[];
  materielFinances: MaterielFinancementInfo[];
  materielColumns: TableColumnDefinitionModel[];
  incorrectColumns: TableColumnDefinitionModel[];
  manquanteColumns: TableColumnDefinitionModel[];
  attenduColumns: TableColumnDefinitionModel[];
  isInterne: boolean;

  mock = require('../../classes/mock/suividossier.json');
  currentTabulation: number;
  constructor(
    private ratifservice: RatificationService,
    private route: ActivatedRoute,
    private ddfService: DdfService,
    public transServ: TranslateService,
    private mockService: MockService,
    private affaireService: AffaireService,
    private authService: AuthService
  ) {
    this.mock[1] = require('../../classes/mock/EnsRatification.json');
    this.mock[2] = null; // func.generateRandomValue(new ContratInfoClass());
    this.mock[3] = require('../../classes/mock/ratification.json');
    this.mock[4] = require('../../classes/mock/suiviParc.json');
    this.mock[5] = require('../../classes/mock/commentaires.json');
    this.dossierSelector =  (row) => !this.selectedRatification;
    this.ratificationSelector = (row) => this.selectedRatification && row.chrono === this.selectedRatification.chrono;
    this.isInterne = this.authService.isInterne();
    // this.isInterne = true;
  }
  getDdfsColumnsDef() {
    return [
      {
        columnDef: 'indent',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NBFL'),
        cell: (row: RatificationInfo) => `attach_file`,
        type: 'icon'
      },
      {
        columnDef: 'Fl',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NBFL'),
        cell: (row: RatificationInfo) =>
          `${this.dossierRatifie.numeroFL}/${row.chrono}`
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.MONTANT'),
        cell: (row: RatificationInfo) =>
          this.formatNumber.transform(
            row.planFinancement
              ? row.planFinancement.montantFinancement
              : row.montant
          )
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DUREE'),
        cell: (row: RatificationInfo) =>
          `${row.planFinancement ? row.planFinancement.duree : row.duree} mois`
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.STATUS'),
        cell: (row: RatificationInfo) => row.statutRatification.libelle
      }
    ] as TableColumnDefinitionModel[];
  }
  getDossierColumnsDef() {
    return [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.CHRONO'),
        cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.MONTANT'),
        cell: (row: DossierRatifieInfo) =>
          `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DUREE'),
        cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.STATUT_COMMERCIAL'),
        date: true,
        cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.STATUS'),
        cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];
  }
  setMontageColumnsDef() {
    this.incorrectColumns = [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NON_CONFORME')
        // cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB_RELANCES')
        //  cell: (row: DossierRatifieInfo) =>
        //   `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TIERS_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.MAIL_TIERS_RELANCE'
        ),
        date: true
        //   cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status0',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_CONTROLE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status1',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_LAST_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status2',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_TEMP')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status3',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_DEF')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status4',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status5',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.COMMENT_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];

    this.manquanteColumns = [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.FORM.PCS_MANQUANTES')
        // cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'status4',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_CONTROLE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_LAST_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB_RELANCES')
        //  cell: (row: DossierRatifieInfo) =>
        //   `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TIERS_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.MAIL_TIERS_RELANCE'
        ),
        date: true
        //   cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status0',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_TEMP')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status1',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_DEF')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status2',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status3',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.COMMENT_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];

    this.incorrectColumns = [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.PCS_INCORRECTES')
        // cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'status4',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_CONTROLE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_LAST_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB_RELANCES')
        //  cell: (row: DossierRatifieInfo) =>
        //   `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TIERS_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.MAIL_TIERS_RELANCE'
        ),
        date: true
        //   cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status0',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_TEMP')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status1',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_DEF')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status2',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status3',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.COMMENT_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];

    this.attenduColumns = [
      {
        columnDef: 'ID',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.PCS_ATTENDUES')
        // cell: (row: DossierRatifieInfo) => `${row.numeroFL}`
      },
      {
        columnDef: 'status4',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_CONTROLE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status5',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_LAST_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB_RELANCES')
        //  cell: (row: DossierRatifieInfo) =>
        //   `${this.formatNumber.transform(row.montant)} €`
      },
      {
        columnDef: 'duree',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TIERS_RELANCE')
        //  cell: (row: DossierRatifieInfo) => row.duree + ' mois'
      },
      {
        columnDef: 'Statut commercial',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.MAIL_TIERS_RELANCE'
        ),
        date: true
        //   cell: (row: DossierRatifieInfo) => row.dateSaisie
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_TEMP')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status1',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DERO_DEF')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status2',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DATE_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      },
      {
        columnDef: 'status3',
        forbiddenScreens: ['xs', 'sm'],
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.COMMENT_DERO')
        //  cell: (row: DossierRatifieInfo) => row.statut.libelle
      }
    ] as TableColumnDefinitionModel[];
  }
  ngOnDestroy() {
    func.unsubscriber(this.pieces$);
    func.unsubscriber(this.ddf$);
    func.unsubscriber(this.route$);
  }
  initDossier(res) {
    this.ddfData = res as DossierInfo2;
    this.dossierHeader = DossierHeaderBuilder.setDossier(this.ddfData);
    this.DossierRatifiable = false;
    this.ddfRetrived = true;
    this.setView();
  }
  initDossierRatifie(res) {
    this.dossierRatifie = res as DossierRatifieInfo;
    this.memory.dossier = this.dossierRatifie;
    console.log('Ratification', res.content);
    this.DossierRatifiable = true;
    this.loaded = true;
  }
  ngOnInit() {
    this.route$ = this.route.params.subscribe(params => {
      if (params.did.indexOf('_') === -1) {
        throw new Error('Id Incorrect');
      }
      this.numDoss = params.did.split('_')[1];
      this.type = params.did.split('_')[0];
    });
    console.log('numeroFlashlease', this.numDoss);
    if (this.type === Phase.MONTAGE) {
      this.initMontage();
    }
    if (this.type === Phase.PARC) {
      this.initParc();
    }
    if (this.type === Phase.DDF) {
      this.ddf$ = this.ddfService.getDdf(this.numDoss).subscribe(
        res => {
          this.initDossier(res.content);
          this.initCommentairesParSuiviDeDossier();
          if (this.ddfData.statut.libelle === 'Ratification') {
            // this.labelDossier = 'Informations générales';
            /* this.ratifservice.getRatificationList(this.numDoss).subscribe(
            result => {
              this.ratifications = result.content as RatificationInfo[];
              console.log('Ratification', res.content);
              this.ratificationsloaded = true;
            },
            err => {
              this.ratifications = null;
              console.log('Ratifications non remonté introuvable');
            }
          );*/
            this.ratifservice.getRatifications(this.numDoss).subscribe(
              result => {
                this.initDossierRatifie(result.content);
              },
              err => {
                this.dossierRatifie = null;
                console.log('Ratification introuvable');
              }
            );
          }
        },
        err => {
          if (this.mockService.isDev()) {
            this.initDossier(this.mock[0]);
            setTimeout(this.initDossierRatifie(this.mock[1]), 800);
          }
          console.log('erreur de récupération des infos', err);
        }
      );
      this.pieces$ = this.ddfService.getPiecesDdf(this.numDoss).subscribe(
        res => {
          this.pieces = res.content;
          this.piecesJointe = this.buildPieces();
        },
        err => {
          if (this.mockService.isDev()) {
            /* this.dossierRatifie = this.mock[0];
             this.ddfData = this.mock[1];
             this.DossierRatifiable = false;
             this.ddfRetrived = true;*/
          }
          console.log('erreur de récupération des infos', err);
        }
      );
    }
  }
  initParcObs(res) {
    this.affaires = res as AffaireInfo;
      const aff = this.affaires;
      this.dossierHeader = {
        dossierId: this.numDoss,
        raisonSocial: aff.client.raisonSociale,
        siren: aff.client.siren,
        //  produitFinancier: '??',
        duree: aff.duree,
        periodicite:
          aff.elements && aff.elements.length > 0
            ? aff.elements[0].periodicite.libelle
            : '',
        montant: aff.montantRachat
        // loyer: '??',
      } as DossierHeader;
      this.setAffaireView();
      this.loaded = true;
  }
  initParc() {
    this.affaireService.getDossierById(this.numDoss).subscribe(result => {
      this.initParcObs(result.content);
    },
  err => {
    if (this.mockService.isDev()) {
      console.log('mockService etat de parc');
      this.initParcObs(this.mock[4]);
      /* this.dossierRatifie = this.mock[0];
       this.ddfData = this.mock[1];
       this.DossierRatifiable = false;
       this.ddfRetrived = true;*/
    }
  });
    // this.setParcDates();
  }
  initMontage() {
    this.setMontageDates();
    this.transServ.get('SUIVI.FORM.PCS_MANQUANTES').subscribe(it => {
      this.setMontageColumnsDef();
    });
    this.loaded = true;
  }

  initCommentairesParSuiviDeDossier() {

    this.ddfService.getCommentairesParSuiviDeDossier(this.numDoss).subscribe(
      res => {
        let list;
        if (!this.isInterne) {
          list = res.content.commentaires.filter(p => p.messageExterne !== null);
        } else {
          list = res.content.commentaires;
        }
        this.commentairesDecisionCommerciale = list.sort((a, b) => {
          if (a.dateCreation < b.dateCreation) {
            return -1;
          } else {
            return 1;
          }
        });

        console.log('liste des commentaire :' + this.commentairesDecisionCommerciale);
      },
      err => {
        if (this.mockService.isDev()) {
          this.commentairesDecisionCommerciale = this.mock[5];
        }
        console.log('erreur de récupération des infos', err);
      }
    );
    // this.commentairesDecisionCommerciale = this.mock[5];
  }
  commentAdded(event) {
    const myComment: string = event.comment;
    const externe: boolean = event.ext;
    const interne: boolean = event.int;
    const commentObjet = {
      'message': myComment,
      'interne': interne,
      'externe': externe
    };

    console.log('Send commentaire : ' +  commentObjet + ' ' + this.numDoss);
   this.ddfService.postCommentairesParSuiviDeDossier(commentObjet, this.numDoss).subscribe(
    res => {this.initCommentairesParSuiviDeDossier(); console.log('commentaire envoyé'); });
  }

  setView() {
    if (this.ddfRetrived) {
      this.dossierContent = [
        this.buildInformationsGenerale(),
        this.buildBlocDDF(),
        this.buildStatut(),
        this.buildCommentaire(),
        this.buildContrePartie(),
        this.buildInfosVendeur()
      ];
      this.transServ.get(' ').subscribe(it => {
        this.steps = [
          { name: this.transServ.instant('HOME.TABS.DDFS') },
          { name: this.transServ.instant('HOME.TABS.MONTAGE') },
          { name: this.transServ.instant('HOME.TABS.SUIVI') }
        ];
        this.columns = this.getDdfsColumnsDef();
        this.dossierColumns = this.getDossierColumnsDef();
      });
      this.loaded = true;
      this.currentTabulation = 0;
    }
  }
  setContratView() {
    if (this.ddfRetrived) {
      this.contratContent = [
        this.buildInfosVendeur(true),
        this.buildSimulation(true),
        this.buildComplementFinancement(true),
        this.buildCalage(true),
        this.buildAutreMajoration(true),
        this.buildModeReglement(true),
        this.buildIdentificationVendeur(true),
        this.buildIdentificationClient(true),
        this.buildStatutRachat(true),
        this.buildPrestationAnnexe(true),
        this.buildMaterielPrincipal(true),
        this.buildGaranties(true)
      ];
      this.loaded = true;
    }
  }
  setAffaireView() {
    this.transServ.get('  ').subscribe(it => {
      this.elementColumns = this.setElementColumns();
    });
    this.affairesContent = [
      this.buildInfoGeneraleAffaires(),
      this.buildClientAffaires(),
      this.buildInfosVendeurAffaires(),
      this.buildInfosApporteurAffaires()
      // this.buildElementAffaires()
    ];
    let i = 0;
    this.affaireElements = this.affaires.elements.map(el =>
      this.buildElementAffaire(el, ++i)
    );
    this.setParcDates(this.affaires.firstElement);
    this.loaded = true;
  }
  buildInfoGeneraleAffaires(isContrat?): Dossier {
    const affaires = this.affaires;
    return this.build('Informations générales', [
      this.set('Société de gestion', affaires.societeGestion),
      this.set('Mode de règlement', affaires.modeReglement.libelle),
      this.set("Catégorie d'affaires", affaires.categorieAffaire),
      this.set('Nom du vendeur', affaires.nomVendeur),
      this.set('Statut EKIP', affaires.statut.libelle),
      this.set('Code offre', affaires.codeOffre),
      this.set('Durée', affaires.duree),
      Dossier.getEmptyDossier,
      this.set(
        'Montant HT du rachat à la dernière échéance',
        affaires.montantRachat
      )
    ]);
  }
  buildClientAffaires(isContrat?): Dossier {
    const affaires = this.affaires.client;
    return this.build('Client', [
      this.set('SIREN', affaires.siren),
      this.set('Raison sociale', affaires.raisonSociale)
    ]);
  }
  buildInfosApporteurAffaires(isContrat?): Dossier {
    const affaires = this.affaires;
    return this.build('Vendeur', [
      this.set('SIREN', affaires.numApporteur),
      this.set('Raison sociale', affaires.nomApporteur)
    ]);
  }
  buildInfosVendeurAffaires(isContrat?): Dossier {
    const affaires = this.affaires;
    return this.build('Apporteur', [
      this.set('Réseau du vendeur', affaires.codeReseau),
      this.set('Région interne Franfinance', affaires.codeRegionInt),
      this.set('Code district vendeur', affaires.codeDistrict),
      this.set('Secteur Franfinance', affaires.codeSecteur),
      this.set('Région interne Franfinance', affaires.codeRegionExt)
    ]);
  }
  buildElementAffaire(element: ElementInfo, index): Dossier {
    let datePublication: Dossier,
      dateLocation: Dossier,
      dateLocationFin: Dossier,
      dateLocationNext: Dossier,
      dateLocationFirst: Dossier;
    dateLocation = this.set(
      'Date de début de location',
      element.dateDebutLocation
    );
    dateLocationFin = this.set(
      'Date de fin de location',
      element.dateFinLocation
    );
    dateLocationNext = this.set(
      'Date de la prochaine échéance',
      element.dateProchaineEcheance
    );
    dateLocationFirst = this.set(
      'Date première échéance',
      element.datePremiereEcheance
    );
    datePublication = this.set(
      'Date publication greffe',
      element.datePublicationGreffe
    );
    dateLocation.isDate = true;
    dateLocationFin.isDate = true;
    dateLocationNext.isDate = true;
    dateLocationFirst.isDate = true;
    datePublication.isDate = true;
    const custom = Dossier.getEmptyDossier();
    custom.title = 'Biens';
    custom.custom = true;

    const dossier = this.build('Element n°' + index, [
      this.set('Référence externe', element.referenceApporteur),
      this.set('Prestation LMAI', element.prestationLMAI),
      this.set("Période de l'affaire", element.periodicite.libelle),
      dateLocation,
      dateLocationFin,
      this.set('Nombre de loyers restants', element.nombreLoyersRestants),
      dateLocationNext,
      this.set('Montant de la base locative', element.baseLocInit),
      this.set(
        "Taux de rendement interne de l'opération",
        element.tauxRendementInterne
      ),
      this.set("Taux nominal de l'opération", element.tauxNominal),
      this.set("TEG actuariel de l'opération", element.tegActuariel),
      this.set(
        'Taux de rendement interne actuariel',
        element.tauxRendementInterneActuariel
      ),
      this.set(
        "Taux de rendement interne de l'opération",
        element.tauxRendementInterne
      ),
      this.set('Montant VR', element.montantVR),
      this.set('Montant VR client repreneur ', element.montantVRRepreneur),
      this.set('Loyer financier HT', element.loyerFinHT),
      this.set('Loyer prestation services', element.loyerPrestationServiceHT),
      this.set('Primes assurances', element.primeAssurances),
      this.set('Loyer global HT', element.loyerGlobal),
      this.set('VR client repreneur', element.pourcentVRClient),
      this.set('VR client fournisseur', element.pourcentVRFournisseur),
      this.set(
        'Vr repreneur non fournisseur / non client',
        element.loyerFinHT
      ),
      dateLocationFirst,
      datePublication,
      this.set(
        'Numéro fournisseur entretien',
        element.numeroFournisseurEntretien
      ),
      this.set('Nom fournisseur entretien', element.nomFournisseurEntretien),
      this.set('Code contrat prestation', element.codeContratPrestation),
      this.set('Code contrat assurance', element.codeContratAssurance)
    ]);
    dossier.data = element.biens;
    dossier.list.push(custom);
    return dossier;
  }
  buildCalage(isContrat?) {
    const calage = this.selectedContrat.ratification.calage;
    return this.build('Autres majorations', [
      this.set('Calage', calage.dateFinancement),
      this.set('Nombre de jours', calage.nbJoursCalage)
    ]);
  }
  buildAutreMajoration(isContrat?) {
    const majoration = this.selectedContrat.ratification.autreMajorations;
    return this.build(
      'Autres majorations',
      majoration.map(it => this.set(it.libelle, it.montantMajoration))
    );
  }
  buildStatutRachat(isContrat?) {
    const rachat = this.selectedContrat.ratification.rachat;
    return this.build('Rachat', [
      this.set('Le montant global intègre', rachat.montantGlobal),
      this.set(
        'Avant échéance de',
        func.mapTimestampToDate(Number(rachat.dateRachat))
      )
    ]);
  }
  buildGaranties(isContrat?) {
    const garanties = this.selectedContrat.ratification.garanties;
    return {
      value: null,
      title: 'Garanties et conditions',
      list: [
        {
          value: null,
          title: null,
          list: garanties.map(it => this.set(it.libelle, it.code))
        }
      ]
    } as Dossier;
  }
  buildInformationsGenerale(): Dossier {
    const dossierRatifie = this.ddfData;
    const { nom, prenom } = dossierRatifie.vendeur
      ? dossierRatifie.vendeur
      : { nom: '', prenom: '' };
    return {
      value: null,
      title: 'Informations générales',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'SIREN',
              value: dossierRatifie.numeroSIREN
            },
            {
              title: 'Raison sociale',
              value: dossierRatifie.raisonSociale
            },
            {
              title: 'Montant',
              value: dossierRatifie.montant,
              isNumber: true
            },
            {
              title: 'Durée',
              value: dossierRatifie.duree
            }
          ]
        } as Dossier,
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Produits financiers',
              value: dossierRatifie.produitFinancier.libelle
            },
            {
              title: 'Date de saisie',
              value: dossierRatifie.dateSaisie,
              isDate: true
            },
            {
              title: 'Gestionnaire de saisie',
              value: `${nom} ${prenom}`
            },
            {
              title: 'Média  de création du dossier',
              value: dossierRatifie.media
            }
          ]
        } as Dossier
      ]
    };
  }
  buildBlocDDF(): Dossier {
    const dossierRatifie = this.ddfData;
    return {
      value: null,
      title: 'Informations sur la demande',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'N°dossier',
              value: dossierRatifie.id
            },
            {
              title: 'Produits financiers',
              value: dossierRatifie.produitFinancier
                ? dossierRatifie.produitFinancier.libelle
                : ''
            },
            {
              title: 'Montant',
              value: dossierRatifie.montant,
              isNumber: true
            },
            {
              title: 'Durée',
              value: dossierRatifie.duree
            }
          ]
        } as Dossier,
        {
          value: null,
          title: 'Informations matériels',
          list: [
            {
              title: 'Matériel(s)',
              value: dossierRatifie.materiel
                ? dossierRatifie.materiel.libelle
                : ''
            },
            {
              title: 'Fournisseur(s)',
              value: null // dossierRatifie.fournisseurs
            },
            {
              title: 'Commentaire interne(s)',
              value: null // dossierRatifie.fournisseurs
            },
            Dossier.getEmptyDossier()
          ]
        } as Dossier
      ]
    };
  }

  buildPlanFinancement(): Dossier {
    const ratifs = this.dossierRatifie;
    return {
      value: null,
      title: 'Plan de financement',
      list: [
        {
          value: null,
          title: 'Informations sur la demande',
          list: [
            {
              title: 'Montant',
              value: ratifs.id,
              isNumber: true
            },
            {
              title: 'Périodicité',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].planFinancement.periodicite.libelle
                  : ''
            },
            {
              title: 'Loyer Financier',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].planFinancement.loyerFinancierMajore
                  : ''
            },
            {
              title: 'Coefficient',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].planFinancement.loyerFinancierBareme
                  : ''
            }
          ]
        } as Dossier,
        {
          value: null,
          title: 'Options de financement',
          list: [
            {
              title: 'Calage',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].calage
                  : ''
            },
            {
              title: 'Règlement',
              value:
                ratifs && ratifs.ratifications
                  ? ratifs.ratifications[0].planFinancement.modeReglement
                    .libelle
                  : ''
            },
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier()
          ]
        } as Dossier
      ]
    };
  }

  buildInfosVendeur(isContrat?): Dossier {
    const ratifs = isContrat
      ? this.selectedContrat.vendeur
      : this.ddfData.vendeur;
    return {
      value: null,
      title: 'Identification du vendeur',
      list: [
        {
          value: null,
          list: [
            {
              title: 'Marché',
              value: ratifs.agence.apporteur.marche.libelle
            },
            {
              title: 'Apporteur',
              value: ratifs.agence.apporteur.libelle
            },
            {
              title: 'Agence',
              value: ratifs.agence.libelle
            },
            {
              title: 'Vendeur',
              value: ratifs.nom + ' ' + ratifs.prenom
            }
          ]
        } as Dossier
      ]
    };
  }

  buildStatut(): Dossier {
    const ratifs = this.ddfData;
    return {
      value: null,
      title: 'Statut',
      list: [
        {
          value: null,
          title: 'Statut courant',
          list: [
            {
              title: 'Statut courant',
              value: ratifs.statut.libelle
            },
            {
              title: 'Date du statut',
              value: ratifs.statut.date
            },
            {
              title: 'Commentaire du statut',
              value: ratifs.statut.commentaire
            },
            {
              title: 'Gestionnaire de statut',
              value: ratifs.statut.commentaire
            }
          ]
        } as Dossier
      ]
    };
  }

  buildCommentaire(): Dossier {
    return {
      value: null,
      title: 'Décisions commerciales',
      list: [
        {
          value: null,
          title: 'Commentaires',
          custom: true,
          list: []
        }
      ]
    } as Dossier;
  }

  buildContrePartie(): Dossier {
    const ratifs = this.ddfData.blocContrepartie;
    return {
      value: null,
      title: 'ContrePartie(Données INSEE) ',
      list: [
        {
          value: null,
          title: '',
          list: [
            {
              title: 'Enseigne',
              value: ratifs.enseigne
            },
            {
              title: 'NAF',
              value: ratifs.codeNaf
                ? ratifs.codeNaf + '(' + ratifs.libelleNaf + ')'
                : null
            },
            {
              title: 'Effectif',
              value: ratifs.effectif,
              isNumber: true
            },
            {
              title: `Adresse de l'établissement principal`,
              value: ratifs.adresseEtablissement
                ? ratifs.adresseEtablissement[0]
                : null
            }
          ]
        } as Dossier,
        {
          value: null,
          title: '',
          list: [
            {
              title: 'Forme juridique',
              value: ratifs.formeJuridique
            },
            {
              title: `Chiffre d'affaires`,
              value: ratifs.chiffreAffaires
            },
            {
              title: 'Cote BDF',
              value: ratifs.coteBDF
            },
            Dossier.getEmptyDossier()
          ]
        } as Dossier
      ]
    };
  }
  buildPieces() {
    const list = this.pieces;
    const type = [];
    const result = [];
    const bloc = list.map(it => {
      const item = this.buildPiece(it);
      if (type.indexOf(item.value) > -1) {
        const res = result.filter(ite => ite.value === item.value) as Dossier[];
        res[0].list = res[0].list.concat(item.list);
      } else {
        type.push(item.value);
        result.push(item);
      }
      return item;
    });
    return result;
  }
  buildPiece(item) {
    const list = [
      /* {
        title: 'id',
        value: item.oid
      },*/
      {
        title: 'Document ' + item.oid,
        value: item.nomDocument.split('__')[1]
      }
      /* {
        title: 'Type de document',
        value: item.typeDocument
      },
      {
        title: 'Status',
        value: item.status
      }*/
    ];
    const bloc = new Dossier('', list, item.typeDocument);
    return bloc;
  }

  buildSimulation(isContrat?): Dossier {
    const simulation = isContrat
      ? this.selectedContrat.ratification
      : this.selectedRatification;
    const financement = simulation.planFinancement
      ? simulation.planFinancement
      : {};
    const bareme = simulation.bareme ? simulation.bareme : {};
    if (isContrat) {
      return {
        value: null,
        title: 'Simulation',
        list: [
          {
            value: null,
            title: null,
            list: [
              this.set('Reference apporteur', simulation.referenceApporteur),
              this.set(
                'Produit commercial',
                simulation.produitCommercial.libelle
              ),
              this.set('Durée', simulation.duree),
              this.set('Autorisation restante', '??')
            ]
          },
          {
            value: null,
            title: null,
            list: [
              this.set('Montant', simulation.montant),
              this.set('Loyer financier', financement.loyerFinancierMajore),
              this.set('Frais de montage', simulation.fraisDeMontage),
              this.set('Clause indexation', financement.clauseIndexation)
            ]
          },
          {
            value: null,
            title: null,
            list: [
              this.set('Commision apporteur', simulation.commissionApporteur),
              this.set('Dérogation', simulation.motifDerogation),
              this.set('Taux de TVA', financement.tauxTVA),
              this.set('Barème', simulation.bareme)
            ]
          },
          {
            value: null,
            title: null,
            list: [
              this.set('Barème', simulation.commissionApporteur),
              this.set('Code barème origine', simulation.motifDerogation),
              Dossier.getEmptyDossier(),
              Dossier.getEmptyDossier()
            ]
          }
        ]
      } as Dossier;
    }
    return {
      value: null,
      title: 'Simulation',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Référence externe',
              value: simulation.referenceApporteur
            },
            {
              title: 'Poduits commercial',
              value: simulation.produitCommercial.libelle
            },
            {
              title: 'Montant',
              value: simulation.montant,
              isNumber: true
            },
            {
              title: 'Frais de montage',
              value: simulation.fraisDeMontage
            }
          ]
        } as Dossier,
        {
          value: null,
          title: 'Informations matériels',
          list: [
            {
              title: 'Financement',
              value: financement.montantFinancement
            },
            {
              title: 'Duree',
              value: financement.duree
            },
            {
              title: 'Commentaire',
              value: simulation.commentairePalier
            },
            {
              title: 'Derogation',
              value: simulation.motifDerogation
            }
          ]
        } as Dossier,
        {
          value: null,
          title: null,
          custom: true,
          list: []
        },
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Taux de refinancement',
              value: financement.tauxRefinancement
            },
            {
              title: 'Code barème',
              value: bareme.code
            },
            {
              title: 'Taux de marge',
              value: financement.tauxMarge
            },
            {
              title: 'Spread',
              value: bareme.libelleSpread
            }
          ]
        } as Dossier,
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Terme',
              value: financement.terme ? financement.terme.libelle : null
            },
            {
              title: 'Mode amortissement',
              value: financement.modeAmortissement
                ? financement.modeAmortissement.libelle
                : null
            },
            {
              title: 'Taux',
              value: financement.taux
            },
            {
              title: 'Taux T.V.A.',
              value: financement.tauxTVA
            }
          ]
        } as Dossier
      ]
    };
  }
  initContrat(res) {
    this.selectedRatification = null;
    this.selectedContrat = res as ContratInfo;
    this.setDossierDatesContrat();
    this.memory.contrat = this.selectedContrat;
  }
  initRatification(res) {
    this.selectedRatification = res;
    this.dossierRatifie.ratifications.forEach(rat => {
      if (rat.chrono === this.selectedRatification.chrono) {
        rat = this.selectedRatification;
      }
    });
    this.selectedContrat = null;
    this.memory.contrat = null;
    this.setRatificationView();
  }
  ratificationSelected(e: RatificationInfo) {
    this.selectedRatification = e;
    this.memory.ratification = e;
    this.dossierLoading = true;
    if (e.statutRatification.code === 'RATIF_CO') {
      this.ratifservice
        .getContrat({
          dossierId: this.numDoss,
          contratId: this.selectedRatification.chrono
        })
        .subscribe(
          resultat => {
            this.initContrat(resultat.content);
          },
          err => {
            if (this.mockService.isDev) {
              console.log('mock service');
              this.initContrat(this.mock[3]);
            }
            console.error('contrat introuvable');
          }
        );
    } else {
      this.ratifservice
        .getRatification({
          dossierId: this.numDoss,
          contratId: this.selectedRatification.chrono
        })
        .subscribe(
          resultat => {
            this.initRatification(resultat.content);
          },
          err => {
            if (this.mockService.isDev()) {
              console.log('serviceMock');
              this.initRatification(this.mock[3]);
            }
            console.error('detail ratif  introuvable');
          }
        );
    }

    /* this.setRatificationView();
     this.currentTabulation = 1;*/
  }
  setRatificationView() {
    const { paliers } = this.selectedRatification.planFinancement;
    this.paliers = paliers ? paliers : [];
    this.contratContent = [
      this.buildInfosVendeur(),
      this.buildSimulation(),
      this.buildIdentificationClient(),
      this.buildStatut(),
      this.buildMaterielFinances(),
      this.buildComplementFinancement(),
      this.buildModeReglement(),
      this.buildPrestationAnnexe()
    ];
    this.currentTabulation = 1;
    this.palierColumns = this.setPalierColumns();
    this.materielFinances = this.selectedRatification.materielsFinancement;
    this.materielColumns = this.setMaterielColumns();
    this.setDossierDatesRatification();
    this.dossierLoading = false;
  }
  setPalierColumns() {
    return [
      {
        columnDef: 'Rang du palier',
        header: this.transServ.instant('SUIVI.PALIER.TABLE.COLUMNS.RANG'),
        cell: (row: PalierInfo) => row.indice
      },
      {
        columnDef: `Nombre d'échéances`,
        header: this.transServ.instant('SUIVI.PALIER.TABLE.COLUMNS.ECHEANCE'),
        cell: (row: PalierInfo) => row.ratio
      },
      {
        columnDef: 'Periodicité',
        header: this.transServ.instant('SUIVI.PALIER.TABLE.COLUMNS.PERIODE'),
        cell: (row: PalierInfo) => row.periodicite.libelle
      },
      {
        columnDef: 'loyer',
        header: this.transServ.instant('SUIVI.PALIER.TABLE.COLUMNS.LOYER'),
        cell: (row: PalierInfo) => this.formatNumber.transform(row.loyer)
      }
    ] as TableColumnDefinitionModel[];
  }
  setElementColumns() {
    return [
      {
        columnDef: 'designation',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.DESIGNATION'),
        cell: (row: BienInfo) => row.designation
      },
      {
        columnDef: `Serial`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.SERIALNUMBER'),
        cell: (row: BienInfo) => row.numeroSerie
      },
      {
        columnDef: 'id',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.IDNUMBER'),
        cell: (row: BienInfo) => row.immobilisation
      },
      {
        columnDef: 'Montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.MONTANT'),
        cell: (row: BienInfo) => this.formatNumber.transform(row.montant)
      },
      {
        columnDef: 'Num fournisseur',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NUMFOURNISSEUR'),
        cell: (row: BienInfo) =>
          (row.numeroFournisseur)
      },
      {
        columnDef: 'Nom fournisseur',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NOMFOURNISSEUR'),
        cell: (row: BienInfo) => (row.nomFournisseur)
      },
      {
        columnDef: 'Taux Amorti',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.AMORTISSEMENT'),
        cell: (row: BienInfo) =>
          (row.typeAmortissement)
      }
    ] as TableColumnDefinitionModel[];
  }
  setMaterielColumns() {
    return [
      {
        columnDef: 'Nb',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.NB'),
        cell: (row: MaterielFinancementInfo) => row.nbMateriels
      },
      {
        columnDef: `Type`,
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TYPE'),
        cell: (row: MaterielFinancementInfo) => row.type
      },
      {
        columnDef: 'Numéro de série',
        header: this.transServ.instant(
          'SUIVI.TABLE.COLUMNS.SERIALNUMBER'
        ),
        cell: (row: MaterielFinancementInfo) => row.numeroSerie
      },
      {
        columnDef: 'Montant',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.MONTANT'),
        cell: (row: MaterielFinancementInfo) =>
          this.formatNumber.transform(row.montant.montant)
      },
      {
        columnDef: 'Taux TVA',
        header: this.transServ.instant('SUIVI.TABLE.COLUMNS.TAUX'),
        cell: (row: MaterielFinancementInfo) =>
          this.formatNumber.transform(row.tauxTva)
      }
    ] as TableColumnDefinitionModel[];
  }
  buildComplementFinancement(isContrat?): Dossier {
    const { montantPremierLoyerMajore, montantVR } = isContrat
      ? this.selectedContrat.ratification.planFinancement
      : this.selectedRatification.planFinancement;
    return {
      value: null,
      title: 'Complément du plan financier',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Premier loyer majoré',
              value: montantPremierLoyerMajore
            },
            {
              title: 'Valeur résiduelle',
              value: montantVR
            },
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }

  /*buildMajorations(): Dossier {
    const {montantPremierLoyerMajore, montantVR}  = this.selectedRatification.planFinancement;
    return {
      value: null,
      title: 'Complément du plan financier',
      list:  [
        {
          title: 'Terme',
          value: montantPremierLoyerMajore
        },
        {
          title: 'Mode amortissement',
          value: montantVR
        }
      ]
    } as Dossier;

  }*/
  buildModeReglement(isContrat?): Dossier {
    const { modeReglement } = isContrat
      ? this.selectedContrat.ratification.planFinancement
      : this.selectedRatification.planFinancement;
    return {
      value: null,
      title: 'Règlement',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Mode de règlement',
              value: modeReglement ? modeReglement.libelle : null
            },
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }
  buildPrestationAnnexe(isContrat?): Dossier {
    const {
      loyerToutInclus,
      loyerFinancierBareme,
      loyerFinancierMajore
    } = isContrat
        ? this.selectedContrat.ratification.planFinancement
        : this.selectedRatification.planFinancement;
    return {
      value: null,
      title: 'Prestations annexes, assurance (par période)',
      list: [
        {
          value: null,
          title: null,
          list: [
            isContrat
              ? this.set('Loyer financier barème', loyerFinancierBareme)
              : this.set('Loyer total', loyerToutInclus),
            isContrat
              ? this.set('Loyer financier majoré', loyerFinancierMajore)
              : Dossier.getEmptyDossier(),
            isContrat
              ? this.set('Loyer total', loyerToutInclus)
              : Dossier.getEmptyDossier(),
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }
  buildIdentificationVendeur(isContrat?): Dossier {
    const vendeur = this.selectedContrat.vendeur;
    return {
      value: null,
      title: 'Identification du vendeur',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Apporteur',
              value: vendeur.agence.apporteur.libelle
            },
            {
              title: 'Agence',
              value: vendeur.agence.libelle
            },
            {
              title: 'Nom',
              value: vendeur.nom
            },
            {
              title: 'Prenom',
              value: vendeur.prenom
            }
          ]
        },
        {
          value: null,
          title: null,
          list: [
            this.set('Mail', vendeur.mail),
            this.set('Téléphone', vendeur.telephone),
            this.set('Fax', vendeur.fax),
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }
  buildIdentificationClient(isContrat?): Dossier {
    const { siren, raisonSociale } = isContrat
      ? this.selectedContrat.ratification.client
      : this.selectedRatification.client
        ? this.selectedRatification.client
        : { siren: null, raisonSociale: null };
    return {
      value: null,
      title: 'Prestations annexes, assurance (par période)',
      list: [
        {
          value: null,
          title: null,
          list: [
            {
              title: 'Numero SIREN',
              value: siren
            },
            {
              title: 'Nom',
              value: raisonSociale
            },
            {
              title: 'Commentaire',
              value: null
            },
            Dossier.getEmptyDossier()
          ]
        }
      ]
    } as Dossier;
  }
  buildMaterielFinances(): Dossier {
    return {
      value: null,
      title: 'Matériel financés',
      list: [
        {
          value: null,
          title: null,
          custom: true
          // list: this.selectedRatification.materielsFinancement.map(it => this.set(it.designation, it.anneeMiseEnService))
        }
      ]
    } as Dossier;
  }
  buildMaterielPrincipal(isContrat?): Dossier {
    const materiels = this.selectedContrat.materiels;
    return this.build(
      'Matériel principal ( Neuf )',
      materiels.map(it => this.set(it.designation, it.anneeMiseEnService))
    );
  }
  dossierSelected() {
    this.selectedRatification = null;
    this.setView();
    this.currentTabulation = 0;
  }
  set(title, value): Dossier {
    return Dossier.set(title, value) as Dossier;
  }
  build(title, list) {
    return {
      value: null,
      title: title,
      list: [
        {
          value: null,
          title: null,
          list: list
        }
      ]
    } as Dossier;
  }
  setDossierDatesRatification() {
    let date1: TemporalFreezeItem,
      date2: TemporalFreezeItem,
      date3: TemporalFreezeItem;
    date1 = TemporalFreezeItem.setStart(
      new Date(this.dossierRatifie.dateSaisie),
      'Accordé'
    );
    date2 = TemporalFreezeItem.setcurrentStep(
      new Date(this.selectedRatification.dateCreation),
      'Ratifié'
    );
    date3 = TemporalFreezeItem.setEnd(
      new Date(
        2 * Number(this.selectedRatification.dateCreation) -
        Number(this.dossierRatifie.dateSaisie)
      ),
      'é'.toUpperCase() + 'dité'
    );
    this.dossierDates = [date1, date2, date3];
  }
  setDossierDatesContrat() {
    let date1: TemporalFreezeItem,
      date2: TemporalFreezeItem,
      date3: TemporalFreezeItem;
    date1 = TemporalFreezeItem.setStart(
      new Date(this.ddfData.dateSaisie),
      'Accordé'
    );
    date2 = TemporalFreezeItem.setcurrentStep(
      new Date(this.selectedContrat.ratification.dateCreation),
      'Ratifié'
    );
    date3 = TemporalFreezeItem.setEnd(
      new Date(Number(this.selectedContrat.dateCreation)),
      'é'.toUpperCase() + 'dité'
    );
    this.dossierDates = [date1, date2, date3];
  }
  setMontageDates() {
    let date1: TemporalFreezeItem,
      date2: TemporalFreezeItem,
      date3: TemporalFreezeItem,
      date4: TemporalFreezeItem;
    date1 = TemporalFreezeItem.setStart(new Date(2018, 2, 12), 'reçu');
    date2 = TemporalFreezeItem.setcurrentStep(
      new Date(2018, 3, 14),
      'En traitement'
    );
    date3 = TemporalFreezeItem.setEnd(new Date(2018, 4, 24), 'Anomalies');
    date4 = TemporalFreezeItem.setEnd(new Date(2018, 5, 28), 'Payés');
    this.montageFreezeDates = [date1, date2, date3, date4];
  }
  setParcDates(el) {
    let date1: TemporalFreezeItem,
    date2: TemporalFreezeItem,
    date3: TemporalFreezeItem,
    date4: TemporalFreezeItem;
    date1 = TemporalFreezeItem.setStart(new Date(el.dateDebutLocation), 'Début de location');
    date2 = TemporalFreezeItem.setEnd(
      new Date(el.datePremiereEcheance),
      'Première échéance'
    );
    date3 = TemporalFreezeItem.setcurrentStep(new Date(el.dateProchaineEcheance), 'Prochaine échéance');
    date4 = TemporalFreezeItem.setEnd(new Date(el.dateFinLocation), 'Fin de location');
    this.parcFreezeDates =  [date1, date2, date3, date4].filter(it => it);
  }
  freezeEventClicked(e: TemporalFreezeItem) {
    if (this.memory.contrat && e.label === 'é'.toUpperCase() + 'dité') {
      this.contratContent = [
        this.buildInfosVendeur(true),
        this.buildSimulation(true),
        this.buildComplementFinancement(true),
        this.buildCalage(true),
        this.buildAutreMajoration(true),
        this.buildModeReglement(true),
        this.buildIdentificationVendeur(true),
        this.buildIdentificationClient(true),
        this.buildStatutRachat(true),
        this.buildPrestationAnnexe(true),
        this.buildMaterielPrincipal(true),
        this.buildGaranties(true)
      ];
    }
    if (this.memory.ratification && e.label === 'Ratifié') {
      this.contratContent = [
        this.buildInfosVendeur(),
        this.buildSimulation(),
        this.buildIdentificationClient(),
        this.buildStatut(),
        this.buildMaterielFinances(),
        this.buildComplementFinancement(),
        this.buildModeReglement(),
        this.buildPrestationAnnexe()
      ];
    }
    if (e.label === 'Accordé') {
      this.contratContent = [
        this.buildInformationsGenerale(),
        this.buildBlocDDF(),
        this.buildStatut(),
        this.buildContrePartie(),
        this.buildInfosVendeur()
      ];
    }
  }
}
