import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DossierHeaderComponent } from './dossier-header.component';

describe('DossierHeaderComponent', () => {
  let component: DossierHeaderComponent;
  let fixture: ComponentFixture<DossierHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DossierHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DossierHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
