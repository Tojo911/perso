import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { DdfService } from '../services/ddf/ddf.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/internal/operators/map';
import { tap } from 'rxjs/internal/operators/tap';
import { CatalogueService } from '../services/catalogue/catalogue.service';
import { CatalogueInfo } from '../classes/catalogue-info';
import { MaterielService } from '../services/materiel/materiel.service';
import { TranslateService } from '@ngx-translate/core';
import { DossierInfo } from '../models/dossier-info';

@Component({
  selector: 'app-dossier',
  templateUrl: './dossier.component.html',
  styleUrls: ['./dossier.component.scss']
})
export class DossierComponent implements OnInit {
  public dossier$: Observable<DossierInfo>;
  public cataloguesList$: Observable<CatalogueInfo[]>;
  public materielsByCat$: Observable<any[]>;
  public value = '';

  public model = {
    catalogue: '',
    materiel: ''
  };

  public steps: string[];

  BaremeList = [
    { code: '332', id: 167, apporteur: null, libelle: 'Accord Cosme 1' },
    { code: '332', id: 168, apporteur: null, libelle: 'Accord Cosme 2' }
  ];

  assuranceList = [
    { code: '332', id: 167, apporteur: null, libelle: 'Assurance 1' },
    { code: '332', id: 168, apporteur: null, libelle: 'Assurance 2' }
  ];

  constructor(
    private route: ActivatedRoute,
    private ddfService: DdfService,
    private catalogueService: CatalogueService,
    private materielService: MaterielService,
    private translateService: TranslateService
  ) {
    this.route.params.subscribe(params => {
      this.dossier$ = this.ddfService.getDdf(params.did).pipe(
        map(r => new DossierInfo(r.content)),
        tap(e => console.log('result...  ', e))
      );
    });

    this.cataloguesList$ = this.catalogueService.getCatalogues().pipe(
      map(r => {
        return r.content.catalogues.map(
          (c: CatalogueInfo) => new CatalogueInfo(c)
        );
      })
    );
  }

  ngOnInit() {}

  public getSteps() {
    const steps = [
      { name: this.translateService.instant('DOSSIER.BREADCRUMB.STEPS.STEP1') },
      { name: this.translateService.instant('DOSSIER.BREADCRUMB.STEPS.STEP2') },
      { name: this.translateService.instant('DOSSIER.BREADCRUMB.STEPS.STEP3') }
    ];
    return steps;
  }

  public getMaterielsByCat() {
    this.materielsByCat$ = this.materielService
      .getMaterielByCatalogue(this.model.catalogue['code'])
      .pipe(map((res: any) => res.content.materiels));
  }

  public updateDossier(materiel: any) {
    if (materiel !== undefined) {
      this.dossier$.subscribe(e => e.updateMateriel(materiel));
    }
  }
}
