import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DossierBlocComponent } from './dossier-bloc.component';

describe('DossierBlocComponent', () => {
  let component: DossierBlocComponent;
  let fixture: ComponentFixture<DossierBlocComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DossierBlocComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DossierBlocComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
