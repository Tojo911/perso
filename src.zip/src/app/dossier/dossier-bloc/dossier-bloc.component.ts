import {
  Component,
  OnInit,
  Input,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { AmountFormatter } from '../../classes/inputFormatter/amountFormatter';
import * as globalFunc from '../../models/global-functions';
import { isDefined } from '@angular/compiler/src/util';

export class Dossier {
  title: string;
  list: Dossier[];
  custom?: boolean;
  model?: any;
  data?: any;
  value: string | number;
  isNumber?: boolean;
  isDate?: boolean;
  constructor(title, list, value) {
    this.title = title;
    this.list = list;
    this.value = value;
  }
  static getEmptyDossier() {
    return {
      title: '####',
      value: null
    } as Dossier;
  }
  static set(title, value) {
    return {
      title: title,
      value: value
    };
  }
}

@Component({
  selector: 'app-dossier-bloc',
  templateUrl: './dossier-bloc.component.html',
  styleUrls: ['./dossier-bloc.component.scss']
})
export class DossierBlocComponent implements OnInit, OnChanges {
  amountFormat = new AmountFormatter();
  @Input()
  disabled;
  @Input()
  translateSuffix: string;
  @Input()
  nbColumns: number;
  globalFunc = globalFunc;
  @Input()
  items: Dossier[];
  constructor(public transServ: TranslateService) {}
  ngOnChanges(changes: SimpleChanges) {
    if (changes['items'] && changes['items'].currentValue) {
      if (this.items) {
        this.transServ.get(this.translateSuffix + 'SIREN').subscribe(t => {
          this.items.forEach(it => {
            it = this.translator(it);
            if (this.nbColumns && this.nbColumns > 0 && it.list) {
              while (it.list.length % this.nbColumns !== 0) {
                it.list.push(Dossier.getEmptyDossier() as Dossier);
              }
            }
            if (it.list) {
              it.list.forEach(item => (item = this.translator(item)));
            }
          });
        });
      }
    }
  }
  translator(it: Dossier) {
    if (
      it.title &&
      isDefined(this.getIntName(it.title)) &&
      this.translateSuffix &&
      this.transServ.instant(this.getIntName(it.title)) &&
      this.getIntName(it.title) !==
        this.transServ.instant(this.getIntName(it.title))
    ) {
      it.title = this.transServ.instant(this.getIntName(it.title));
    }
    return it;
  }
  ngOnInit() {}
  getIntName(str) {
    return this.translateSuffix + str
      .split(' ')
      .filter(s => s.length > 2)
      .join()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9]+/g, '')
      .toUpperCase();
  }
}
