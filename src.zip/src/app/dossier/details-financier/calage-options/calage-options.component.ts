import { Component, Input, OnInit, EventEmitter, Output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-calage-options',
  templateUrl: './calage-options.component.html',
  styleUrls: ['./calage-options.component.scss']
})
export class CalageOptionsComponent implements OnInit {
  @Input() calage: boolean;
  @Input() nbJoursCalage: number;
  @Input() label: string;

  @Output() calageChange = new EventEmitter();
  @Output() nbJoursCalageChange = new EventEmitter();

  public calageOptionsList: string[];

  constructor(private translateService: TranslateService) {
    this.calageOptionsList = [
      this.translateService.instant(
        'DOSSIER.DETAILF.OPTIONSF.CALAGE.OPTIONS.NON'
      ),
      this.translateService.instant(
        'DOSSIER.DETAILF.OPTIONSF.CALAGE.OPTIONS.OUI'
      )
    ];
  }

  ngOnInit() {}

  // try to convert calage to oui /non
  setSelectedCalageOption(): string {
    if (this.calage) {
      return this.calageOptionsList[1];
    }
    return this.calageOptionsList[0];
  }

  onCalageChange(e) {
    if (e === this.calageOptionsList[0]) {
      this.calage = false;
      this.nbJoursCalage = 0;
      this.nbJoursCalageChange.emit(0);
    } else {
      this.calage = true;
    }

    this.calageChange.emit(this.calage);
  }

  onNbJoursCalageChange(e) {
    this.nbJoursCalageChange.emit(e);
  }
}
