/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Component } from '@angular/core';

import { CalageOptionsComponent } from './calage-options.component';

describe('CalageOptionsComponent', () => {
  let component: CalageOptionsComponent;
  let fixture: ComponentFixture<CalageOptionsComponent>;

  // tslint:disable-next-line:component-selector
  @Component({ selector: 'app-multi-options', template: '' })
  class MutltiOptionsStubComponent {}

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CalageOptionsComponent, MutltiOptionsStubComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalageOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
