import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { MaterialModule } from './shared/modules/material/material.module';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { WidgetsModule } from './shared/widgets/widgets.module';

import { AppComponent } from './app.component';
/* Page Components */
import { HeaderComponent } from './layout/header/header.component';
import { AppLayoutComponent } from './layout/app-layout.component';
import { AppFooterComponent } from './layout/app-footer/app-footer.component';

/* Shared components */

/* Dossier */
import { DossierComponent } from './dossier/dossier.component';
import { DetailsFinancierComponent } from './dossier/details-financier/details-financier.component';
import { CalageOptionsComponent } from './dossier/details-financier/calage-options/calage-options.component';
import { SuiviDossierComponent } from './dossier/suivi-dossier/suivi-dossier.component';

/* Login */
import { LoginComponent } from './login/login.component';

/* Home */
import { HomeComponent } from './home/home.component';

/* DDF */
import { SirenComponent } from './ddf/siren/siren.component';
import { DdfNotificationComponent } from './ddf/ddf-notification/ddf-notification.component';
import { DdfDataSourceService } from './services/ddf/ddf-data-source.service';
import { WaitdialogComponent } from './ddf/waitdialog/waitdialog.component';
import { DdfPageComponent } from './ddf/ddf-page/ddf-page.component';

/* Services */
import { AuthService } from './services/auth/auth.service';
import { DdfService } from './services/ddf/ddf.service';
import { RatificationService } from './services/ddf/ratification.service';
import { EntrepriseService } from './services/entreprise/entreprise.service';
import { LoggedGuard } from './services/auth/guards/logged.guard';
import { RechercheService } from './services/recherche/recherche.service';

import { importType } from '@angular/compiler/src/output/output_ast';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule } from '@angular/common/http';

/* Components */
import { ComponentsModule } from './shared/components/components.module';
import { RequesterService } from './shared/services/requester/requester.service';
import { LoadConfigurationService } from './shared/services/load-configuration/load-configuration.service';
import { FlashSearchComponent } from './layout/header/flash-search/flash-search.component';
import { DureeProduitPipe } from './pipes/duree-produit.pipe';
import { AnneeMESPipe } from './pipes/annee-mes.pipe';
import { SearchDialogComponent } from './layout/header/flash-search/search-dialog/search-dialog.component';
import { ResultatsRechercheComponent } from './resultats-recherche/resultats-recherche.component';
import { MonCompteComponent } from './users/mon-compte/mon-compte.component';
import { DirectivesModule } from './directives/directives.module';
import { DossierBlocComponent } from './dossier/dossier-bloc/dossier-bloc.component';
import { ModelGeneratorComponent } from './classes/mock/model-generator/model-generator.component';
import { TemporalFreezeComponent } from './dossier/suivi-dossier/temporal-freeze/temporal-freeze.component';
import { DossierHeaderComponent } from './dossier/dossier-header/dossier-header.component';
import { CommentairesComponent } from './dossier/commentaires/commentaires.component';
// AoT requires an exported function for factories
export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient);
}
declare var require: any;
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    HeaderComponent,
    DossierComponent,
    DetailsFinancierComponent,
    CalageOptionsComponent,
    SirenComponent,
    WaitdialogComponent,
    AppLayoutComponent,
    AppFooterComponent,
    DdfNotificationComponent,
    DdfPageComponent,
    SearchDialogComponent,
    FlashSearchComponent,
    DureeProduitPipe,
    AnneeMESPipe,
    SearchDialogComponent,
    SuiviDossierComponent,
    MonCompteComponent,
    DossierBlocComponent,
    ResultatsRechercheComponent,
    DossierHeaderComponent,
    ModelGeneratorComponent,
    TemporalFreezeComponent,
    CommentairesComponent,
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule,
    MaterialModule,
    BrowserAnimationsModule,
    WidgetsModule,
    ComponentsModule,
    DirectivesModule,

    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    ReactiveFormsModule
  ],
  entryComponents: [
    WaitdialogComponent,
    DdfNotificationComponent,
    SearchDialogComponent
  ],
  providers: [
    AuthService,
    EntrepriseService,
    DdfService,
    LoggedGuard,
    RequesterService,
    LoadConfigurationService,
    DdfDataSourceService,
    RatificationService,
    RechercheService,
    // tslint:disable-next-line:max-line-length
    {
      provide: APP_INITIALIZER,
      useFactory: (config: LoadConfigurationService) => () => config.load(),
      deps: [LoadConfigurationService],
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
