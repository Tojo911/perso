import { Timestamp } from 'rxjs';

// this Method allow to convert an Object to a Map<key, value> type
export function convertToMap(obj: any): Map<string, any> {
  const map = new Map<string, any>();
  let result = null;

  if (obj) {
    Object.keys(obj).forEach(k => {
      result =
        typeof obj[k] === 'object'
          ? map.set(k, this.convertToMap(obj[k]))
          : map.set(k, obj[k]);
    });
  }
  return result;
}
export function unsubscriber(obs) {
  if (obs) {
    obs.unsubscribe();
  }
}
// this genericType-Method allow to convert an Object to a List
export function mapKpiObjToList<T>(obj: any, type: new (...args) => T) {
  const list: T[] = [];

  if (obj) {
    Object.keys(obj).forEach(k => {
      list.push(new type(k, obj[k]));
    });
  }
  return list;
}

export function mapTimestampToDate(timestamp: number): string {
  const dateObject = new Date(+timestamp);
  return (
    (dateObject.getDate() < 10
      ? '0' + dateObject.getDate()
      : dateObject.getDate()) +
    '/' +
    (dateObject.getMonth() + 1 < 10
      ? '0' + (dateObject.getMonth() + 1)
      : dateObject.getMonth() + 1) +
    '/' +
    (dateObject.getFullYear() + '').slice(-2)
  );
}
export function generateRandomValue(obj) {
  if ( typeof obj === 'string') {
    return randomizedString(randomNumber(3, 20));
  } else if (typeof obj === 'number') {
    return randomNumber(0, 99999999);
  } else if (obj instanceof  Date) {
    return randomdate(2012, 2030);
  } else if (obj instanceof  Date) {
    return randomdate(2012, 2030);
  } else if (obj instanceof  Array) {
   console.log(obj);
  }
   obj.forEach(field => field = generateRandomValue(field) );
   return obj;
}

export function randomizedString(size?) {

  return Math.random().toString(36).substring(size ? size : 7);
}

export function randomNumber(min, max) {
  if (min === max) {
    return min;
  }
  return Math.floor(Math.random() * max) + min;
}

export function randomdate(minYear, maxYEar) {
  return new Date(randomNumber(minYear, maxYEar), randomNumber(0, 11), randomNumber(1, 31));
}
