import { DossierInfo } from './dossier-info';

export class ItemTableInfo {
  numeroFL: number;
  numeroSIREN: number;
  raisonSociale: string;
  montant: number;
  dateSaisie: number;
  dateExpire: number;
  dateStatut: number;
  statut: string;
  statutCommercial: string;
  vendeur: string;

  // response may be DossierInfo, DossierMontage or SuiviParc
  constructor(response?: DossierInfo) {
    if (response) {
      this.numeroFL = response.id;
      this.numeroSIREN = response.numSiren;
      this.raisonSociale = response.raisonSociale;
      this.montant = response.montant
        ? this.getMontantFromResponse(response.montant)
        : response.montantRachat;
      this.dateSaisie = response.dateCreation
        ? response.dateCreation
        : response.dateSaisie;
      this.dateExpire = response.dateExpire;
      this.dateStatut = response.dateStatut;
      this.statut = response.statut.get('libelle');
      this.statutCommercial = response.statutCommercial;
      this.vendeur = response.vendeur ? response.vendeur.get('nom') : null;
    }
  }

  getMontantFromResponse(res) {
    return res ? (typeof res === 'object' ? res.montant : res) : res;
  }
}
