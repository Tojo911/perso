export interface DossierInfo {
  id?: number;
  numeroSIREN?: string;
  montant?: number;
  duree?: number;
  produitFinancier?: NatureCode;
  dateSaisie?: string;
  raisonSociale?: string;
  dateValiditeAccord?: string;
  media?: CanalCode;
  materiel?: MaterielCode;
  blocMateriel?: BlocMaterielInfo;
  blocPlanFinancement?: BlocPlanFinancementInfo;
  vendeur?: VendeurInfo;
  statut?: StatutDDFInfo;
  donneesInternes?: DonneesInternesInfo;
  blocContrepartie?: BlocContrepartieInfo;
  codeMedia?: MediaCode;
  blocSimulation?: BlocSimulationInfo;
  blocRatification?: BlocRatificationInfo;
  decision?: DecisionInfo;
  statutCommercial?: string;
  historiqueStatutCommercial?: string[];
  piecesJointes?: string[];
  statutInfo?: StatutInfo;
  topDirigeant?: boolean;
  infosDirigeant?: PersonneInfo;
  numeroFL?: number;
}

export interface CanalCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface MaterielCode {
  code?: string;
  libelle?: string;
}
export interface BlocMaterielInfo {
  neuf?: boolean;
  anneeMiseEnService?: number;
  valeurResiduelle?: number;
  options?: MaterielOptionsCode;
  niveauUtilisation?: MaterielNiveauUtilisationCode;
  tauxVR?: number;
}
export interface MaterielOptionsCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface MaterielNiveauUtilisationCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface BlocPlanFinancementInfo {
  premierLoyerMajore?: number;
  tauxVR?: number;
  montantVR?: number;
}
export interface StatutDDFInfo {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  commentaire?: string;
  date?: string;
  gestionnaire?: UtilisateurFrontInfo;
  sousStatutInfo?: SousStatutInfo;
  ordre?: number;
}
export interface UtilisateurFrontInfo {
  id?: number;
  login?: string;
  prenomNom?: string;
  typeVendeur?: number;
  fax?: string;
  mail?: string;
}
export interface BlocContrepartieInfo {
  enseigne?: string;
  codeNaf?: string;
  libelleNaf?: string;
  categorieJuridique?: string;
  formeJuridique?: string;
  adresseEtablissement?: string[];
  effectif?: number;
  chiffreAffaires?: number;
  anneeChiffreAffaires?: number;
  coteBDF?: string;
}
export interface MediaCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface BlocSimulationInfo {
  derogation?: boolean;
  motifDerogation?: string;
  typeSimulation?: string;
}
export interface BlocRatificationInfo {
  oid?: number;
}
export interface DecisionInfo {
  decision?: string;
  commentaireExterne?: string;
  commentaireInterne?: string;
  motif?: string;
}
export interface StatutInfo {
  oid?: number;
}

export interface CiviliteCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}

export interface DossierInfo2 {
  id?: number;
  numeroSIREN?: string;
  montant?: number;
  duree?: number;
  produitFinancier?: NatureCode;
  dateSaisie?: string;
  raisonSociale?: string;
  dateValiditeAccord?: string;
  media?: CanalCode;
  materiel?: MaterielCode;
  blocMateriel?: BlocMaterielInfo;
  blocPlanFinancement?: BlocPlanFinancementInfo;
  vendeur?: VendeurInfo;
  statut?: StatutDDFInfo;
  donneesInternes?: DonneesInternesInfo;
  blocContrepartie?: BlocContrepartieInfo;
  codeMedia?: MediaCode;
  blocSimulation?: BlocSimulationInfo;
  blocRatification?: BlocRatificationInfo;
  decision?: DecisionInfo;
  statutCommercial?: string;
  historiqueStatutCommercial?: string[];
  piecesJointes?: string[];
  statutInfo?: StatutInfo;
  topDirigeant?: boolean;
  infosDirigeant?: PersonneInfo;
  numeroFL?: number;
}

export interface AbonnementInfos {
  actif?: boolean;
  dateDebut?: number;
  oid?: number;
  interdit?: boolean;
  ratificationAuto?: boolean;
}
export interface AgenceInfos {
  identifiantEKIP?: string;
  identifiantSDMI?: string;
  libelle?: string;
  oid?: number;
}
export interface ApporteurInfos {
  canalApporteurCode?: string;
  canalApporteurSigle?: string;
  oid?: number;
  libelle?: string;
  segmentation?: string;
  societeGestion?: string;
  societeGestionCreditBail?: string;
}
export interface CategorieInfos {
  oid?: number;
  sigle?: string;
  codeinterface?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
}
export interface MarcheInfos {
  code?: string;
  libelle?: string;
  oid?: number;
  vendor?: boolean;
  groupeMarcheLibelle?: string;
  groupeMarcheOid?: number;
  groupeMarche?: {
    oid?: number;
    libelle?: string;
    actif?: boolean;
    accesPrmServicing?: boolean;
  };
  codeMarcheExt?: string;
}
export interface NatureInfos {
  oid?: number;
  sigle?: string;
  codeinterface?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
}
export interface SousNatureInfos extends NatureInfos {
  nature?: NatureInfos;
}
export interface ProduitInfos {
  oid?: number;
  categorie?: CategorieInfos;
  nature?: NatureInfos;
  montantMin?: number;
  montantMax?: number;
  dureeMin?: number;
  dureeMax?: number;
  dureeOffre?: number;
  devise?: string;
  libelle?: string;
  marche?: MarcheInfos;
  actif?: boolean;
  sousNature?: SousNatureInfos;
  materielObligatoire?: boolean;
  planFinancementObligatoire?: boolean;
  garantieObligatoire?: boolean;
}
export interface UserInfo {
  id?: number;
  login?: string;
  prenomNom?: string;
  typeVendeur?: number;
  fax?: string;
  mail?: string;
  firstname?: string;
  lastname?: string;
  username?: string;
  domain?: string;
  group?: string;
  agence?: AgenceInfos;
  apporteur?: ApporteurInfos;
  vendeur?: VendeurInfos;
  abonnement?: AbonnementInfos;
  marche?: MarcheInfos;
  inPerimetre?: boolean;
  produits?: ProduitInfos[];
  roles?: string[];
  materielDefault?: string;
  catalogueDefault?: string;
  authorities?: [
    {
      authority?: string;
    }
  ];
}

export interface VendeurInfos {
  actif?: boolean;
  nbEchecs?: number;
  suspendu?: boolean;
}
export interface StatutCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface AffaireInfo {
  id?: number;
  societeGestion?: string;
  categorieAffaire?: string;
  statut?: StatutCode;
  duree?: number;
  modeReglement?: ModeReglementCode;
  client?: ClientInfo;
  elements?: ElementInfo[];
  referenceInterne?: string;
  nomVendeur?: string;
  numVendeur?: string;
  affaireSDMI?: boolean;
  numAffaireEntretien?: string;
  montantRachat?: number;
  codeReseau?: string;
  codeDistrict?: string;
  codeRegionInt?: string;
  codeRegionExt?: string;
  codeSecteur?: string;
  numApporteur?: string;
  nomApporteur?: string;
  tiersRacheteur?: string;
  dateArretFacturation?: string;
  modeReglementPremierLoyer?: ModeReglementCode;
  numAffaireTransfert?: string;
  isAffaireTransfere?: boolean;
  codeOffre?: string;
  libelleCodeOffre?: string;
  firstElement?: ElementInfo;
}
export interface ElementInfo {
  id?: number;
  numeroElement?: number;
  loyerFinancier?: number;
  loyerPrestations?: number;
  loyerFinHT?: number;
  loyerPrestationServiceHT?: number;
  terme?: TermeCode;
  primeAssurances?: number;
  loyerGlobal?: number;
  dateProchaineEcheance?: string;
  referenceApporteur?: string;
  prestationLMAI?: string;
  periodicite?: PeriodiciteCode;
  dateDebutLocation?: string;
  dateFinLocation?: string;
  nombreLoyersRestants?: number;
  baseLocInit?: number;
  tauxRendementInterne?: number;
  tauxRendementInterneActuariel?: number;
  tauxNominal?: number;
  tegActuariel?: number;
  montantVR?: number;
  montantVRRepreneur?: number;
  pourcentVRClient?: number;
  pourcentVRFournisseur?: number;
  pourcentVRAutre?: number;
  datePremiereEcheance?: string;
  datePublicationGreffe?: string;
  termeProchaineEcheance?: TermeCode;
  nomFournisseurEntretien?: string;
  numeroFournisseurEntretien?: string;
  codeContratPrestation?: string;
  codeContratAssurance?: string;
  biens?: string[];
}

export interface RatificationInfo {
  id?: number;
  montant?: number;
  duree?: number;
  numeroFlashLease?: number;
  statut?: StatutMontageInfo;
  client?: ClientInfo;
  userCreateur?: UtilisateurFrontInfo;
  dateCreation?: string;
  vendeur?: VendeurInfo;
  typeMontage?: string;
  produitCommercial?: ProduitCommercialInfo;
  fraisDeMontage?: number;
  criteres?: CriteresMontageInfo;
  isMultiPalier?: boolean;
  chrono?: number;
  motifDerogation?: MotifDerogationCode;
  clientDetail?: BlocContrepartieInfo;
  garanties?: GarantieDDFInfo[];
  ratificationCourante?: boolean;
  materielsFinancement?: MaterielFinancementInfo[];
  fournisseurs?: FournisseurPropositionInfo[];
  planFinancement?: PlanFinancementInfo;
  planFinancementDecision?: PlanFinancementInfo;
  rachat?: RachatDDFInfo;
  calage?: CalageDDFInfo;
  prestations?: PrestationInfo[];
  autreMajorations?: AutreMajorationInfo[];
  referenceApporteur?: string;
  topDerogation?: boolean;
  bareme?: BaremeInfo;
  donneesInternes?: DonneesInternesInfo;
  modeleContrat?: ModeleContratCode;
  fluxRatification?: FluxRatificationCode;
  typeOperation?: string;
  tauxVrApparente?: number;
  montantVrApparente?: number;
  typeRatification?: string;
  commentairePalier?: string;
  pourGrandCompte?: boolean;
  pourAdministration?: boolean;
  statutRatification?: StatutRatificationInfo;
  vendeurRatification?: VendeurInfo;
  flagEcheancier?: boolean;
  commissionApporteur?: number;
  rachatIds?: string[];
  fromModif?: boolean;
  offreRachatLabel?: string;
  montantFraisDeMontage?: MontantInfo;
  prctFinancement?: number;
  codeCatalogue?: string;
  codeMateriel?: string;
  designation?: string;
  identifiantMateriel?: string;
  fraisDeMontageForce?: boolean;
  fmontantDispo?: number;
}
export interface AdresseCompleteInfo {
  adresse?: string;
  complementAdresse?: string;
  codePostal?: string;
  ville?: string;
  pays?: string;
}
export interface StatutMontageInfo {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  commentaire?: string;
  date?: string;
  gestionnaire?: UtilisateurFrontInfo;
  sousStatutInfo?: SousStatutInfo;
  ordre?: number;
}

export interface SousStatutInfo {
  code?: string;
  commentaire?: string;
  libelle?: string;
}
export interface ClientInfo {
  id?: number;
  referenceTiers?: string;
  siren?: string;
  raisonSociale?: string;
  soldeCompte?: number;
}
export interface VendeurInfo {
  id?: number;
  nom?: string;
  prenom?: string;
  fax?: string;
  mail?: string;
  agence?: AgenceInfo;
  telephone?: string;
  actif?: boolean;
  dateEntreeAgence?: string;
  dateSortieAgence?: string;
}
export interface AgenceInfo {
  id?: number;
  libelle?: string;
  apporteur?: ApporteurInfo;
  listVendeurs?: string[];
}
export interface ApporteurInfo {
  id?: number;
  libelle?: string;
  marche?: MarcheInfo;
  listAgences?: string[];
}
export interface MarcheInfo {
  id?: number;
  libelle?: string;
  groupe?: GroupeMarchesInfo;
  listApporteurs?: string[];
  code?: string;
}
export interface GroupeMarchesInfo {
  id?: number;
  libelle?: string;
}
{
}
export interface ProduitCommercialInfo {
  code?: string;
  libelle?: string;
  ordre?: number;
  modeleContrat?: ModeleContratCode;
  produitFinancier?: NatureCode;
}
export interface ModeleContratCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  natureCode?: NatureCode;
  groupeMarcheInfo?: GroupeMarchesInfo;
  ordre?: number;
}
export interface NatureCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface CriteresMontageInfo {
  modeExpression?: string;
  fraisDeMontage?: number;
  minimumFraisDeMontage?: number;
  maximumFraisDeMontage?: number;
}
export interface MotifDerogationCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}

export interface GarantieDDFInfo {
  code?: string;
  libelle?: string;
}
export interface MaterielFinancementInfo {
  id?: number;
  designation?: string;
  marque?: string;
  type?: string;
  numeroSerie?: string;
  anneeMiseEnService?: number;
  materielNeuf?: boolean;
  montant?: MontantInfo;
  nbMateriels?: number;
  tauxTva?: number;
  fournisseurFromProp?: FournisseurPropositionInfo;
  codeCatalogue?: string;
  codeMateriel?: string;
  identifiant?: string;
  principal?: boolean;
}
export interface MontantInfo {
  montant?: number;
  devise?: string;
}
export interface FournisseurPropositionInfo {
  numeroFournisseur?: number;
  oidFournisseur?: number;
  nom?: string;
  adresse?: AdresseCompleteInfo;
  numeroSiren?: string;
}
export interface PlanFinancementInfo {
  montantFinancement?: number;
  periode?: number;
  produitFinancier?: NatureCode;
  produitCommercial?: ProduitCommercialInfo;
  duree?: number;
  taux?: number;
  tauxRefinancement?: number;
  tauxMarge?: number;
  periodiciteTaux?: PeriodiciteTauxCode;
  tauxVR?: number;
  montantVR?: number;
  tauxPremierLoyerMajore?: number;
  montantPremierLoyerMajore?: number;
  loyerFinancierMajore?: number;
  loyerFinancierBareme?: number;
  loyerToutInclus?: number;
  modeAmortissement?: ModeAmortissementCode;
  terme?: TermeCode;
  periodicite?: PeriodiciteCode;
  modeReglement?: ModeReglementCode;
  clauseIndexation?: string;
  modeSaisieCalcul?: string;
  tauxVrApparente?: number;
  montantVrApparente?: number;
  paliers?: PalierInfo[];
  multiPaliers?: boolean;
  prctFinancement?: number;
  tauxTVA?: number;
  tauxTEAG?: number;
}
export interface PeriodiciteTauxCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  duree?: number;
  ordre?: number;
}
export interface ModeAmortissementCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface TermeCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface PeriodiciteCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  duree?: number;
  ordre?: number;
}
export interface ModeReglementCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  codeMajoration?: string;
  ordre?: number;
}
export interface PalierInfo {
  indice?: number;
  nbEcheances?: number;
  periodicite?: PeriodiciteCode;
  terme?: TermeCode;
  loyer?: number;
  encoursInitial?: number;
  encoursInitialPrct?: number;
  ratio?: number;
  encoursFinal?: number;
  encoursFinalPrct?: number;
  methodeCalcul?: string;
}
export interface RachatDDFInfo {
  montantGlobal?: number;
  dateRachat?: string;
  numerContrat?: string;
  soldeDu?: number;
  contratBailleurExterne?: number;
}
export interface CalageDDFInfo {
  nbMoisCalage?: number;
  nbJoursCalage?: number;
  dateFinancement?: string;
  topCalage?: boolean;
}
export interface PrestationInfo {
  code?: string;
  libelle?: string;
  ordre?: number;
  id?: number;
  catalogue?: CataloguePrestationInfo;
  modeSaisi?: string;
  pourcentMajoration?: number;
  montantMajoration?: number;
  pourcentMontantMajoration?: number;
  borneMax?: number;
  borneMin?: number;
  valeurParDefaut?: number;
  ageMaxMateriel?: number;
  modeExpressionEkip?: string;
  valeurMaxPourcentLoyer?: number;
  montantMinDossier?: number;
  montantMaxDossier?: number;
  type?: string;
}
export interface CataloguePrestationInfo {
  code?: string;
  id?: number;
  apporteur?: ApporteurInfo;
  libelle?: string;
}
export interface AutreMajorationInfo {
  code?: string;
  libelle?: string;
  ordre?: number;
  id?: number;
  catalogue?: CatalogueAutreMajorationInfo;
  modeSaisi?: string;
  pourcentMajoration?: number;
  montantMajoration?: number;
  pourcentMontantMajoration?: number;
  borneMax?: number;
  borneMin?: number;
  valeurParDefaut?: number;
  valeurMaxPourcentLoyer?: number;
}
export interface CatalogueAutreMajorationInfo {
  code?: string;
  id?: number;
  apporteur?: ApporteurInfo;
  libelle?: string;
}
export interface BaremeInfo {
  code?: string;
  codeCampagne?: string;
  libelleCampagne?: string;
  taux?: number;
  terme?: string;
  modeAmortissement?: string;
  derogation?: boolean;
  type?: string;
  libelleTypeBareme?: string;
  clauseIndexation?: string;
  codeSpread?: string;
  libelleSpread?: string;
}
export interface DonneesInternesInfo {
  gestionnaireSaisie?: string;
  commentaireInterne?: string;
  gestionnaireStatut?: string;
  appel?: boolean;
}
export interface FluxRatificationCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface StatutRatificationInfo {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  commentaire?: string;
  date?: string;
  gestionnaire?: UtilisateurFrontInfo;
  ordre?: number;
}

export interface DossierRatifieInfo {
  id?: number;
  numeroSIREN?: string;
  montant?: number;
  duree?: number;
  produitFinancier?: NatureCode;
  dateSaisie?: string;
  raisonSociale?: string;
  dateValiditeAccord?: string;
  media?: CanalCode;
  materiel?: MaterielCode;
  blocMateriel?: BlocMaterielInfo;
  blocPlanFinancement?: BlocPlanFinancementInfo;
  vendeur?: VendeurInfo;
  statut?: StatutDDFInfo;
  donneesInternes?: DonneesInternesInfo;
  blocContrepartie?: BlocContrepartieInfo;
  codeMedia?: MediaCode;
  blocSimulation?: BlocSimulationInfo;
  blocRatification?: BlocRatificationInfo;
  decision?: DecisionInfo;
  statutCommercial?: string;
  historiqueStatutCommercial?: string[];
  piecesJointes?: string[];
  statutInfo?: StatutInfo;
  topDirigeant?: boolean;
  infosDirigeant?: PersonneInfo;
  ratifications?: RatificationInfo[];
  numeroFL?: number;
}

export interface ElementFinancierInfo {
  periodicite?: PeriodiciteCode;
  duree?: number;
  montant?: MontantInfo;
  taux?: number;
  terme?: TermeCode;
  modeAmortissement?: ModeAmortissementCode;
  natureCode?: NatureCode;
  prctFinancement?: number;
  datePremierLoyer?: string;
  montantOptionAchat?: number;
  tauxOptionAchat?: number;
}

export interface ContratInfo {
  id?: number;
  montant?: number;
  duree?: number;
  numeroFlashLease?: number;
  statut?: StatutMontageInfo;
  client?: ClientInfo;
  userCreateur?: UtilisateurFrontInfo;
  dateCreation?: string;
  vendeur?: VendeurInfo;
  typeMontage?: string;
  produitCommercial?: ProduitCommercialInfo;
  fraisDeMontage?: number;
  criteres?: CriteresMontageInfo;
  isMultiPalier?: boolean;
  elementFinancier?: ElementFinancierInfo;
  etablissementClient?: EtablissementClientInfo;
  facturation?: FacturationInfo;
  prestationsRatification?: PrestationInfo[];
  prestationsContrat?: PrestationInfo[];
  observationsParticulieres?: string;
  livraison?: LivraisonInfo;
  materiels?: MaterielContratInfo[];
  loa?: boolean;
  loyerMajore?: number;
  chrono?: number;
  multiPalier?: boolean;
  ratification?: RatificationInfo;
  historiquesDossiers?: HistoEditionContratInfo[];
}
export interface EtablissementClientInfo {
  siren?: string;
  nom?: string;
  assujettiTaxePro?: boolean;
  codeNaf?: string;
  libelleNaf?: string;
  adresseComplete?: AdresseCompleteInfo;
  identifiantFormeJuridique?: number;
  formeJuridique?: string;
  numeroTelephone?: string;
  dateDebutActivite?: string;
  chiffreAffaire?: string;
  effectif?: string;
  fondsCommerce?: FondsCommerceCode;
  loyer?: number;
  dirigeant?: PersonneInfo;
  representantClient?: RepresentantClientInfo;
}
export interface FondsCommerceCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface PersonneInfo {
  civilite?: CiviliteCode;
  nom?: string;
  nomJeuneFille?: string;
  prenom?: string;
  dateNaissance?: string;
  lieuNaissance?: string;
  situationFamiliale?: SituationFamilialeCode;
}
export interface RepresentantClientInfo {
  civilite?: CiviliteCode;
  nom?: string;
  nomJeuneFille?: string;
  prenom?: string;
  dateNaissance?: string;
  lieuNaissance?: string;
  situationFamiliale?: SituationFamilialeCode;
  qualite?: string;
  ville?: string;
  numeroTelephone?: string;
  comptableAssignataire?: string;
  ordonnateur?: string;
}
export interface SituationFamilialeCode {
  code?: string;
  libelle?: string;
  type?: string;
  defaut?: boolean;
  ordre?: number;
}
export interface FacturationInfo {
  adresseCompleteFacturation?: AdresseCompleteInfo;
  banque?: BanqueInfo;
  nomPersonneAJoindre?: string;
  numeroTelephonePersonneAJoindre?: string;
  rib?: RibInfo;
}
export interface BanqueInfo {
  nomBanque?: string;
  nomAgenceBanque?: string;
  adresseComplete?: AdresseCompleteInfo;
}
export interface RibInfo {
  codeBanque?: string;
  codeGuichet?: string;
  numeroCompte?: string;
  cleRib?: string;
  iban1?: string;
  iban2?: string;
  iban3?: string;
  iban4?: string;
  iban5?: string;
  iban6?: string;
  iban7?: string;
  iban8?: string;
  iban9?: string;
  bic?: string;
  typeRIB?: string;
  rib?: string;
  iban?: string;
}
export interface LivraisonInfo {
  adresse?: AdresseCompleteInfo;
  datePrevisionnelle?: string;
  fournisseurs?: FournisseurInfo[];
}
export interface MaterielContratInfo {
  id?: number;
  designation?: string;
  marque?: string;
  type?: string;
  numeroSerie?: string;
  anneeMiseEnService?: number;
  materielNeuf?: boolean;
  montant?: MontantInfo;
  nbMateriels?: number;
  tauxTva?: number;
  fournisseurFromProp?: FournisseurPropositionInfo;
  codeCatalogue?: string;
  codeMateriel?: string;
  identifiant?: string;
  fournisseur?: FournisseurInfo;
  montantHT?: MontantInfo;
  principal?: boolean;
}
export interface HistoEditionContratInfo {
  date?: string;
  action?: string;
  gestionnaire?: User;
  chrono?: string;
  emmetteur?: User;
  destinataires?: string[];
}
export interface User {
  identifiant?: string;
  nomPrenom?: string;
  responsableId?: string;
}
export interface FournisseurInfo {
  numeroFournisseur?: number;
  oidFournisseur?: number;
  nom?: string;
  adresse?: AdresseCompleteInfo;
  numeroSiren?: string;
}
export interface BienInfo {
  designation?: string;
  id?: string;
  immobilisation?: string;
  marque?: string;
  modele?: string;
  montant?: number;
  nature?: string;
  nomFournisseur?: string;
  numeroFournisseur?: string;
  numeroSerie?: string;
  typeAmortissement?: string;
}

export interface CommentaireDecisionCommerciale {
  oid?: number;
  dossier?: Dossier;
  messageInterne?: string;
  messageExterne?: string;
  dateDeCreation?: string;
  user?: User;
}
export interface PFI {
  loyer?: Montant;
  duree?: number;
  montant?: Montant;
  tauxMajorationPremierLoyer?: number;
  mtPremierLoyer?: Montant;
  tauxVR?: number;
  loyerFinancierBareme?: Montant;
  tauxDepotGarantie?: number;
  amortissement?: TypeAmortissement;
  modeReglement?: ModeReglement;
  nature?: Nature;
  taux?: Taux;
  taeg?: Taux;
  terme?: Terme;
  loyerFinancierMajore?: Montant;
  periodicite?: Periodicite;
  sousNature?: SousNature;
  qualification?: QualificationPFI;
  oid?: number;
  dtFirstEcheance?: string;
  dtLastEcheance?: string;
  coefficient?: number;
  nbPeriodes?: number;
  tauxTVA?: number;
  clauseIndexation?: string;
  modeSaisieCalcul?: string;
  multiPaliers?: boolean;
  paliers?: string[];
  engagementReprise?: any; // EngagementReprise;
  montantVR?: Montant;
  prctFinancement?: number;
  tauxRefinancement?: number;
  tauxMarge?: number;
  periodiciteTaux?: Periodicite;
  prestationMaintenance?: string;
  tauxVrApparente?: number;
  tauxMajorationPremierLoyerDoublePrecision?: number;
  tauxDepotGarantieDoublePrecision?: number;
  prctFinancementDoublePrecision?: number;
  tauxRefinancementDoublePrecision?: number;
  tauxVRDoublePrecision?: number;
  tauxMargeDoublePrecision?: number;
  tauxTVADoublePrecision?: number;
}
export interface TypeAmortissement {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
}
export interface ModeReglement {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  codeMajoration?: string;
}
export interface Nature {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
}
export interface Taux {
  valeur?: number;
  description?: TauxDescriptif;
  valeurDoublePrecision?: number;
}
export interface TauxDescriptif {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
}
export interface Terme {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
}
export interface Periodicite {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  duree?: number;
}
export interface SousNature {
  oid?: number;
  actif?: boolean;
  libelle?: string;
  sigle?: string;
  ordre?: string;
  nature?: Nature;
}
export interface QualificationPFI {
  note?: NoteInterne;
  remise?: NiveauRemise;
}
export interface NoteInterne {
  valeur?: string;
  pourcentage?: number;
  dateNotation?: string;
  dateValidite?: string;
  methode?: string;
  versionMoteur?: string;
  nomModele?: string;
  versionModele?: string;
  prioriteModele?: number;
  equivalentSG?: string;
  noteScore?: number;
}
export interface NiveauRemise {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
}
export interface DecisionDossier {
  decision?: string;
  avis?: string;
  motif?: string;
  informationMAJ?: InfoMAJ;
  oidMotif?: number;
  pfi?: PFI;
  numeroEnveloppeLC?: number;
  numeroEnveloppeER?: number;
  dateValidite?: string;
  messageClient?: string;
  dateRevision?: string;
  commentaireRevision?: string;
  identifiantUtilisateurRevision?: string;
  nomPrenomUtilisateurRevision?: string;
  dateMajRevision?: string;
  eligibleCOSME?: boolean;
  dateValiditeReelle?: string;
}
export interface Categorie {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
}
export interface ReleveGestion {
  actifs?: Montant;
  impayes?: Montant;
  dateDerniereFactureEmise?: string;
  dateProchaineFacture?: string;
  positionLibelle?: string;
  positionCode?: number;
  teg?: Taux;
  tegActuariel?: Taux;
}
export interface Simulation {
  oid?: number;
  commentaire?: string;
  referenceApporteur?: string;
  pfi?: PlanFinancementSimulation;
  autresMajorations?: string[];
  prestations?: string[];
  dateCreation?: string;
  userCreation?: User;
  bareme?: Bareme;
  canal?: string;
  canalName?: string;
  marche?: string;
  marcheName?: string;
  derogation?: boolean;
  motifDeDerogation?: any; // MotifDerogation;
  typeSimulation?: string;
  action?: string;
  numeroFlashLease?: number;
  calage?: Calage;
  rachatTopUp?: Rachat;
  methodeCalcul?: string;
  clientAssujettiTaxePro?: boolean;
  tauxVrApparente?: number;
  montantVrApparente?: Montant;
  garanties?: string[];
  flagEcheancier?: boolean;
  proposition?: any; // PropositionCommerciale;
  montantFraisMontage?: Montant;
  isForcerFraisMontage?: boolean;
  commentairePalier?: string;
  fournisseurs?: string[];
  materielsFinancement?: string[];
  produitCommercial?: any; // ProduitCommercial;
  rachats?: string[];
  commentaireRachat?: string;
  montantFraisGreffe?: Montant;
  isForcerFraisGreffe?: boolean;
  isEditionTTC?: boolean;
  destinataire?: string;
  dirigeant?: ChefEntreprise;
  isGrandClient?: boolean;
  demandeMultiPaliers?: string;
  motifDerogation?: string;
  clientTaxePro?: boolean;
  tauxVrApparenteDoublePrecision?: number;
}
export interface PlanFinancementSimulation {
  loyer?: Montant;
  duree?: number;
  montant?: Montant;
  tauxMajorationPremierLoyer?: number;
  mtPremierLoyer?: Montant;
  tauxVR?: number;
  loyerFinancierBareme?: Montant;
  tauxDepotGarantie?: number;
  amortissement?: TypeAmortissement;
  modeReglement?: ModeReglement;
  nature?: Nature;
  taux?: Taux;
  taeg?: Taux;
  terme?: Terme;
  loyerFinancierMajore?: Montant;
  periodicite?: Periodicite;
  sousNature?: SousNature;
  qualification?: QualificationPFI;
  oid?: number;
  dtFirstEcheance?: string;
  dtLastEcheance?: string;
  coefficient?: number;
  nbPeriodes?: number;
  tauxTVA?: number;
  clauseIndexation?: string;
  modeSaisieCalcul?: string;
  multiPaliers?: boolean;
  paliers?: string[];
  engagementReprise?: any; // EngagementReprise;
  montantVR?: Montant;
  prctFinancement?: number;
  tauxRefinancement?: number;
  tauxMarge?: number;
  periodiciteTaux?: Periodicite;
  prestationMaintenance?: string;
  tauxVrApparente?: number;
  montantPremierLoyer?: Montant;
  montantVrApparente?: Montant;
  tauxMajorationPremierLoyerDoublePrecision?: number;
  tauxDepotGarantieDoublePrecision?: number;
  prctFinancementDoublePrecision?: number;
  tauxRefinancementDoublePrecision?: number;
  tauxVRDoublePrecision?: number;
  tauxMargeDoublePrecision?: number;
  tauxTVADoublePrecision?: number;
}
export interface Bareme {
  dureeMin?: number;
  dureeMax?: number;
  montantMin?: Montant;
  vr?: number;
  montantMax?: Montant;
  taux?: number;
  encoursMax?: number;
  encoursMin?: number;
  categorieAffaire?: Nature;
  code?: string;
  assujettiTaxeProfessionelle?: boolean;
  periodicite?: Periodicite;
  vrMax?: number;
  vrMin?: number;
  terme?: Terme;
  typeAmortissement?: TypeAmortissement;
  encours?: number;
  apporteurs?: string[];
  marches?: string[];
  type?: string;
  montant?: number;
  clauseIndexation?: string;
  produitFinancier?: Nature;
  codeCampagne?: string;
  codeSpread?: string;
  libelleSpread?: string;
  libelleCampagne?: string;
  montantVr?: number;
}
export interface Ratification {
  oid?: number;
  chrono?: number;
  gestionnaire?: User;
  societeGestion?: string;
  dateCreation?: string;
  planFinancement?: PlanFinancementSimulation;
  rachatTopUp?: Rachat;
  calage?: Calage;
  prestations?: string[];
  autresMajorations?: string[];
  garanties?: string[];
  dossier?: Dossier;
  taxePro?: boolean;
  materiels?: string[];
  fournisseurs?: string[];
  commentaire?: string;
  referenceApporteur?: string;
  modeleFlux?: any; // FluxRatification;
  bareme?: Bareme;
  modeleContrat?: any; // ModeleContrat;
  tauxVrApparente?: number;
  montantVrApparente?: Montant;
  typeRatification?: string;
  derogation?: boolean;
  motifDerogation?: any; // MotifDerogation;
  methodeCalcul?: string;
  dateValidite?: string;
  commentairePalier?: string;
  etat?: Etat;
  vendeur?: Vendeur;
  produitCommercial?: any; // ProduitCommercial;
  flagEcheancier?: boolean;
  commentaireRachat?: string;
  montantFraisMontage?: Montant;
  fraisMontageForce?: boolean;
  rachats?: string[];
  montantFraisGreffe?: Montant;
  isForcerFraisGreffe?: boolean;
  destinataire?: string;
  tauxVrApparenteDoublePrecision?: number;
}
export interface Rachat {
  montant?: Montant;
  dateRachat?: string;
  numeroContrat?: string;
  soldeDu?: Montant;
  contratBailleurExterne?: Montant;
}
export interface Calage {
  topCalage?: boolean;
  dateFinancement?: string;
  nbMoisCalage?: number;
  nbJoursCalage?: number;
}
export interface Contrat {
  oid?: number;
  ratification?: Ratification;
  fournisseurs?: string[];
  prestations?: string[];
  materielsFinancement?: string[];
  planFinancement?: PFI;
  observation?: string;
  dossier?: Dossier;
  idDocument?: string;
  chrono?: number;
  dateCreation?: string;
  dateLivraison?: string;
  gestionnaire?: User;
  etablissement?: Etablissement;
  chiffreAffaire?: string;
  effectif?: string;
  montantFraisMontage?: Montant;
  montantFraisGreffe?: Montant;
  editionTTC?: boolean;
}
export interface Dossier {
  affaire?: Affaire;
  appel?: number;
  numDossier?: number;
  numAcquis?: string;
  dateMeL?: string;
  qualification?: QualificationDossier;
  dateCreation?: string;
  pfi?: PFI;
  garanties?: string[];
  decision?: DecisionDossier;
  etat?: Etat;
  statutCommercial?: Etat;
  categorie?: Categorie;
  oid?: number;
  objetsFinancements?: string[];
  numSystemGestion?: string;
  idOGAffaire?: string;
  idOGContrat?: string;
  idOGInterneContrat?: string;
  dosRefGestionState?: string;
  releve?: ReleveGestion;
  simulation?: Simulation;
  histoSimulations?: string[];
  ratification?: Ratification;
  ratifications?: string[];
  contrat?: Contrat;
  commentaires?: string[];
  montantUtilise?: Montant;
  codeGroupeMarcheMateriel?: string;
  codeMarcheMateriel?: string;
  topDeal?: boolean;
  canalAcqLBP?: string;
  marcheAcqLBP?: string;
  typeDemande?: string;
  preQualif?: string;
  datePreQualif?: string;
  qualificationRisque?: QualificationRisque;
  garantieCOSME?: boolean;
  dureeAccordPourCosme?: number;
  decisionOAPR?: DecisionOAPR;
  enveloppeDecision?: EnveloppeDDF;
  codeAff?: string;
  bonneQualitePayeur?: boolean;
  nombreUnivers?: string;
  ancienneteClient?: string;
  topDirigeant?: boolean;
  infosComplementaire?: InfosComplementaire;
  notificationBPM?: string;
  acteComplexe?: boolean;
  ddf?: boolean;
  reamenagement?: boolean;
  autre?: boolean;
  transfert?: boolean;
  eligibleCosme?: boolean;
  alreadyAppel?: boolean;
}
export interface EnveloppeDDF {
  typeEnveloppe?: string;
  libelle?: string;
  raisonSociale?: string;
  numero?: number;
  siren?: string;
  dateDebutValidite?: string;
  dateFinValidite?: string;
  numeroODE?: number;
  note?: NoteInterne;
  segmentation?: Segmentation;
  qualification?: QualificationAffaire;
}
export interface Affaire {
  numAffaire?: number;
  numAcquis?: string;
  dateCreation?: string;
  dossiers?: Dossier[];
  client?: Etablissement;
  garanties?: string[];
  etat?: Etat;
  interlocuteurs?: string[];
  numSystemGestion?: string;
  systemGestion?: string;
  societeGestion?: string;
  numSocieteTechnique?: string;
  mtAffaire?: Montant;
  oid?: number;
  projet?: Projet;
  qualification?: QualificationAffaire;
  autreIntervenantPM?: Etablissement;
}
{
}
export interface Etablissement {
  oid?: number;
  oidGestion?: string;
  typePersonne?: string;
  domiciliation?: Domiciliation;
  facturation?: Coordonnees;
  livraison?: Livraison;
  numeroSiret?: any; // Siret;
  enseigne?: string;
  trancheEffectif?: string;
  dateCreation?: string;
  codeSingularite?: string;
  coordonnees?: Coordonnees;
  origine?: string;
  nature?: string;
  codeNaf?: string;
  caractereSiege?: boolean;
  effectif?: number;
  exploitantProduction?: string;
  codeParticipationParticuliereProduction?: string;
  codeNatureActivite?: string;
  codeSurfaceActivite?: string;
  codeLieuActivite?: string;
  entreprise?: Entreprise;
}
export interface Domiciliation {
  banque?: string;
  agence?: string;
  personneAJoindre?: PersonnePhysique;
  rib?: RIB;
  coordonnees?: Coordonnees;
  oid?: number;
}
export interface PersonnePhysique {
  oid?: number;
  oidGestion?: string;
  typePersonne?: string;
  domiciliation?: Domiciliation;
  facturation?: Coordonnees;
  livraison?: Livraison;
  departementNaissance?: string;
  villeNaissance?: string;
  dateNaissance?: string;
  nomJF?: string;
  nom?: string;
  prenom?: string;
  paysNaissance?: Pays;
  identifiantBdf?: string;
}
export interface Coordonnees {
  numeroTelephone?: string;
  numeroFax?: string;
  adresseEMail?: string;
}
export interface Livraison {
  dateLivraison?: string;
  adresse?: Coordonnees;
}
export interface Pays {
  codeAlpha2Iso?: string;
  codeAlpha3Iso?: string;
  nomIso?: string;
  libelle?: string;
  codeNumeriqueIso?: number;
}
export interface RIB {
  codeBanque?: string;
  numeroCompte?: string;
  codeGuichet?: string;
  cleRib?: string;
  iban1?: string;
  iban2?: string;
  iban3?: string;
  iban4?: string;
  iban5?: string;
  iban6?: string;
  iban7?: string;
  iban8?: string;
  iban9?: string;
  bic?: string;
  typeRIB?: string;
  iban?: string;
}
export interface Siren {
  numeroSiren?: string;
}

export interface Entreprise {
  oid?: number;
  oidGestion?: string;
  typePersonne?: string;
  domiciliation?: Domiciliation;
  facturation?: Coordonnees;
  livraison?: Livraison;
  siren?: Siren;
  raisonSociale?: string;
  codeTiersGarant?: string;
  capital?: Montant;
  dateCreation?: string;
  categorieJuridique?: number;
  cdAgentEconomique?: string;
  codeNaf?: string;
  codeNafEligibleDomTom?: boolean;
  nombreEtablissements?: number;
  natureJuridique?: string;
  codeAPRM?: string;
  historiqueClientFF?: HistoriqueClientFF;
  bilan?: Bilan;
  bilanNMoins1?: Bilan;
  capitauxPropres?: Montant;
  chefEntreprise?: ChefEntreprise;
  etatFinancier?: EtatFinancierEntreprise;
  dateModificationCapital?: string;
  actionnaire?: any;
  entIndividuel?: boolean;
  adresseLivraison?: Coordonnees;
  qualificationRisque?: QualificationRisque;
  autreIntervenantPP?: ChefEntreprise;
  ratiosFinanciers?: string[];
  associes?: string[];
  historiqueSG?: HistoriqueClientSG;
  fondDeCommerce?: FondDeCommerce;
  loyer?: Montant;
  representant?: Representant;
  exploitantProduction?: string;
}
export interface HistoriqueClientSG {
  oid?: number;
  refSG?: string;
  engagement?: number;
  dateValeurEngagement?: string;
  secteurSuivi?: string;
  libelleSecteurSuivi?: string;
  marquagePrevRisques?: boolean;
  datePrevRisques?: string;
  codeMarquagePrevRisques?: string;
  montantImpayes?: Montant;
  dateImpayes?: string;
  cdl?: number;
  topCdl?: boolean;
  provisionne?: boolean;
  personneIncidents?: boolean;
  noteSg?: Note;
  sirenGroupe?: string;
  categorieTiersReglementaire?: string;
  groupeLBO?: string;
  flag_prudentiel?: string;
  codeTiersReglementaire?: string;
  classeDeSuiviSigES?: string;
  codeEEP?: string;
  sigleEEP?: string;
  libelleEEP?: string;
  modeleNotation?: string;
  versionModeleNotation?: string;
  libelleLongModeleNotation?: string;
  libelleCourtModeleNotation?: string;
}
export interface HistoriqueClientFF {
  nombreContratsSains?: number;
  datePlusAncienContratSain?: string;
  nombreContratsEnRecouvrement?: number;
  datePlusAncienPassageRecouvrement?: string;
  nombreContratsEnContentieux?: number;
  datePlusRecentPassageContentieux?: string;
  nombreContratsEnDefautProvision?: number;
  datePlusRecentPassageDefautProvisions?: string;
  montantCRD?: Montant;
  montantEngagements?: Montant;
  montantEngagementsLBP?: Montant;
  montantEngagementsST?: Montant;
  derniereDecision?: string;
  motifDerniereDecision?: string;
  avisDerniereDecision?: string;
  numeroDossierDerniereDecision?: number;
  dateDerniereDecision?: string;
  montantDerniereDecision?: Montant;
  decideurDerniereDecision?: string;
  derniereDecisionHorsRefusRecents?: string;
  avisDerniereDecisionHorsRefusRecents?: string;
  motifDerniereDecisionHorsRefusRecents?: string;
  numeroDossierDerniereDecisionHorsRefusRecents?: number;
  dateDerniereDecisionHorsRefusRecents?: string;
  montantDerniereDecisionHorsRefusRecents?: Montant;
  decideurDerniereDecisionHorsRefusRecents?: string;
  montantTotal?: Montant;
  montantLoyersRetard?: Montant;
  nombreLoyersRetard?: number;
  oid?: number;
  oidListeBlancheNoire?: string;
  oidMotif?: number;
  codeMotif?: string;
  dateDebutValidite?: string;
  dateFinValidite?: string;
  montantMotif?: number;
  montantEncoursGroupe?: number;
  montantEngagementsMT?: Montant;
  codeListe?: string;
  motifExclusion?: string;
  infosTiersBaseRisque?: InfosTiersBR;
  infosTiersBaseRisqueLBP?: InfosTiersBR;
  montantExposition?: Montant;
  montantExpositionLBP?: Montant;
  soldeVivant?: Montant;
  soldeVivantLBP?: Montant;
  watchListLBP?: boolean;
  watchListLBPStr?: string;
}
export interface InfosContratsVivantsBR {
  nombreRcContratVivants?: number;
  nombreRoContratVivants?: number;
  nombreSuContratVivants?: number;
  nombreContratVivants?: number;
  nombreContratsSainsVivants?: number;
  datePremiereMelContratVivants?: string;
  nombreContratsVivantsAmiables?: number;
  nombreRcContratVivantAmiables?: number;
  nombreSuContratVivantAmiables?: number;
  nombreRoAmiables?: number;
  encoursHtAmiables?: number;
  soldeHTImpRcContratsVivantsAmiables?: number;
  nombreVivImpIncPaiement3Mois?: number;
  nombreAmiImpIncPaiement3Mois?: number;
  nombreImpIncPaiment3Et12mois?: number;
  nombreImpIncPaiementSup12Mois?: number;
  nombreImpIncPaiement36Mois?: number;
  nombreContratsContentieux?: number;
  nombreRcContratContencieux?: number;
  nombreSuContratContencieux?: number;
  nombreRoContratContencieux?: number;
  encoursHtContratContencieux?: number;
  nombreContractEchuContentieuxMoins5ans?: number;
}
export interface InfosHistoriquesBR {
  nombreContratsAmiableMoins2ans?: number;
  nombreContratsContentieuxMoins5ans?: number;
  nombreContratsPerteMoins10ans?: number;
  nombreContratsSainsFinisMoins5ans?: number;
  nombreContratsResiliesMoins5ans?: number;
  datePremiereMel?: string;
  flagPassageDefautServicing?: string;
  dateSortieDefautServicing?: string;
  flagPassageDefautComptePropre?: string;
  dateSortieDefautComptePropre?: string;
  defaut?: boolean;
}
export interface InfosTiersBR {
  infosVivants?: InfosContratsVivantsBR;
  infosHistoriques?: InfosHistoriquesBR;
  montantExpositionRisque?: number;
  montantEncoursVivant?: number;
  baseLocativeContrats?: number;
  chiffreAffaireGroupe?: number;
  dateArreteBilan?: string;
  idrctGroupe?: string;
  nomGroupe?: string;
  sirenMaisonMere?: string;
  nombreLoyerImp36Mois?: number;
  nombreLoyerImp12Mois?: number;
  nombreLoyerImp9Mois?: number;
  nombreLoyerImp6Mois?: number;
  nombreLoyerImp3Mois?: number;
  nombreFact36Mois?: number;
  datePassageDefautComptePropre?: string;
  flagPassageDefautComptePropre?: boolean;
  datePassageDefautServicing?: string;
  flagPassageDefautServicing?: boolean;
  etatTiers?: string;
  etatTiersServicing?: string;
}
export interface Bilan {
  dateBilan?: string;
  dureeExercice?: number;
  chiffreAffaire?: Montant;
  chiffreAffaireGroupe?: Montant;
  resultatNet?: Montant;
  fondsPropres?: Montant;
  typeCA?: string;
  resultatExploitation?: Montant;
  resultatCourant?: Montant;
  capaciteAutofinancement?: Montant;
  oid?: number;
  emptsDettesEtbCdt?: Montant;
  bilanPassifTotal?: Montant;
  dettesSoldesCrediteursBqCcp?: Montant;
  transfertCharges?: Montant;
  produitsAutres?: Montant;
  produitsExploitation?: Montant;
  dotAmortImmo?: Montant;
  dotProvImmo?: Montant;
  dotProvActifs?: Montant;
  dotProvRisquesCharges?: Montant;
  chargesAutres?: Montant;
  chargesFinancieres?: Montant;
  participationSalaries?: Montant;
  beneficePerte?: Montant;
  cbmAchatsChargesExternes?: Montant;
  cbiAchatsChargesExternes?: Montant;
  groupesAssociesBrut?: Montant;
  cbmEngagements?: Montant;
  cbiEngagements?: Montant;
  valMobPlmtBrut?: Montant;
  valMobPlmtNet?: Montant;
  disponibilites?: Montant;
  gpAssocActifBrut?: Montant;
  effEscNonEchus?: Montant;
  capitalSouscrit?: Montant;
  cliCmptBrut?: Montant;
  cliCmptNet?: Montant;
  autreFondsPropres?: Montant;
  provisionsReglemetes?: Montant;
  interetCharges?: Montant;
  emprDettesBrut?: Montant;
  emprDettesBrut1?: Montant;
  emprDettesBrut5?: Montant;
  achatMarchandise?: Montant;
  variationStkMarchandise?: Montant;
  achatMatierePremiere?: Montant;
  variationStkMatPrem?: Montant;
  autresAchatsExternes?: Montant;
  impotsTaxeEvts?: Montant;
  salaireTraitement?: Montant;
  chargeSociale?: Montant;
  totalRecette?: Montant;
  excedent?: Montant;
  dotationAmorissement?: Montant;
  deficitSocCivile?: Montant;
  acompteAvance?: Montant;
  dettesFourinsseur?: Montant;
  dettesFiscales?: Montant;
  dettesImmobilisation?: Montant;
  dettesAutres?: Montant;
  chargesCnstAvBrut?: Montant;
  chargesCnstAvAmortProv?: Montant;
  totActifCirculantBrut?: Montant;
  totActifCirculantAmortProv?: Montant;
  effectif?: number;
  etat?: string;
  amortissementProvision_1A?: Montant;
  fraisEtablissement_AC?: Montant;
  terrain_AN?: Montant;
  construction_AP?: Montant;
  installation_AR?: Montant;
  autresImmobilisations_AT?: Montant;
  immobilisationEnCours_AV?: Montant;
  avancesAcomptesImmobilisation_AX?: Montant;
  primeRemboursementObligation_CM?: Montant;
  creances1an_CR?: Montant;
  produitsEmissionTitres_DM?: Montant;
  avancesConditionnees_DN?: Montant;
  totalProvisions_DR?: Montant;
  empruntsObligataires_DS?: Montant;
  autresEmpruntsObligataires_DT?: Montant;
  empruntsDettesFinancieres_DV?: Montant;
  productionBiensVendue_FF?: Montant;
  productionServicesVendue_FI?: Montant;
  productionStockee_FM?: Montant;
  productionImmobilisee_FN?: Montant;
  subventionExploitation_FO?: Montant;
  benefice_GH?: Montant;
  pertes_GI?: Montant;
  repriseSurProvisions_GM?: Montant;
  totalProduitsFinanciers_GP?: Montant;
  differenceNegativeChange_GS?: Montant;
  chargesNettesValeursMobilieres_GT?: Montant;
  produitsExceptionnelsGestion_HA?: Montant;
  reprisesProvisionsTransfertCharge_HC?: Montant;
  chargesExceptionnellesGestion_HE?: Montant;
  impotsBenefices_HK?: Montant;
  augmentationImmoIncorporelles_KF?: Montant;
  augmentationImmoCorporelles_LP?: Montant;
  immobilisationCorporellesCours_MY?: Montant;
  avancesAcomptesImmo_NC?: Montant;
  dotationsExploitation_UF?: Montant;
  dotationsFinancieres_UH?: Montant;
  dotationsExceptionnelles_UK?: Montant;
  chargesPersonnelExterieur_YU?: Montant;
  montantTVA_YY?: Montant;
}
export interface EtatFinancierEntreprise {
  note?: NoteInterne;
  fichageFcc?: boolean;
  coteBdf?: any; // CoteBdfEntreprise;
  dateInterrogationBDF?: string;
  montantContestationCreance?: Montant;
  nombreContestationCreance?: number;
  incidents?: boolean;
  nombreIncidentPaiement?: number;
  montantIncidentPaiement?: Montant;
  presencePrivilege?: boolean;
  libellePrivilege?: string;
  montantPrivilege?: Montant;
  montantPrivilegeTP?: Montant;
  montantPrivilegeURSSAF?: Montant;
  datePrivilege?: string;
  datePrivilegeTP?: string;
  datePrivilegeURSSAF?: string;
  paiement?: string;
  coteExpert?: string;
  coteExpertReport?: string;
  dateCoteSDARapportExpert?: string;
  dateInterrogationCoface?: string;
  motifElliproScoreAlpha?: string;
  ratioRentabiliteEco?: string;
  oid?: number;
  planContinuation?: boolean;
  dateDebutPlanContinuation?: string;
  dateFinPlanContinuation?: string;
  liquidationJudiciaire?: boolean;
  dateLiquidationJudiciaire?: string;
  procedureSauvegarde?: boolean;
  dateProcedureSauvegarde?: string;
  cessationInsee?: boolean;
  dateCessation?: string;
  incidentPaiement?: boolean;
  listeMotifsImpayes?: string;
  montantCourtTerme?: Montant;
  dateCourtTerme?: string;
  noteExpert?: NoteExpert;
  segmentation?: Segmentation;
  montantIncapacitePaiementT1?: Montant;
  montantIncapacitePaiementT2T4?: Montant;
  montantTotalPassifEE?: number;
  dateDerniereCentralisation?: string;
  totalCourtTerme?: Montant;
  moyenEtLongTerme?: Montant;
  creditsBailsMobilliers?: Montant;
  creditsBailsImmobilliers?: Montant;
  countPrivilegeTP?: string;
  countPrivilegeURSSAF?: string;
  evtMarquantDefavorable?: boolean;
  evtMarquantRedhibitoire?: boolean;
  dateEvtMarquantDefavorable?: string;
  dateEvtMarquantRedhibitoire?: string;
  pd?: number;
}
export interface Segmentation {
  type?: string;
  origine?: string;
  evenement?: string;
  portefeuilleContrepartie?: PortefeuilleContrePartie;
  portefeuilleComptable?: PortefeuilleComptable;
  codeSecteurClient?: number;
  ctrCode?: number;
  ctrLibelle?: string;
  typeTiers?: string;
}
export interface PortefeuilleContrePartie {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  codePortefeuilleTransactionRetail?: string;
  codePortefeuilleTransactionNonRetail?: string;
  grandeClientele?: boolean;
  code?: string;
  codePortefeuilleCompta?: string;
}
export interface PortefeuilleComptable {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  codePortefeuilleCompta?: string;
}
export interface FondDeCommerce {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
}
export interface Montant {
  montant?: number;
  devise?: string;
  montantDoublePrecision?: number;
}
export interface Representant {
  oid?: number;
  oidGestion?: string;
  typePersonne?: string;
  domiciliation?: Domiciliation;
  facturation?: Coordonnees;
  livraison?: Livraison;
  departementNaissance?: string;
  villeNaissance?: string;
  dateNaissance?: string;
  nomJF?: string;
  nom?: string;
  prenom?: string;
  paysNaissance?: Pays;
  identifiantBdf?: string;
  civilite?: string;
  coordonnees?: Coordonnees;
  nationalite?: string;
  situationDeFamille?: string;
  ordonnateur?: string;
  comptable?: string;
  qualite?: string;
}
export interface Etat {
  infoMAJ?: InfoMAJ;
  statut?: Statut;
  sousStatut?: SousStatut;
}
export interface Statut {
  code?: string;
  libelle?: string;
  date?: string;
}
export interface SousStatut {
  code?: string;
  commentaire?: string;
  libelle?: string;
  date?: string;
}
export interface Projet {
  numProjet?: string;
  numAcquis?: string;
  dateReception?: string;
  affaires?: string[];
  vendeur?: Vendeur;
  oid?: number;
  qualification?: QualificationProjet;
  emetteur?: string;
  partenaire?: Partenaire;
  canal?: Canal;
  media?: Media;
  service?: Service;
  userCreateur?: User;
}
export interface QualificationProjet {
  note?: NoteInterne;
  noteApporteur?: string;
}
export interface NoteInterne {
  valeur?: string;
  pourcentage?: number;
  dateNotation?: string;
  dateValidite?: string;
  methode?: string;
  versionMoteur?: string;
  nomModele?: string;
  versionModele?: string;
  prioriteModele?: number;
  equivalentSG?: string;
  noteScore?: number;
}
export interface Partenaire {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
}
export interface Canal {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
  affichage?: boolean;
}
export interface Media {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
  canal?: Canal;
  partenaire?: Partenaire;
}
export interface Service {
  oid?: number;
  libelle?: string;
  nbTentatives?: number;
  scoreSeuil?: number;
  sigle?: string;
  numeroAboutement?: string;
  actif?: boolean;
}
export interface Vendeur {
  agence?: Agence;
  dateEntreeAgence?: string;
  dateSortieAgence?: string;
  nom?: string;
  prenom?: string;
  telephone?: string;
  mobile?: string;
  fax?: string;
  mail?: string;
  oid?: number;
  fixe2?: string;
  actif?: boolean;
  codeAcces?: string;
  identifiant?: string;
  commercial?: IngenieurCommercial;
  suspendu?: boolean;
  nbEchecs?: number;
  profil?: number;
}
export interface IngenieurCommercial {
  agence?: Agence;
  dateEntreeAgence?: string;
  dateSortieAgence?: string;
  nom?: string;
  prenom?: string;
  telephone?: string;
  mobile?: string;
  fax?: string;
  mail?: string;
  oid?: number;
  fixe2?: string;
  actif?: boolean;
  codeAcces?: string;
  identifiant?: string;
  commercial?: any;
  suspendu?: boolean;
  nbEchecs?: number;
  profil?: number;
  version?: number;
}
export interface Agence {
  apporteur?: Apporteur;
  libelle?: string;
  oid?: number;
  actif?: boolean;
  identifiantEKIP?: string;
  identifiantSDMI?: string;
  canauxAutorises?: DispositionAgenceCanalAutorise[];
  marchesAutorises?: DispositionAgenceMarcheAutorise[];
}
export interface Apporteur {
  codeEkip?: string;
  qualification?: QualificationApporteur;
  oid?: number;
  code?: string;
  libelle?: string;
  marche?: any; // Marche;
  fixeBOC?: string;
  faxBOC?: string;
  actif?: boolean;
  mailBOC?: string;
  canalApporteur?: CanalAcquisitionApporteur;
  prgVente?: ProgrammeVente;
  infosVendor?: ApporteurVdr;
  codeApporteurExt?: string;
  segmentation?: string;
  reetude?: boolean;
  flagPartageRisque?: boolean;
  societeGestion?: string;
  societeGestionCreditBail?: string;
}
export interface QualificationApporteur {
  note?: NoteInterne;
  numeroSiren?: string;
  codeMateriel?: string;
  eligibiliteCOSME?: boolean;
  eligibiliteCOSMEPlus?: boolean;
  eligibiliteDomTom?: boolean;
  segmentation?: string;
  reetude?: boolean;
  flagPartageRisque?: boolean;
  vendor?: boolean;
  codeTiersGarant?: string;
}
export interface CanalAcquisitionApporteur {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
}
export interface ProgrammeVente {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
}
export interface ApporteurVdr {
  oid?: number;
  ccbm?: any;
  ccbmBackup?: any;
  adresseCompl?: string;
  adresse?: string;
  codePostal?: string;
  ville?: string;
  datePrevLivraison?: boolean;
  leaser?: boolean;
  fraisDeMaintenance?: boolean;
  modifiable?: boolean;
  commissionApport?: number;
  canalVendor?: CanalAcquisitionLBP;
}
export interface CanalAcquisitionLBP {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
}
export interface DispositionAgenceCanalAutorise {
  agenceOid?: number;
  canal?: CanalAcquisitionLBP;
  actif?: boolean;
  oid?: number;
}
export interface DispositionAgenceMarcheAutorise {
  agenceOid?: number;
  marche?: MarcheAcquisitionLBP;
  actif?: boolean;
  oid?: number;
}
export interface MarcheAcquisitionLBP {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
  actif?: boolean;
}
export interface QualificationAffaire {
  note?: NoteInterne;
  portefeuille?: PortefeuilleTransaction;
  segment?: string;
}
export interface NoteInterne {
  valeur?: string;
  pourcentage?: number;
  dateNotation?: string;
  dateValidite?: string;
  methode?: string;
  versionMoteur?: string;
  nomModele?: string;
  versionModele?: string;
  prioriteModele?: number;
  equivalentSG?: string;
  noteScore?: number;
}
export interface PortefeuilleTransaction {
  oid?: number;
  sigle?: string;
  codeClass?: string;
  libelle?: string;
  ordre?: number;
  defaut?: boolean;
}
export interface QualificationDossier {
  note?: NoteInterne;
  oid?: number;
  noteExpert?: NoteExpert;
  eligibiliteCOSMEAutomate?: boolean;
  noteCOSMEAutomate?: NoteCosme;
  noteLBP?: Note;
  noteMaaf?: Note;
  lgd?: number;
}
export interface NoteExpert {
  valeur?: string;
  pourcentage?: number;
  dateNotation?: string;
  dateValidite?: string;
  methode?: string;
  user?: User;
}
export interface NoteCosme {
  valeur?: string;
  pourcentage?: number;
  dateNotation?: string;
  dateValidite?: string;
  methode?: string;
  origine?: string;
}
export interface Note {
  valeur?: string;
  pourcentage?: number;
  dateNotation?: string;
  dateValidite?: string;
  methode?: string;
}
export interface QualificationRisque {
  note?: NoteInterne;
  oid?: number;
  qualification?: string;
  dateQualification?: string;
  codedecisionnaire?: string;
  motif?: string;
  infoMaj?: InfoMAJ;
}
export interface InfoMAJ {
  date?: string;
  commentaire?: string;
  user?: User;
  motif?: string;
}
export interface DecisionOAPR {
  scoreOctroi?: number;
  scoreOctroiClasse?: number;
  ctSurCA?: number;
  mltCbmCbiSurSnc?: number;
  mltCbmCbiSurMba?: number;
  vrEspereeMateriel?: number;
  avisOAPR?: string;
  avisScore?: string;
  statutFinal?: string;
  messagesInternes?: string;
  noteMateriel?: string;
  tiersGarantEnv?: string;
  idTiersGarantEnv?: string;
  typeGarantieEnv?: string;
  interrogationEnvGrace?: boolean;
  decisionSipasEnvGrace?: string;
  messageSipasEnvGrace?: string;
}
export interface InfosComplementaire {
  dirigeant?: ChefEntreprise;
  referenceExterne?: string;
}
export interface ChefEntreprise {
  oid?: number;
  oidGestion?: string;
  typePersonne?: string;
  domiciliation?: Domiciliation;
  facturation?: Coordonnees;
  livraison?: Livraison;
  departementNaissance?: string;
  villeNaissance?: string;
  dateNaissance?: string;
  nomJF?: string;
  nom?: string;
  prenom?: string;
  paysNaissance?: Pays;
  identifiantBdf?: string;
  civilite?: string;
  coordonnees?: Coordonnees;
  nationalite?: string;
  situationDeFamille?: string;
  fonction?: string;
  dateFonction?: string;
  etatFinancier?: EtatFinancierPhysique;
  origineChefEntreprise?: InfoMAJ;
}
export interface EtatFinancierPhysique {
  fichageFicp?: boolean;
  coteBdf?: CoteBdfDirigeant;
  fichageFcc?: boolean;
  niveauFichageFicp?: string;
  oid?: number;
  fichageFiben56?: boolean;
  homonymieDirigeant?: boolean;
}
export interface CoteBdfDirigeant {
  dateCotation?: string;
  dateRevision?: string;
  cote?: string;
}
