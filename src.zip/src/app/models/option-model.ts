export  class ModelOption {
  libelle: string;
  value: string;
  data: any;
  constructor(lib, val, dat? ) {
    this.libelle = lib;
    this.value = val;
    this.data = dat;
  }

  static setUniqueValue(lib) {
    return new ModelOption(lib, lib, null);
  }
}
