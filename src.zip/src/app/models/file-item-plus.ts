import { FileItem } from 'ng2-file-upload';

export class FileItemPlus extends FileItem {
  documentType?: string;
}
