import * as globalFunc from '../models/global-functions';

export class SuiviParcInfo {
  id: number;
  client: Map<string, any>;
  statut: Map<string, any>;
  montant: any;
  dateStatut: number;
  dateExpire: number;
  statutCommercial: string;

  constructor(response: any) {
    this.id = response.referenceInterne; // Num affaire => referenceInterne
    this.client = globalFunc.convertToMap(response.client);
    this.statut = globalFunc.convertToMap(response.statut);
    this.montant = response.montantRachat;
    this.statutCommercial = response.statutCommercial;
    this.dateStatut = globalFunc.convertToMap(response.firstElement).get('dateDebutLocation');
    this.dateExpire = globalFunc.convertToMap(response.firstElement).get('dateFinLocation');
  }
}
