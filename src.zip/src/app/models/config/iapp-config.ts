export interface IAppConfig {
    env: string;
    production: boolean;
    urlBackend: string;
    enableProxy: boolean;
    contextBackend: string;
    domain: string;
}
export interface EnvIAppConfig {
  dev?: IAppConfig;
  int?: IAppConfig;
  production?: IAppConfig;
  common?: any;
}
