import { ModelOption } from './option-model';

export class DdfValidation {

    private  numeroSiren?: string;
    private  codeProduitFinancier?: string;
    private  duree: number;
    private  montant: number;
    private  codeMateriel?: string;
    private  neuf = false;
    private  anneeMiseEnService: number;
    private  nombreMateriel: number;
    private  premierLoyer: number;
    private  valeurResiduelle: number;
    private  montantVR: number;
    private  libelleMateriel?: string;


    constructor(input: DdfModel) {
      if (input.siren) {
        this.numeroSiren = input.siren ;
      }
      if (input.duree) {
        this.duree =  Number(input.duree); // Number(input.duree.value);
      }
      if (input.montant) {
        this.montant = Number(input.montant);
      }
      this.neuf = !(input.etat_mat === '0');
      if (input.anneeMiseEnService) {
        this.anneeMiseEnService = Number(input.anneeMiseEnService);
      }
      if (input.produit) {
        this.codeProduitFinancier =  input.produit.value;
      }
      if (input.valeurResiduelle && this.codeProduitFinancier === 'CB' ) {
        this.valeurResiduelle =  Number(input.valeurResiduelle);
      }
      if (input.premierLoyer  && this.codeProduitFinancier === 'CB') {
        this.premierLoyer =  Number(input.premierLoyer);
      }
      if (input.code_mat) {
        this.codeMateriel = input.code_mat.value;
      }
    }
}

export class DdfModel {
  public vendeur ?: string;
  public agence ?: string;
  public apporteur ?: string;
  public marché ?: string;
  public siren ?= '';
  public sirenError ?= false;
  public raison?: string;
  public nomdir?: string;
  public nom_naiss_diff?: string;
  public choixNom_naiss_diff?: string;
  public anneeNaissance?: string;
  public montant?: number;
  public valeurResiduelle?: number;
  public premierLoyer?: number;
  public valeurResiduelleMontant?: number;
  public premierLoyerMontant?: number;
  public duree?: string; // ModelOption; // FIXME: change type duree to string, when list duree is static
  public code_cat?: ModelOption;
  public code_mat?: ModelOption;
  public etat_mat ?= '1';
  public anneeMiseEnService?: number;
  public commentMateriel?: string;
  public produit?: ModelOption;
  public montantRachat?: string;
  public dateNaissance?: number;
  public files?: any;
}
