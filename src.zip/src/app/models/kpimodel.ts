export class KpiModel {
  public libelle: string;
  public quantite: number;
  public data?: any;
  constructor(lib?, quant?) {
    this.libelle = lib ? lib : '';
    this.quantite = quant ? quant : 0;
  }

  static new(lib: string) {
    return new KpiModel(lib);
  }
  static addOne(obj: KpiModel, lib?: string) {
    if (!obj && (lib !== null || lib !== '')) {
      obj = new KpiModel(lib);
    }
    obj.quantite++;
    return obj;
  }
}
