import * as globalFunc from '../models/global-functions';

export class DossierMontageInfo {
  id: number;
  statut: Map<string, any>;
  numSiren: string;
  raisonSocial: string;
  montant: any;
  dateReception: number;

  constructor(response: any) {
    this.id = response.idDossier;
    this.statut = globalFunc.convertToMap(response.statut);
    this.numSiren = response.siren;
    this.raisonSocial = response.raisonSocialClient;
    this.montant = response.montantHT;
    this.dateReception = response.dateReceptionDocumentNonTraite;
  }
}
