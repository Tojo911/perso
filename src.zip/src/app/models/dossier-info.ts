import { ModelOption } from '../models/option-model';
import * as globalFunc from '../models/global-functions';
export class DossierInfo {
  /* TODO: @anas: we need to rediscuss this and check info with backend data */
  id: number;
  numSiren: number;
  montant: any;
  duree: ModelOption;
  produitFinancier: Map<string, any>;
  dateSaisie: number;
  dateCreation?: number;
  raisonSociale: string;
  statut: Map<string, any>;
  materiel: Map<string, any>;
  blocMateriel: Map<string, any>;
  blocPlanFinancement: Map<string, any>;
  vendeur: Map<string, any>;
  // To be changed with correct attribute
  loyerFinancier: any;
  periodicite: any;
  loyerTotal: any;
  assurance: any;
  calage: any;
  nbJoursCalage: any;
  assurance_personne: any;
  assurance_materiel: any;
  bareme: any;
  fournisseur: any;
  maintenance: any;
  serie: any;
  designation: any;
  statutCommercial: string;
  montantRachat;
  dateStatut: number;
  dateExpire: number;
  constructor(response: any) {
    this.montantRachat = response.montantRachat;
    if (response.firstElement) {
      this.dateStatut = response.firstElement.dateDebutLocation;
      this.dateExpire = response.firstElement.dateFinLocation;
    }
    this.id = response.referenceInterne
      ? response.referenceInterne
      : response.numeroFL;
    this.numSiren = !response.client
      ? response.numeroSIREN
      : response.client.siren;
    this.montant = response.montant;
    if (response.duree) {
      this.duree = response.duree.toString();
    }
    this.produitFinancier = globalFunc.convertToMap(response.produitFinancier);
    this.dateSaisie = response.dateCreation
      ? response.dateCreation
      : response.dateSaisie;
    this.raisonSociale = response.client
      ? response.client.raisonSociale
      : response.raisonSociale;
    this.statut = globalFunc.convertToMap(response.statut);
    this.materiel = globalFunc.convertToMap(response.materiel);
    this.blocMateriel = globalFunc.convertToMap(response.blocMateriel);
    this.blocPlanFinancement = globalFunc.convertToMap(
      response.blocPlanFinancement
    );
    this.vendeur = globalFunc.convertToMap(response.vendeur);
    // To be changed with correct attribute
    this.loyerFinancier = '256';
    this.periodicite = 'Semestrielle';
    this.loyerFinancier = '3256';
    this.assurance = '145';
    this.calage = '';
    this.nbJoursCalage = '';
    this.assurance_personne = '';
    this.assurance_materiel = '';
    this.bareme = '';
    this.fournisseur = 167;
    this.maintenance = '';
    this.serie = '56897425';
    this.designation = 'Designation';
    this.statutCommercial = response.statutCommercial;
  }

  public updateMateriel(obj: any) {
    this.materiel = globalFunc.convertToMap(obj);
  }
}
