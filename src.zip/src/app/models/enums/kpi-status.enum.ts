import { TranslateService } from '@ngx-translate/core';
let b: TranslateService;

export enum kpiStatusEnum {
  accords = 'Accordés',
  refus = 'Refus',
  etudes = 'A l\'etude',
  expires = 'Expirent',
  ETU = 'A l\'etude',
  ANN = 'Refus',
  SSU = 'Expirent',
  RISK_DI = 'A l\'etude',
  GEST_GE = 'Accordés',
  ANO = 'Refus',
  recu = 'Reçu',
  enTraitement = 'En traitement',
  enAnomalie = 'Anomalie(s)',
  paye = 'Payé(s)',
  saines = 'Sains',
  amiables = 'Amiables',
  contentieuses = 'Contentieux',
  expirentMoins6Mois = 'Expirent'
}
