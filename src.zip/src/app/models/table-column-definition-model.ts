
export interface TableColumnDefinitionModel {
  columnDef?: string;
  forbiddenScreens?: any;
  header?: string;
  sort?: boolean;
  date?: boolean;
  tooltip?: string;
  cell?: (row: any) => any;
  type?: string;
}
