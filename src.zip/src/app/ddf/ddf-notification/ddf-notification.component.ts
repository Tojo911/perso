import { Component, OnInit, Inject } from '@angular/core';
import { FormControl } from '@angular/forms';

import { EntrepriseService } from '../../services/entreprise/entreprise.service' ;
import { DdfService } from '../../services/ddf/ddf.service';


import { Router } from '@angular/router';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { WaitdialogComponent } from '../waitdialog/waitdialog.component';
import { observable } from 'rxjs';
import { DossierInfo } from '../../models/dossier-info';


@Component({
  selector: 'app-ddf-notification',
  templateUrl: './ddf-notification.component.html',
  styleUrls: ['./ddf-notification.component.scss']
})
export class DdfNotificationComponent implements OnInit {

 private ddfData: DossierInfo;

model = {
  siren: '',
  sirenError: false,
  raison: '',
  Nomdir: '',
  choixNom_naiss_diff: '',
  anneeNaissance: '',
  montant: '',
  ValeurResiduelle: '',
  PremierLoyer: '',
  duree: '',
  code_mat: '',
  etat_mat: '1',
  annee_mat: '',
  CommentMateriel: '',
  produit: '',
  montantRachat: '',
  NumDoss: '',
  DateNaissance: '',
};

numerofl = '00000';
ddfNotified = false;

  constructor(
    private entrepriseService: EntrepriseService,
    private ddfService: DdfService,
    private router: Router,
    public dialogRef: MatDialogRef<WaitdialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogdata: any
  ) {}

  ngOnInit() {

  this.ddfService.getDdf(this.ddfData)
  .subscribe(
    (res) => {

  });
}



  ddfNotif() {
    const data = {
      codeProduitFinancier: 'LF',
      numeroSiren: this.model.siren,
      raison: this.model.raison,

    };
    this.ddfNotified = true;
    }

CreateDocddf() {
  console.log('');

}
submitEtudeDdf() {
  console.log ('');
}
closeDialog () {
  this.dialogRef.close();
}

}
