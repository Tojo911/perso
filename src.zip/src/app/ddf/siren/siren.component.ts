import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

import { Observable, Subject } from 'rxjs';

import {
  filter,
  debounceTime,
  distinctUntilChanged,
  switchMap
} from 'rxjs/operators';

import { EntrepriseService } from '../../services/entreprise/entreprise.service';

@Component({
  selector: 'app-siren',
  templateUrl: './siren.component.html',
  styleUrls: ['./siren.component.scss']
})
export class SirenComponent implements OnInit {
  siren = '';
  isLoading = false;
  term$ = new Subject<string>();

  constructor(private entrepriseService: EntrepriseService) {}

  ngOnInit() {
    const subscribe = this.term$
      .pipe(debounceTime(500))
      .pipe(filter(val => val !== ''))
      .pipe(distinctUntilChanged())
      .subscribe(val => {
        this.entrepriseService.getEntreprise(val).subscribe(res => {
          console.log(res);
        });
      });
  }
}
