import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DdfService } from '../../services/ddf/ddf.service';
import { DdfDataSourceService } from '../../services/ddf/ddf-data-source.service';
import { retryWhen } from 'rxjs/internal/operators/retryWhen';
import { interval } from 'rxjs';
import { tap } from 'rxjs/internal/operators/tap';
import { Router } from '@angular/router';
import { DossierInfo } from '../../models/dossier-info';
import { map } from 'rxjs/operators';
import { DossierInfo2 } from '../../models/ddf';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-waitdialog',
  templateUrl: './waitdialog.component.html',
  styleUrls: ['./waitdialog.component.scss']
})
export class WaitdialogComponent implements OnInit {
  numDoss = undefined;
  ddfSubmitted = false;
  ddfData = undefined;
  showDdfStatus = false;
  infos: any;

  constructor(
    private ddfService: DdfService,
    private ddfDatasoucre: DdfDataSourceService,
    public dialogRef: MatDialogRef<WaitdialogComponent>,
    private router: Router,
    public translate: TranslateService
  ) {}
  ngOnInit() {
    this.ddfDatasoucre.numfl.subscribe(message => this.setValue(message));
    this.ddfSubmitted = false;
  }

  closeDialog() {
    this.dialogRef.close();
    this.router.navigate(['dossier/ddf_' + this.numDoss + '/suivi/']);
  }

  getDfdData(id: any) {
    this.ddfService
      .getDdf(id)
      .pipe(
        map(res => {
          const content = res.content as DossierInfo2;
          if (content.statut.code === 'ETU') {
            this.ddfData = new DossierInfo(res.content);
            this.showDdfStatus = true;
            throw res;
          }
          return res;
        }),
        retryWhen(_ => interval(5000)),
        tap(p => console.log('tap....', p))
      )
      .subscribe(
        res => {
          this.ddfData = new DossierInfo(res.content);
          console.log(`statut: ` + this.ddfData.statut.code);
          this.showDdfStatus = true;
        },
        err => {
          console.log('error...', err);
        }
      );
  }
  setValue(message) {
    this.ddfSubmitted = true;
    this.numDoss = message;
    if (this.numDoss) {
      this.getDfdData(this.numDoss);
    }
  }
}
