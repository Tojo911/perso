import {
  Component,
  ViewChild,
  AfterViewInit,
  OnDestroy,
  EventEmitter
} from '@angular/core';
import { DdfService } from '../services/ddf/ddf.service';
import { Observable, Subscription, combineLatest } from 'rxjs';
import * as _ from 'lodash';
import * as moment from 'moment';
import { AuthService } from '../services/auth/auth.service';
import { ProduitService } from '../services/produit/produit.service';
import {
  MatTableDataSource,
  MatPaginator,
  PageEvent,
  MatSort,
  Sort,
  MatTabChangeEvent,
  MatTab
} from '@angular/material';
import { KpiModel } from '../models/kpimodel';
import * as globalFunc from '../models/global-functions';
import { DossierInfo } from '../models/dossier-info';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { SuiviParcInfo } from '../models/suivi-parc-info';
import { DossierMontageInfo } from '../models/dossier-montage';
import { Perimetre } from '../models/perimetre';
import { ModelOption } from '../models/option-model';
import { ItemTableInfo } from '../models/item-table-info';
import { HomeTabEnum } from '../models/enums/home-tab.enum';
import { map } from 'rxjs/operators';
import { Dossier } from '../dossier/dossier-bloc/dossier-bloc.component';
import { Phase } from '../dossier/suivi-dossier/suivi-dossier.component';
import { SirenFormatter } from '../classes/inputFormatter/sirenFormatter';
import { AmountFormatter } from '../classes/inputFormatter/amountFormatter';
import { OnInit } from '@angular/core';

// TODO: Export kpiStatusEnum
export enum kpiStatusEnum {
  accords = 'Accordé',
  refus = 'Refusé',
  etudes = "A l'étude",
  expires = 'Expirent',
  ETU = "A l'étude",
  ANN = 'Refusé',
  SSU = 'Expirent',
  RISK_DI = "A l'étude",
  GEST_GE = 'Accordé',
  ANO = 'Refus',
  recu = 'Reçu',
  enTraitement = 'En traitement',
  enAnomalie = 'Anomalie(s)',
  paye = 'Payé(s)',
  saines = 'En loyer saine',
  amiables = 'Amiables',
  contentieuses = 'En loyer contentieuse',
  expirentMoins6Mois = 'Expirent'
}
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements AfterViewInit, OnDestroy, OnInit {
  public filter_ddf_status = [];
  public filter_ddf_status_com = [];
  public ddfKpiSubscription: Subscription;
  public value = '';
  public ddfListSubscription: Subscription;
  public ddfStatutSubscription: Subscription;
  private tabSubscription: Subscription;
  public critere: any = {};
  public aux: any;
  public ddfDatasource: any[];
  public userFirstname: string;
  public documentReady = false;
  public ddfTableColumns = [];
  public suiviParcTableColumns = [];
  public filterValue: string;
  public kpisDfsList: KpiModel[];
  public kpisMontageList: KpiModel[];
  public kpisSuiviParcList: KpiModel[];
  public parcDatasource: any[];
  public filter_parc_status = [];
  public filter_montage_status = [];
  public currentState: KpiModel;
  public kpiStatutSelected: ModelOption;
  private dataAux: any[] = undefined;
  private filterStatutParam: any;
  private filterMontantParam: any;
  public perimetre: Perimetre;
  public perimetres: Perimetre[];
  public loadingData = false;
  public loadingKpi = false;
  private statusDdf: any;
  private statusComDdf: any;
  private statusParc: any;
  private statusMontage: any;
  public appVersion = environment.version;
  private dossier: DossierInfo;
  private auxParcList: SuiviParcInfo[];
  private parcDataAux: any[] = undefined;
  private kpiStatusEnum = kpiStatusEnum;
  @ViewChild('tabulation')
  public tabulation;
  public montageDatasource;
  public isInterne: boolean;
  private auxDossierMontageList;
  private montageDataAux: any[] = undefined;
  public kpiSelectedEvent: EventEmitter<ModelOption> = new EventEmitter<
    ModelOption
  >();
  public isDashMontage: boolean;
  public isDashParc: boolean;
  public tabultationIndex: number;
  public isDashMontageExcel: boolean;

  public storage = {
    ddfData: 'ddfData',
    ddfStatut: 'ddfStatut',
    ddfStatutCom: 'ddfStatutCom',
    montageData: 'montageData',
    montageStatut: 'montageStatut',
    montageStatutCom: 'montageStatutCom',
    suiviParcData: 'suiviParcData',
    suiviParcStatut: 'suiviParcStatut',
    suiviParcStatutCom: 'suiviParcStatutCom',
    ddfUrl: 'ddf',
    montageUrl: 'montage',
    suiviParcUrl: 'affaires'
  };

  public HomeTabenum = HomeTabEnum;
  private sirenFormatter = new SirenFormatter();
  private amountFormatter = new AmountFormatter();
  constructor(
    private ddfService: DdfService,
    private authService: AuthService,
    private translateService: TranslateService,
    private router: Router
  ) {
    this.userFirstname = this.authService.getUserDataByKeyFromJWTPayload(
      'firstname'
    );
    this.perimetre = this.authService.getPerimetreFromToken();
    this.isInterne = this.authService.isInterne();
    this.isDashMontage = this.isAuthMontage();
    this.isDashMontageExcel = this.isAuthMontageExcel();
    this.isDashParc = this.isAuthSuivi();
  }

  ngOnInit() {}

  ngOnDestroy() {
    if (this.ddfListSubscription) {
      this.ddfListSubscription.unsubscribe();
    }
    if (this.ddfKpiSubscription) {
      this.ddfKpiSubscription.unsubscribe();
    }
    if (this.ddfStatutSubscription) {
      this.ddfStatutSubscription.unsubscribe();
    }
    if (this.tabSubscription) {
      this.tabSubscription.unsubscribe();
    }
  }
  isProd() {
    return environment.env === 'prod';
  }
  isAuthMontage() {
    return this.authService.isDashMontage();
  }
  isAuthMontageExcel() {
    return this.authService.isDashExportExcel();
  }
  isAuthSuivi() {
    return this.authService.isDashParc();
  }
  isAuthDdf() {
    return this.authService.isAuthDdf();
  }
  linkToDossier(e) {
    this.router.navigate(['dossier/' + e.numeroFL + '/suivi/']);
  }

  resetTable() {
    // get DDFs datasource
    this.dataAux = JSON.parse(
      localStorage.getItem(this.storage.ddfData + this.perimetre.vendeur)
    );
    if (this.dataAux) {
      this.ddfDatasource = this.dataAux;
    }

    // get DDFs STATUS
    this.statusDdf = JSON.parse(localStorage.getItem(this.storage.ddfStatut));
    if (this.statusDdf) {
      this.filter_ddf_status = this.statusDdf;
    }
    this.statusComDdf = JSON.parse(
      localStorage.getItem(this.storage.ddfStatutCom + this.perimetre.vendeur)
    );
    if (this.statusComDdf) {
      this.filter_ddf_status_com = this.statusComDdf;
    }

    // get DOSSIERS MONTAGE datasource
    this.montageDataAux = JSON.parse(
      localStorage.getItem(this.storage.montageData + this.perimetre.vendeur)
    );
    if (this.montageDataAux) {
      this.montageDatasource = this.montageDataAux;
    }

    // get DOSSIERS MONTAGE STATUS
    this.statusMontage = JSON.parse(
      localStorage.getItem(this.storage.montageStatut)
    );
    if (this.statusMontage) {
      this.filter_montage_status = this.statusMontage;
    }

    // get SUIVI PARC datasource
    this.parcDataAux = JSON.parse(
      localStorage.getItem(this.storage.suiviParcData + this.perimetre.vendeur)
    );
    if (this.parcDataAux) {
      this.parcDatasource = this.parcDataAux;
    }
    // get SUIVI PARC STATUS
    this.statusParc = JSON.parse(
      localStorage.getItem(this.storage.suiviParcStatut)
    );
    if (this.statusParc) {
      this.filter_parc_status = this.statusParc;
    }
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.tabSubscription = this.ddfService.currentDashboardTab.subscribe(
        event => {
          if (event !== undefined) {
            this.tabulation.selectedIndex = event;
          }
          this.updatePerimetre(this.tabulation.selectedIndex);
        }
      );
      // get TABLEs definitions
      this.translateService.get('TABLE').subscribe(t => {
        this.ddfTableColumns = this.getDdfsColumnsDef();
        this.suiviParcTableColumns = this.getSuiviParcColumnsDef();
      });
      this.resetTable();
      this.documentReady = true;
    }, 300);
  }

  getDdfsColumnsDef() {
    return [
      {
        columnDef: 'numFranfinance',
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.NUM_FLASHLEASE'
        ),
        sort: true,
        cell: (row: ItemTableInfo) => row.numeroFL
      },
      {
        columnDef: 'numSiren',
        forbiddenScreens: ['xs', 'sm', 'md'],
        sort: true,
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_SIREN'),
        cell: (row: ItemTableInfo) =>
          this.sirenFormatter.transform(row.numeroSIREN)
      },
      {
        columnDef: 'raisonSocial',
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.RAISON_SOCIAL'
        ),
        tooltip: true,
        sort: true,
        cell: (row: ItemTableInfo) => row.raisonSociale
      },
      {
        columnDef: 'montant',
        header: this.translateService.instant('HOME.TABLE.COLUMNS.MONTANT'),
        sort: true,
        cell: (row: ItemTableInfo) =>
          this.amountFormatter.transform(row.montant)
      },
      {
        columnDef: 'dateCreation',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.DATE_CREATION'
        ),
        sort: true,
        date: true,
        cell: (row: ItemTableInfo) => row.dateSaisie
      },
      {
        columnDef: 'vendeur',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.VENDEUR'),
        sort: true,
        cell: (row: ItemTableInfo) => row.vendeur
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.STATUS'),
        sort: true,
        cell: (row: ItemTableInfo) => row.statut
      },
      {
        columnDef: 'statusCo',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.STATUS_COMMERCIAL'
        ),
        sort: true,
        cell: (row: ItemTableInfo) => row.statutCommercial
      }
    ];
  }

  getSuiviParcColumnsDef() {
    return [
      {
        columnDef: 'numEkip',
        sort: true,
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_EKIP'),
        cell: (row: ItemTableInfo) => row.numeroFL
      },
      {
        columnDef: 'numSiren',
        sort: true,
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.NUM_SIREN'),
        cell: (row: ItemTableInfo) => row.numeroSIREN
      },
      {
        columnDef: 'raisonSocial',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.RAISON_SOCIAL'
        ),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: ItemTableInfo) => row.raisonSociale
      },
      {
        columnDef: 'agence',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.AGENCE'),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: ItemTableInfo) => '?'
      },
      {
        columnDef: 'apporteur',
        forbiddenScreens: ['xs', 'sm', 'md'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.APPORTEUR'),
        tooltip: 'hasTooltip',
        sort: true,
        cell: (row: ItemTableInfo) => '?'
      },
      {
        columnDef: 'montant',
        header: this.translateService.instant(
          'HOME.TABLE.COLUMNS.MONTANT_PARC'
        ),
        sort: true,
        cell: (row: ItemTableInfo) => row.montant
      },
      {
        columnDef: 'expirele',
        header: this.translateService.instant('HOME.TABLE.COLUMNS.EXPIRE_LE'),
        sort: true,
        date: true,
        cell: (row: ItemTableInfo) => row.dateExpire
      },
      {
        columnDef: 'status',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.STATUS'),
        sort: true,
        cell: (row: ItemTableInfo) => row.statut
      },
      {
        columnDef: 'loyer',
        forbiddenScreens: ['xs', 'sm'],
        header: this.translateService.instant('HOME.TABLE.COLUMNS.LOYER'),
        sort: true,
        cell: (row: ItemTableInfo) => '?' // row.loyer
      }
    ];
  }

  closeSlider($e, any) {
    console.log(any);
  }

  itemBeenRead(item) {
    item.new = false;
  }

  getDdfList(idVendeur, dataK, statutK, tabIndex) {
    const accord = this.ddfService
      .getDDFAccordList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const etude = this.ddfService
      .getDDFEtudeList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const refus = this.ddfService
      .getDDFRefusList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const expire = this.ddfService
      .getDDFExpireList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));
    this.ddfListSubscription = combineLatest(accord, etude, refus, expire)
      .pipe(
        map(([r1, r2, r3, r4]) =>
          [...r1, ...r2, ...r3, ...r4].map(item => new DossierInfo(item))
        )
      )
      .subscribe((res: DossierInfo[]) => {
        this.populateDatatable(
          _.orderBy(res, ['dateSaisie'], ['asc']),
          idVendeur,
          dataK,
          statutK,
          tabIndex
        );
        this.loadingData = false;
      });
  }

  getMontageList(idVendeur, dataK, statutK, tabIndex) {
    const payes = this.ddfService
      .getMontagePayesList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const enTraitement = this.ddfService
      .getMontageEntraitementList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const recus = this.ddfService
      .getMontageRecusList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const enAnomalie = this.ddfService
      .getMontageEnAnomalieList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    this.ddfListSubscription = combineLatest(
      payes,
      enTraitement,
      recus,
      enAnomalie
    )
      .pipe(
        map(([r1, r2, r3, r4]) =>
          [...r1, ...r2, ...r3, ...r4].map(item => new DossierInfo(item))
        )
      )
      .subscribe((res: DossierInfo[]) => {
        this.populateDatatable(
          _.orderBy(res, ['dateSaisie'], ['asc']),
          idVendeur,
          dataK,
          statutK,
          tabIndex
        );
        this.loadingData = false;
      });
  }

  getParcList(idVendeur, dataK, statutK, tabIndex) {
    const saines = this.ddfService
      .getParcSaineList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const contentieuse = this.ddfService
      .getParcContentieuseList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const amiable = this.ddfService
      .getParcAmiableList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    const expire = this.ddfService
      .geParcExpireList(idVendeur)
      .pipe(map(res => res.content as DossierInfo[]));

    this.ddfListSubscription = combineLatest(
      saines,
      contentieuse,
      amiable,
      expire
    )
      .pipe(
        map(([r1, r2, r3, r4]) =>
          [...r1, ...r2, ...r3, ...r4].map(item => new DossierInfo(item))
        )
      )
      .subscribe((res: DossierInfo[]) => {
        this.populateDatatable(res, idVendeur, dataK, statutK, tabIndex);
        this.loadingData = false;
      });
  }

  public updatePerimetre(event?) {
    this.loadingKpi = true;
    this.loadingData = true;
    this.tabultationIndex = event ? event : this.tabulation.selectedIndex;
    let datasource, datakey, statutKey;
    if (this.tabultationIndex === HomeTabEnum.DDF) {
      datasource = this.ddfDatasource;
      datakey = this.storage.ddfData;
      statutKey = this.storage.ddfStatut;
      this.getDdfList(
        this.perimetres,
        datakey,
        statutKey,
        this.tabulation.selectedIndex
      );
    } else if (this.tabultationIndex === HomeTabEnum.MONTAGE) {
      datasource = this.montageDatasource;
      datakey = this.storage.montageData;
      statutKey = this.storage.montageStatut;

      this.getMontageList(
        this.perimetres,
        datakey,
        statutKey,
        this.tabulation.selectedIndex
      );
    } else if (this.tabultationIndex === HomeTabEnum.PARC) {
      datasource = this.parcDatasource;
      datakey = this.storage.suiviParcData;
      statutKey = this.storage.suiviParcStatut;
      this.getParcList(
        this.perimetres,
        datakey,
        statutKey,
        this.tabulation.selectedIndex
      );
    }

    this.resetTable();
    if (!this.ddfKpiSubscription) {
      this.ddfKpiSubscription = this.ddfService
        .getKpi(
          this.perimetre.vendeur,
          this.getTypeFromTab(this.tabulation.selectedIndex)
        )
        .subscribe(data => {
          this.kpisDfsList = globalFunc.mapKpiObjToList(data.content, KpiModel);
          this.loadingKpi = false;
        });
    }

    this.ddfStatutSubscription = this.ddfService
      .getAllStatus(this.getTypeFromTab(this.tabulation.selectedIndex))
      .subscribe(res => this.populateStatus(res.content, statutKey));
  }

  public updatePerimetres(event?) {
    this.loadingKpi = true;
    this.loadingData = true;
    this.tabultationIndex = event ? event : this.tabulation.selectedIndex;
    let datasource, datakey, statutKey;
    if (this.tabultationIndex === HomeTabEnum.DDF) {
      datasource = this.ddfDatasource;
      datakey = this.storage.ddfData;
      statutKey = this.storage.ddfStatut;
      this.getDdfList(
        this.perimetres,
        datakey,
        statutKey,
        this.tabulation.selectedIndex
      );
    } else if (this.tabultationIndex === HomeTabEnum.MONTAGE) {
      datasource = this.montageDatasource;
      datakey = this.storage.montageData;
      statutKey = this.storage.montageStatut;

      this.getMontageList(
        this.perimetres,
        datakey,
        statutKey,
        this.tabulation.selectedIndex
      );
    } else if (this.tabultationIndex === HomeTabEnum.PARC) {
      datasource = this.parcDatasource;
      datakey = this.storage.suiviParcData;
      statutKey = this.storage.suiviParcStatut;
      this.getParcList(
        this.perimetres,
        datakey,
        statutKey,
        this.tabulation.selectedIndex
      );
    }

    this.resetTable();
    if (!this.ddfKpiSubscription) {
      this.ddfKpiSubscription = this.ddfService
        .getKpi(
          this.perimetres,
          this.getTypeFromTab(this.tabulation.selectedIndex)
        )
        .subscribe(data => {
          this.kpisDfsList = globalFunc.mapKpiObjToList(data.content, KpiModel);
          this.loadingKpi = false;
        });
      }

    this.ddfStatutSubscription = this.ddfService
      .getAllStatus(this.getTypeFromTab(this.tabulation.selectedIndex))
      .subscribe(res => this.populateStatus(res.content, statutKey));
  }

  populateStatus(list, storageStatusPrefix) {
    const available_status = [];
    list.forEach((item: any) => {
      available_status.push(
        new ModelOption(item['libelle'], item['code'], item)
      );
    });
    localStorage.setItem(
      storageStatusPrefix,
      JSON.stringify(
        _.uniqBy(_.orderBy(available_status, ['libelle'], ['asc']), 'libelle')
      )
    );
  }

  populateDatatable(
    list: DossierInfo[],
    vendeur,
    storageDataPrefix,
    storageStatusPrefix,
    type,
    storageStatusComPrefix?
  ) {
    if (!vendeur) {
      vendeur = this.perimetre.vendeur;
    }
    const available_status_co = [];
    const items = [];

    list.forEach((item: DossierInfo) => {
      const model: ItemTableInfo = new ItemTableInfo(item);
      items.push(model);
    });

    this.aux = items;
    localStorage.setItem(storageDataPrefix + vendeur, JSON.stringify(items));
    if (vendeur === this.perimetre.vendeur) {
      const dataSrc = items.map(item => {
        if (dataSrc && dataSrc.find(it => it.id === item.id) !== undefined) {
          item.new = true;
        }
        return item;
      });
      this.setDataSource(dataSrc, type);
    }

    this.resetTable();
  }

  setDataSource(datasrc, type) {
    if (type === this.getTypeFromTab(this.tabulation.selectedIndex)) {
      if (type === this.getTypeFromTab(HomeTabEnum.DDF)) {
        this.ddfDatasource = datasrc;
      } else if (type === this.getTypeFromTab(HomeTabEnum.MONTAGE)) {
        this.montageDatasource = datasrc;
      } else if (type === this.getTypeFromTab(HomeTabEnum.PARC)) {
        this.parcDatasource = datasrc;
      }
    }
    //  }
  }

  getTypeFromTab(tab) {
    if (tab === HomeTabEnum.DDF) {
      return this.storage.ddfUrl;
    } else if (tab === HomeTabEnum.MONTAGE) {
      return this.storage.montageUrl;
    } else if (tab === HomeTabEnum.PARC) {
      return this.storage.suiviParcUrl;
    }
  }

  ddfDetail(event) {
    this.router.navigate([`dossier/${Phase.DDF}_${event.numeroFL}/suivi/`]);
  }
  montageDetail(event) {
    this.router.navigate([`dossier/${Phase.MONTAGE}_${event.numeroFL}/suivi/`]);
  }
  parcDetail(event) {
    this.router.navigate([`dossier/${Phase.PARC}_${event.numeroFL}/suivi/`]);
  }
}
