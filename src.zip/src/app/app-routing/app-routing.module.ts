import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from '../login/login.component';
import { HomeComponent } from '../home/home.component';
import { DossierComponent } from '../dossier/dossier.component';
import { SuiviDossierComponent } from '../dossier/suivi-dossier/suivi-dossier.component';
import { DdfNotificationComponent } from '../ddf/ddf-notification/ddf-notification.component';
import { DdfPageComponent } from '../ddf/ddf-page/ddf-page.component';
import { LoggedGuard } from '../services/auth/guards/logged.guard';
import { AppLayoutComponent } from '../layout/app-layout.component';
import { MonCompteComponent } from '../users/mon-compte/mon-compte.component';
import { ResultatsRechercheComponent } from '../resultats-recherche/resultats-recherche.component';
import { ModelGeneratorComponent } from '../classes/mock/model-generator/model-generator.component';
import { DevGuard } from '../services/auth/guards/dev.guard';
const routes: Routes = [
  {
    path: '',
    component: AppLayoutComponent,
    canActivate: [LoggedGuard],
    children: [
      {
        path: '',
        component: HomeComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'ddfNotif',
        component: DdfNotificationComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'dossier/:did',
        component: DossierComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'ddf',
        component: DdfPageComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'dossier/:did/suivi',
        component: SuiviDossierComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'monCompte',
        component: MonCompteComponent,
        canActivate: [LoggedGuard]
      },
      {
        path: 'resultats-recherche',
        component: ResultatsRechercheComponent,
        canActivate: [LoggedGuard]
      }
    ]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'tools',
    component: ModelGeneratorComponent,
    canActivate: [DevGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule {}
