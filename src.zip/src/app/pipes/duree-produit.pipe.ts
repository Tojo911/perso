import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dureeProduit'
})
export class DureeProduitPipe implements PipeTransform {
  transform(value: string, args: any): string {
    if (!value || !args) {
      return value;
    }

    return value
      .replace('${min}', args.dureeMin)
      .replace('${max}', args.dureeMax);
  }
}
