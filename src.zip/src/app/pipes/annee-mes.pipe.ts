import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'anneeMES'
})
export class AnneeMESPipe implements PipeTransform {

  transform(value: any, args: string): any {
    if (!value || !args) {
      return value;
    }
    return value.replace('${year}', args);
  }

}
