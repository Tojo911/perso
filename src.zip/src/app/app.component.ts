import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  toppingList = [
    'Extra cheese',
    'Mushroom',
    'Onion',
    'Pepperoni',
    'Sausage',
    'Tomato'
  ];
  colorList: string[] = ['', 'primary', 'secondary', 'tertiary'];

  title = 'app works!';
  constructor(public translate: TranslateService) {
    translate.addLangs(['en', 'fr']);
    const browserLang = translate.getBrowserLang();
    /* translate.use(browserLang.match(/en|fr/) ? browserLang : 'fr'); */
    translate.use('fr');
  }}
