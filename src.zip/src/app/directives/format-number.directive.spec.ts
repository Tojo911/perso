import { FormatNumberDirective } from './format-number.directive';

describe('FormatNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new FormatNumberDirective();
    expect(directive).toBeTruthy();
  });
});
