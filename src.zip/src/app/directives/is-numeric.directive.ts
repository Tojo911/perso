import { Directive, ElementRef, Renderer2, HostListener,  Input } from '@angular/core';

@Directive({
  selector: '[appIsNumeric]'
})
export class IsNumericDirective {
  regExIsNum = new RegExp('^[0-9]\d{0,2}$');
  regExIsAlphabet = new RegExp('[A-Za-z]');
  @Input() isDecimal: boolean;
  constructor(private el: ElementRef, private renderer: Renderer2) {
  }

  @HostListener('keydown', ['$event']) onkeyup($e: KeyboardEvent) {
    if (!this.regExIsNum.test($e.key)) {
      if (($e.key.length === 1
          || $e.key === 'Multiply'
          || $e.key === 'Subtract'
          || $e.key === 'Add'
          || $e.key === 'Divide') && !($e.key === '.' && this.isDecimal)) {
        $e.preventDefault();
      }
    }
  }
}
