import {
  Directive,
  ElementRef,
  Output,
  EventEmitter,
  HostListener,
  Input,
  AfterViewInit
} from '@angular/core';

@Directive({
  selector: '[appClickedOutside]'
})
export class ClickedOutsideDirective implements AfterViewInit {
  @Input()
  public looseCheck = false;
  @Input()
  public hasleftFor: number;
  @Output()
  public hasLeft = new EventEmitter();
  @Output()
  public clickedOutside = new EventEmitter();
  @Output()
  public blur = new EventEmitter();
  public lastElement: any;
  public componentList: ElementRef[] = [];
  @Input()
  compList: ElementRef[] = [];
  @Output()
  public compListChange = new EventEmitter();
  mouseIsOver = false;
  mouseleavedAlready = false;
  overSuspended = false;
  index = 0;
  constructor(private el: ElementRef) {}
  ngAfterViewInit() {
    this.componentList.push(this.el);
  }
  @HostListener('document:click', ['$event.target'])
  public onclick(targetElement) {
    if (
      !this.contains(targetElement) &&
      (this.isInDocument(targetElement) || this.looseCheck)
    ) {
      this.clickedOutside.emit({
        target: targetElement,
        src: this.el.nativeElement
      });
      if (this.lastElement && this.contains(this.lastElement)) {
        this.blur.emit({
          target: targetElement,
          src: this.el.nativeElement,
          last: this.lastElement
        });
      }
    }
    this.lastElement = targetElement;
  }
  isInDocument(targetElement) {
    return targetElement === document.body
      ? false
      : document.body.contains(targetElement);
  }
  contains(el: ElementRef) {
    let contains = false;
    this.componentList.forEach(it => {
      if (it.nativeElement.contains(el)) {
        contains = true;
      }
    });
    this.compList.forEach(it => {
      if (it.nativeElement.contains(el)) {
        contains = true;
      }
    });
    return contains;
  }

  @HostListener('mousemove', ['$event.target'])
  onmouseover(el) {
    this.mouseIsOver = true;
  }
  @HostListener('mouseleave', ['$event.target'])
  onmouseleave(el?) {
    if (this.hasleftFor) {
      if (this.mouseleavedAlready && !this.mouseIsOver && !this.overSuspended) {
        this.hasLeft.emit(el);
      } else if (!this.mouseleavedAlready) {
        setTimeout(() => {
          this.onmouseleave();
        }, this.hasleftFor);
        this.mouseleavedAlready = true;
        this.mouseIsOver = false;
        return;
      }
    }
    this.mouseleavedAlready = false;
    this.mouseIsOver = false;
  }
  public suspendOverDetection() {
    this.mouseIsOver = true;
    this.overSuspended = true;
  }
  public resumeOverDetection() {
    this.overSuspended = false;
  }
}
