import { ClickedOutsideDirective } from './clicked-outside.directive';

describe('ClickedOutsideDirective', () => {
  it('should create an instance', () => {
    const directive = new ClickedOutsideDirective();
    expect(directive).toBeTruthy();
  });
});
