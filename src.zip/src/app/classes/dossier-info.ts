/*export class DossierInfo {
  /* TODO: @anas: we need to rediscuss this and check info with backend data *
  id: number;
  numSiren: string;
  montant: number;
  duree: string;
  produitFinancier: Map<string, any>;
  dateSaisie: Date;
  raisonSociale: string;
  status: Map<string, any>;
  materiel: Map<string, any>;
  blocMateriel: Map<string, any>;
  blocPlanFinancement: Map<string, any>;
  vendeur: Map<string, any>;
  // To be changed with correct attribute
  loyerFinancier: any;
  periodicite: any;
  loyerTotal: any;

  assurance: any;
  calage: any;
  nbJoursCalage: any;
  assurance_personne: any;
  assurance_materiel: any;
  bareme: any;
  fournisseur: any;
  maintenance: any;
  serie: any;
  designation: any;

  constructor(response: any) {
    this.id = response.id;
    this.numSiren = response.numeroSIREN;
    this.montant = response.montant;
    if (response.duree) {
      this.duree = response.duree.toString();
    }
    this.produitFinancier = this.convertToMap(response.produitFinancier);
    this.dateSaisie = response.dateSaisie;
    this.raisonSociale = response.raisonSociale;
    this.status = this.convertToMap(response.statut);
    this.materiel = this.convertToMap(response.materiel);
    this.blocMateriel = this.convertToMap(response.blocMateriel);
    this.blocPlanFinancement = this.convertToMap(response.blocPlanFinancement);
    this.vendeur = this.convertToMap(response.vendeur);
    // To be changed with correct attribute
    this.loyerFinancier = '256';
    this.periodicite = 'Semestrielle';
    this.loyerFinancier = '3256';
    this.assurance = '145';
    this.calage = '';
    this.nbJoursCalage = '';
    this.assurance_personne = '';
    this.assurance_materiel = '';
    this.bareme = '';
    this.fournisseur = 167;
    this.maintenance = '';
    this.serie = '56897425';
    this.designation = 'Designation';
  }

  // this Method allow to convert an Object to a Map<key, value> type
  convertToMap(obj: any): Map<string, any> {
    const map = new Map<string, any>();
    let result = null;

    if (obj) {
      Object.keys(obj).forEach(k => {
        result =
          typeof obj[k] === 'object'
            ? map.set(k, this.convertToMap(obj[k]))
            : map.set(k, obj[k]);
      });
    }
    return result;
  }

  public updateMateriel(obj: any) {
    this.materiel = this.convertToMap(obj);
  }
}
*/
