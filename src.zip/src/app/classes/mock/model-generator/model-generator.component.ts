import { Component, OnInit } from '@angular/core';
export class ObjectDesc {
  name: string;
  desc: string;
  parent: ObjectDesc;
  childs: ObjectDesc[] = [];
  constructor(name, desc, parent?) {
    this.name = name;
    this.desc = desc;
    this.parent = parent;
  }
  getDesc(childsName?) {
    let childDesc = '';
     childsName = childsName ? childsName : [];
    if (this.childs) {
      this.childs.forEach(it => {
        if (!childsName.includes(it.name)) {
          childsName.push(it.name);
          childDesc += it.getDesc(childsName);
        }
      });
    }
    const name = (this.name && this.name.trim() !== '') ? 'export interface ' + this.name : '';
    return   name      +      this.desc +      `
    ` +
      childDesc;
  }
}
@Component({
  selector: 'app-model-generator',
  templateUrl: './model-generator.component.html',
  styleUrls: ['./model-generator.component.scss']
})
export class ModelGeneratorComponent implements OnInit {
  public result: string;
  constructor() {}

  ngOnInit() {}
  transformDesc2Model(str) {
    str = str
      .split('$')
      .join('')
      .split('(double)')
      .join('')
      .split('(int32)')
      .join('')
      .split('(date-time)')
      .join('')
      .split('(float)')
      .join('')
      .split('{...}')
      .join('');
      const cur = str
      .replace(/number/g, 'number;')
      .replace(/integer/g, 'number;')
      .replace(/string/g, 'string;')
      .replace(/boolean/g, 'boolean;')
      .replace(/\t/g, ':');
    let currentObj: ObjectDesc;
    let currentObjName = '',
      recordName = true;
    cur.split('').map(it => {
      if (it === '{') {
        if (!currentObj) {
          currentObj = new ObjectDesc(currentObjName.replace('[', ''), '');
        } else  {
          currentObj.childs.push(
            new ObjectDesc(currentObjName.replace('[', ''), '', currentObj)
          );
          currentObj.desc += ';';
          currentObj = currentObj.childs[currentObj.childs.length - 1];
        }
        recordName = false;
        currentObjName = '';
      } else if (it === ':') {
        recordName = true;
        currentObjName = '';
      }

      if (currentObj) {
        currentObj.desc += (it === ':') ? it + ' ' : it ;
        if (it === '}' && currentObj.parent) {
          currentObj = currentObj.parent;
        }
      }
      if (recordName) {
        if (it !== ':') {
          currentObjName += it;
        }
      }
    });

    return currentObj.getDesc().split('{').join(' {').split(' [').join(' ').split(';]').join(' [];').split('...]')
    .join(' string[];');
  }
}
