import { IFormatInput } from "../interfaces/IFormatInput";

export class SirenFormatter implements IFormatInput {
  formatName = 'siren';
  parse(val) {
    if (!val || val === '') {return ''; }
    let valStr = val + '';
    valStr = valStr.replace(/ /g, '');
    if ( valStr.length > 9) {
      valStr = valStr.substring(0, 9);
    }

    return valStr;
  }
  transform( val) {
    if (!val || val === '') {return ''; }
    let arr;
    let valStr = val + '';
        valStr = this.parse(valStr) + '';
        arr = valStr.split('');
        valStr = '';
        arr.map(c => {
          valStr += c;
          if (
            valStr.replace(/ /g, '').length % 3 === 0 &&
            arr.length > valStr.replace(/ /g, '').length
          ) {
            valStr += ' ';
          }
        });
        return valStr;

  }
}
