import { IFormatInput } from "../interfaces/IFormatInput";

export class AmountFormatter implements IFormatInput {
  constructor(private min?: number, private max?: number, private minLength?: number, private maxLength?: number) {}
  formatName = 'amount';
  parse(val) {
    if (!val || val === '') {return ''; }
    let valStr = val + '';
    if (valStr.substring(valStr.length - 1 , 1) === '.') {
      valStr = valStr.replace('.', '');
    }
    valStr = valStr.replace(/ /g, '');
    if ( valStr === '') {
      return '';
    }
    val = Number(valStr);
    if (this.min && val < this.min) {
      val = this.min + '';
    }
    if (this.max && val > this.max) {
      val = this.max + '';
    }
    valStr = val + '';
    if (this.maxLength && valStr.length > this.maxLength) {
      valStr = valStr.substring(0, this.maxLength);
    }
    return valStr;
  }
  transform( val) {
    if (!val || val === '') {return ''; }
    let decPart = '';
    let arr;
    let virgule = '';
    if (this.min && val < this.min) {
      val = this.min + '';
    }
    if (this.max && val > this.max) {
      val = this.max + '';
    }
    let valStr = val + '';
    if (valStr.indexOf('.') !== -1) {
      virgule = '.';
      decPart = valStr.split('.')[1];
      valStr = valStr.split('.')[0];
    }
    valStr = this.parse(valStr);
    if (valStr === '') {
      return '';
    }
    if (this.maxLength && valStr.length > this.maxLength) {
      valStr = valStr.substring(0, this.maxLength);
    }
    arr = valStr.split('');
    valStr = '';
    arr.reverse().map(c => {
      valStr += c;
      if (
        valStr.replace(/ /g, '').length % 3 === 0 &&
        arr.length > valStr.replace(/ /g, '').length
      ) {
        valStr += ' ';
      }
    });
    valStr = valStr
      .split('')
      .reverse()
      .join('');
      valStr += virgule;
    if ((decPart + '').length > 2) {
      decPart = (decPart + '').substring(0, 2);
    }
    if (decPart && decPart !== '') {
      valStr +=  decPart;
    }
        return valStr;

  }
}
