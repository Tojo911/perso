export interface IFormatInput {
  formatName: string;
  parse: (_: any) => string;
  transform: (_: any) => string;
}
