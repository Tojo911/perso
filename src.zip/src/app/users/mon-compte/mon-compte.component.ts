import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth/auth.service';
import { UserInfo } from '../../models/ddf';

@Component({
  selector: 'app-mon-compte',
  templateUrl: './mon-compte.component.html',
  styleUrls: ['./mon-compte.component.scss']
})
export class MonCompteComponent implements OnInit {
  public userModel: UserInfo = {};
  constructor(private authService: AuthService) {
    this.initiateUser();
  }

  ngOnInit() {}

  initiateUser() {

    this.userModel.firstname = this.authService.getUserDataByKeyFromJWTPayload(
      'firstname'
    );
    this.userModel.username = this.authService.getUserDataByKeyFromJWTPayload(
      'username'
    );
    this.userModel.lastname = this.authService.getUserDataByKeyFromJWTPayload(
      'lastname'
    );
    this.userModel.mail = this.authService.getUserDataByKeyFromJWTPayload(
      'mail'
    );
    this.userModel.agence = this.authService.getUserDataByKeyFromJWTPayloadObject(
      'agence'
    );
  }
}
