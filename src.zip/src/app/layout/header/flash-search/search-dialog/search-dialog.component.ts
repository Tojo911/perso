import { Component, OnInit, Injectable, Inject, ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-search-dialog',
  templateUrl: './search-dialog.component.html',
  styleUrls: ['./search-dialog.component.scss']
})
export class SearchDialogComponent implements OnInit {
  modalTitle: string;
  constructor(private dialogRef: MatDialogRef<SearchDialogComponent>, private el: ElementRef,
    @Inject(MAT_DIALOG_DATA) data) {
      this.modalTitle = data.title;
    }
  ngOnInit() {
  }

  save() {
    this.dialogRef.close(true);
  }

  close() {
    this.dialogRef.close();
  }
  getElRef() {
    return this.el.nativeElement;
  }
}
