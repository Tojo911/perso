import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlashSearchComponent } from './flash-search.component';

describe('FlashSearchComponent', () => {
  let component: FlashSearchComponent;
  let fixture: ComponentFixture<FlashSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlashSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlashSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
