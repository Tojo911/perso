import {
  Component,
  OnInit,
  forwardRef,
  EventEmitter,
  Output
} from '@angular/core';
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR,
  DefaultValueAccessor
} from '@angular/forms';
import { MatDialog, MatDialogConfig, MatSnackBar } from '@angular/material';
import * as _ from 'lodash';
import { ModelOption } from '../../../models/option-model';
import { SearchDialogComponent } from './search-dialog/search-dialog.component';
import { Router, NavigationExtras } from '@angular/router';
import { RechercheService } from '../../../services/recherche/recherche.service';
import { Observable } from 'rxjs';
import { DossierInfo } from '../../../models/dossier-info';
import { map } from 'rxjs/operators';
@Component({
  selector: 'app-flash-search',
  templateUrl: './flash-search.component.html',
  styleUrls: ['./flash-search.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => DefaultValueAccessor),
      multi: true
    }
  ]
})
export class FlashSearchComponent implements OnInit, ControlValueAccessor {
  activated = false;
  blurEnable = true;
  uniqueCriteria = new ModelOption(null, null, null); // ??? why type is ModelOption
  onChange: () => any;
  onTouched: () => any;
  @Output()
  emptySearchResultEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  public emptyResult = false;

  constructor(
    private dialog: MatDialog,
    private router: Router,
    private rechercheService: RechercheService
  ) {}

  ngOnInit() {}

  select(current: ModelOption) {
    this.writeValue(current);
  }

  activateSearch() {
    this.activated = true;
  }

  writeValue(obj: ModelOption): void {}

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  eject() {
    this.activated = false;
  }

  redirectToResultPage(expectedUrl: string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '400px';
    dialogConfig.height = '270px';
    dialogConfig.data = {
      title: 'voulez vous quitter la demande de financement ?'
    };
    this.blurEnable = false;
    const dialogRef = this.dialog
      .open(SearchDialogComponent, dialogConfig)
      .afterClosed()
      .subscribe((result?: boolean) => {
        this.blurEnable = true;
        if (result) {
          this.activated = false;
          this.uniqueCriteria = new ModelOption(null, null, null);
        } else {
          this.router.navigate([expectedUrl]);
        }
      });
    return;
  }

  quickRequest() {
    if (this.uniqueCriteria.value === null) {
      return null;
    }

    this.rechercheService
      .quickSearch(this.uniqueCriteria.value)
      .pipe(map(res => res.content.dossiers as DossierInfo[]))
      .subscribe((res: DossierInfo[]) => {
        if (res.length === 0) {
          this.emptySearchResultEvent.emit(true);
        } else {
          this.emptySearchResultEvent.emit(false);

          if (res.length === 1) {
            // send quick search by Num dossier
            this.sendQuickSearchByDossierRequest();
          }
          // else {
          // send and save resultBy SIREN Result
          // this.rechercheService.sendStorage('je suis la');
          //  this.sendQuickSearchBySirenRequest(); // send quick search by Num siren
          // }
        }
      });
  }

  sendQuickSearchByDossierRequest() {
    const resultSearchtUrl = 'dossier/ddf_' + this.uniqueCriteria.value + '/suivi/';
    if (this.router.url === '/ddf') {
      this.redirectToResultPage(resultSearchtUrl);
    } else {
      this.router.navigate([resultSearchtUrl]);
    }
  }

  // SIREN in next Release
  sendQuickSearchBySirenRequest() {
    const resultSearchtUrl = '/resultats-recherche';
    if (this.router.url === '/ddf') {
      this.redirectToResultPage(resultSearchtUrl);
    } else {
      this.router.navigate([resultSearchtUrl]);
    }
  }

  // ??? why on blur  to reset value
  onBlur($e: any) {
    if (this.blurEnable) {
      this.uniqueCriteria = new ModelOption(null, null, null);
      // this.reset();
    }
  }
}
