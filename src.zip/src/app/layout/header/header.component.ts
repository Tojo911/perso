import { Component, EventEmitter, OnInit, Output } from '@angular/core';

import { AuthService } from '../../services/auth/auth.service';
import { environment } from '../../../environments/environment';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public showEmptyResutContent = false;
  @Output()
  toggleEvent: EventEmitter<void> = new EventEmitter();
  @Output()
  openDdfEvent: EventEmitter<void> = new EventEmitter();
  @Output()
  openNotifdDdfEvent: EventEmitter<void> = new EventEmitter();
  isAuthorizedDdf: boolean;
  model: any = {};
  appVersion: string;
  constructor(
    private authService: AuthService,
    public snackBar: MatSnackBar,
    private translateService: TranslateService
  ) {
    this.appVersion = environment.version;
    this.isAuthorizedDdf = this.isAuthDdf();
  }

  ngOnInit() {
    this.model.user = this.authService.getCurrentUser();
  }

  logout() {
    this.authService.logout();
  }

  toggle() {
    this.toggleEvent.emit();
  }

  openDdf() {
    this.openDdfEvent.emit();
  }
  openNotifDdf() {
    this.openNotifdDdfEvent.emit();
  }
  isProd() {
    return environment.env === 'prod';
  }
  isAuthDdf() {
    return this.authService.isAuthDdf();
  }

  showEmptyResultDialog(result) {
    if (result) {
      this.snackBar.open(
        this.translateService.instant('ADVANCED_SEARCH.NO_RESULT'),
        undefined,
        {
          duration: 2500,
          panelClass: 'snack-container',
          verticalPosition: 'top',
          horizontalPosition: 'center'
        } as MatSnackBarConfig
      );
    }
  }
}
