/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Component } from '@angular/core';

import { RouterTestingModule } from '@angular/router/testing';

import { AppLayoutComponent } from './app-layout.component';
import { AuthService } from '../services/auth/auth.service';

describe('AppLayoutComponent', () => {
  let component: AppLayoutComponent;
  let fixture: ComponentFixture<AppLayoutComponent>;

  @Component({ selector: 'app-header', template: '' })
  class HeaderStubComponent {}

  // tslint:disable-next-line:component-selector
  @Component({ selector: 'mat-icon', template: '' })
  class MatIconStubComponent {}
  // tslint:disable-next-line:component-selector
  @Component({ selector: 'mat-dialog', template: '' })
  class MatDialogStubComponent {}

  // tslint:disable-next-line:component-selector
  @Component({ selector: 'mat-sidenav', template: '' })
  class MatSideNavStubComponent {}

  // tslint:disable-next-line:component-selector
  @Component({ selector: 'mat-sidenav-content', template: '' })
  class MatSideNavContentStubComponent {}

  // tslint:disable-next-line:component-selector
  @Component({ selector: 'mat-sidenav-container', template: '' })
  class MatSideNavContainerStubComponent {}

  // tslint:disable-next-line:component-selector
  @Component({ selector: 'router-outlet', template: '' })
  class RouterOutletStubComponent {}

  // tslint:disable-next-line:component-selector
  @Component({ selector: 'app-footer', template: '' })
  class FooterStubComponent {}

  let AuthServiceStub: Partial<AuthService>;

  AuthServiceStub = {};

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [{ provide: AuthService, useValue: AuthServiceStub }],
      imports: [RouterTestingModule],
      declarations: [
        AppContentComponent,
        HeaderStubComponent,
        MatIconStubComponent,
        MatDialogStubComponent,
        MatSideNavStubComponent,
        RouterOutletStubComponent,
        MatSideNavContentStubComponent,
        MatSideNavContainerStubComponent,
        FooterStubComponent
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
