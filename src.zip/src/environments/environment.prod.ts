
export const environment = {
  production: true,
  env: 'prod',
  version: require('../../package.json').version
};
