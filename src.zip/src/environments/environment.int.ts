
export const environment = {
  production: true,
  env: 'int',
  version: require('../../package.json').version
};
